/* db_enlaces.js — Directorio de recursos y enlaces externos. Solo admin edita. */
window.DB_ENLACES = {
  _version: '2026.05.19',
  meta: {
    descripcion: 'Recursos rápidos y enlaces externos de uso clínico-administrativo',
  },
  enlaces: [
    // Normas y guías
    { id: 'E001', categoria: 'Normas',     titulo: 'Ministerio de Salud Bolivia',           url: 'https://www.minsalud.gob.bo/',                                                                  descripcion: 'Sitio oficial del Ministerio' },
    { id: 'E002', categoria: 'Normas',     titulo: 'INASES',                                 url: 'https://www.inases.gob.bo/',                                                                    descripcion: 'Instituto Nacional de Seguros de Salud' },
    { id: 'E003', categoria: 'Normas',     titulo: 'CIE-10 OMS (oficial)',                   url: 'https://icd.who.int/browse10/2019/en',                                                          descripcion: 'Buscador oficial de CIE-10 (en inglés)' },
    { id: 'E004', categoria: 'Normas',     titulo: 'Vademécum LINAME consulta',              url: 'https://www.minsalud.gob.bo/index.php/medicamentos',                                            descripcion: 'Lista nacional vigente' },

    // Calculadoras / Apps
    { id: 'E101', categoria: 'Apps',       titulo: 'MDCalc',                                 url: 'https://www.mdcalc.com/',                                                                       descripcion: 'Calculadoras clínicas' },
    { id: 'E102', categoria: 'Apps',       titulo: 'UpToDate',                               url: 'https://www.uptodate.com/',                                                                     descripcion: 'Referencia clínica (suscripción)' },
    { id: 'E103', categoria: 'Apps',       titulo: 'Drugs.com Interactions',                 url: 'https://www.drugs.com/drug_interactions.html',                                                  descripcion: 'Verificador de interacciones medicamentosas' },

    // Pediatría / Nutrición
    { id: 'E201', categoria: 'Pediatría',  titulo: 'OMS — Tablas LMS crecimiento',           url: 'https://www.who.int/childgrowth/standards/en/',                                                 descripcion: 'Estándares oficiales OMS 0-5 años' },
    { id: 'E202', categoria: 'Pediatría',  titulo: 'OMS — Crecimiento 5-19 años',            url: 'https://www.who.int/tools/growth-reference-data-for-5to19-years',                              descripcion: 'Growth reference 2007' },
    { id: 'E203', categoria: 'Pediatría',  titulo: 'PAI Bolivia',                            url: 'https://www.minsalud.gob.bo/index.php/inmunizaciones',                                          descripcion: 'Programa Ampliado de Inmunizaciones' },

    // Gestante / Bonos
    { id: 'E301', categoria: 'Subsidios',  titulo: 'SEDEM Bolivia',                          url: 'https://www.sedem.gob.bo/',                                                                     descripcion: 'Servicio de Desarrollo de Empresas Públicas' },
    { id: 'E302', categoria: 'Subsidios',  titulo: 'Bono Juana Azurduy',                     url: 'https://www.minsalud.gob.bo/index.php/bono-juana-azurduy',                                       descripcion: 'Programa nacional BJA' },

    // Diccionarios
    { id: 'E401', categoria: 'Referencias',titulo: 'PubMed',                                 url: 'https://pubmed.ncbi.nlm.nih.gov/',                                                              descripcion: 'Búsqueda bibliográfica médica' },
    { id: 'E402', categoria: 'Referencias',titulo: 'Cochrane Library',                       url: 'https://www.cochranelibrary.com/',                                                              descripcion: 'Revisiones sistemáticas' },
  ],
};
