/* db_sedem.js — Direcciones SEDEM editables por admin */
window.DB_SEDEM = {
  _version: '2026.05.20',
  meta: {
    descripcion: 'Direcciones de oficinas SEDEM para recojo del Subsidio Universal Prenatal por la Vida y BJA',
    fuente: 'SEDEM Bolivia',
  },
  direcciones: [
    { id: 1,  area: 'urbano', nombre: 'LA PAZ – Distribuidora La Paz: Av. Jaimes Freyre esq. Calle 1 Nro. 2344, zona Sopocachi.' },
    { id: 2,  area: 'urbano', nombre: 'EL ALTO I – Distribuidora El Alto: Av. Cívica s/n, Mercado Campesino, zona Santa Rosa.' },
    { id: 3,  area: 'urbano', nombre: 'EL ALTO II – Agencia Villa Tunari: Av. Antonio José de Sucre, Mercado Campesino, frente al retén policial.' },
    { id: 4,  area: 'rural',  nombre: 'SAN BUENAVENTURA – Agencia San Buenaventura: Municipio de San Buenaventura, distrito Tumupasa.' },
    { id: 5,  area: 'rural',  nombre: 'LA ASUNTA – Agencia La Asunta: Coliseo Cerrado La Asunta, zona 3 Las Palmeras, calle José Guamán.' },
    { id: 6,  area: 'rural',  nombre: 'CHULUMANI – Agencia Chulumani: Zona central, calle Murillo s/n, media cuadra del Banco Prodem.' },
    { id: 7,  area: 'rural',  nombre: 'IRUPANA – Agencia Irupana: Calle Cochabamba esq. Héroes del Chaco, planta baja del mercado municipal.' },
    { id: 8,  area: 'rural',  nombre: 'CARANAVI – Agencia Caranavi: Zona River Yara, predios de la sede de la Junta de Vecinos.' },
    { id: 9,  area: 'rural',  nombre: 'TUMUPASA – Agencia Tumupasa: Media cuadra de la plaza principal.' },
    { id: 10, area: 'rural',  nombre: 'PATACAMAYA – Agencia Patacamaya: Av. Manco Kapac, zona Villa Lealtad, frente a la Plaza del Estudiante.' },
    { id: 11, area: 'rural',  nombre: 'ACHACHI – Agencia Achachi: Av. Manco Kapac, zona Villa Lealtad, frente a la Plaza del Estudiante.' },
  ],
};
