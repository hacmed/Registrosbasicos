/* db_agenda.js — Agenda y cronograma editable. Solo admin puede modificar. */
window.DB_AGENDA = {
  _version: '2026.05.23',
  meta: {
    descripcion: 'Eventos, recordatorios y to-dos de la agenda clínica',
  },
  // Permisos por rol: qué pestañas ve cada uno. El admin siempre ve todo.
  // El "invitado" es quien entra sin contraseña.
  rolePermissions: {
    invitado:  ['dashboard', 'vademecum', 'clinica', 'pai-vigil'],
    bja:       ['dashboard', 'nutricion', 'gestante', 'vademecum', 'clinica', 'pai-vigil', 'suppv-bja', 'enlaces', 'seguimiento'],
    nutricion: ['dashboard', 'nutricion', 'gestante'],
  },
  dashboardWidgets: {
    noticias:        true,   // visible para todos por default
    patologiaDelDia: true,
    eventos:         false,  // ocultos hasta que admin los habilite
    todos:           false,
    enlaces:         false,
  },
  noticias: [
    {
      id: 'N001',
      fecha: '2026-05-20',
      titulo: 'Sistema Registros Básicos en operación',
      cuerpo: 'Versión inicial de la app clínica disponible. Incluye Clínica, Vademécum, Nutrición, Gestante, PAI/Vigilancia y SUPPV/BJA.',
    },
  ],
  patologiaDelDia: {
    cie10: 'D50',
    nombre: 'Anemia Ferropénica',
    nota: 'Recordar suplementación con sulfato ferroso en gestantes según norma SAFCI.',
  },
  eventos: [],
  todos: [],
  checkins: [],
};
