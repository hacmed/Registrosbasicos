/* ============================================================================
   roles.js — Panel administrativo central: usuarios, roles y permisos

   ADVERTENCIA: en una app 100% cliente, esto es ORGANIZATIVO, no seguridad
   criptográfica. Cualquiera con conocimientos técnicos puede abrir el código.
   Su valor es ordenar el uso, no proteger contra un atacante.

   Roles:
   - admin: ve y administra todo.
   - Roles personalizados (incl. 'invitado'): el admin define qué pestañas ven.
   Permisos en DB_AGENDA.rolePermissions = { <rol>: [tabIds...] }.
   El usuario sin sesión usa el rol 'invitado'.
   ============================================================================ */
(function () {
  'use strict';

  const ALL_TABS = [
    { id: 'dashboard',  label: 'Inicio' },
    { id: 'nutricion',  label: 'Nutrición' },
    { id: 'gestante',   label: 'Gestante' },
    { id: 'vademecum',  label: 'Vademécum' },
    { id: 'agenda',     label: 'Agenda' },
    { id: 'clinica',    label: 'Clínica' },
    { id: 'pai-vigil',  label: 'PAI / Vigilancia' },
    { id: 'suppv-bja',  label: 'SUPPV / BJA' },
    { id: 'enlaces',    label: 'Enlaces' },
    { id: 'seguimiento',label: 'Seguimiento Gestante' },
  ];

  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

  function getPerms() {
    const ag = window.DB_AGENDA;
    if (!ag) return { invitado: ['dashboard'] };
    if (!ag.rolePermissions) {
      ag.rolePermissions = { invitado: ALL_TABS.map(t => t.id).filter(id => id !== 'agenda') };
    }
    // Migración: si existía 'anon', renombrar a 'invitado'
    if (ag.rolePermissions.anon && !ag.rolePermissions.invitado) {
      ag.rolePermissions.invitado = ag.rolePermissions.anon;
      delete ag.rolePermissions.anon;
    }
    return ag.rolePermissions;
  }

  function savePerms() {
    if (window.DB_AGENDA) window.State?.set('agenda_data', window.DB_AGENDA);
  }

  // ¿Pestaña permitida para el usuario actual?
  function isTabAllowed(id) {
    if (window.Auth?.isAdmin()) return true;
    const user = window.Auth?.getCurrentUser();
    const perms = getPerms();
    const rol = user ? user.role : 'invitado';
    // Un rol no definido en perms ve todo lo no-admin (fallback permisivo salvo invitado)
    const lista = perms[rol] || (rol === 'invitado' ? (perms.invitado || []) : ALL_TABS.map(t => t.id));
    return lista.includes(id);
  }

  // Lista de roles existentes (admin + invitado + los que aparezcan en usuarios/perms)
  function getRoles() {
    const set = new Set(['admin', 'invitado']);
    (window.Auth?.listUsers() || []).forEach(u => set.add(u.role));
    Object.keys(getPerms()).forEach(r => set.add(r));
    return Array.from(set);
  }

  // ====== PANEL ADMINISTRATIVO (pestaña) ===================================
  window.render_admin = function (panel) {
    if (!window.Auth?.isAdmin()) {
      panel.innerHTML = '<div class="empty-state"><p>Acceso solo para administradores.</p></div>';
      return;
    }
    const users = window.Auth.listUsers();
    const roles = getRoles();

    panel.innerHTML = `
      <div class="m6-header">
        <div><h1>Administración</h1>
        <p class="muted small">Usuarios, roles y configuración del sistema</p></div>
      </div>

      <div class="rb-admin-warn">
        ⚠️ Este control es organizativo. En una app sin servidor no constituye seguridad real:
        alguien con conocimientos técnicos puede leer el código. Para seguridad fuerte se requiere un servidor.
      </div>

      <div class="card mt-4">
        <div class="card-h"><h2>👤 Usuarios</h2>
          <button class="btn btn-primary" id="adm-user-new" style="margin-left:auto;font-size:0.85rem;padding:6px 12px;">+ Nuevo usuario</button>
        </div>
        <div class="rb-adm-userlist">
          ${users.map(u => `
            <div class="rb-adm-user">
              <div class="rb-adm-user-info">
                <strong>${esc(u.display || u.username)}</strong>
                <span class="tiny muted">@${esc(u.username)} · rol: <span class="badge badge-clinic tiny">${esc(u.role)}</span></span>
              </div>
              <div class="row gap-2">
                <button class="btn btn-ghost adm-user-edit" data-u="${esc(u.username)}" style="font-size:0.78rem;padding:4px 10px;">Editar</button>
                <button class="btn btn-ghost adm-user-del" data-u="${esc(u.username)}" style="font-size:0.78rem;padding:4px 10px;color:var(--rose);">Eliminar</button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-h"><h2>🔑 Permisos por rol</h2>
          <button class="btn btn-ghost" id="adm-role-new" style="margin-left:auto;font-size:0.85rem;padding:6px 12px;">+ Nuevo rol</button>
        </div>
        <p class="small muted">Marca qué pestañas ve cada rol. El rol <strong>admin</strong> siempre ve todo. El <strong>invitado</strong> es quien entra sin contraseña.</p>
        <div class="rb-adm-roles">
          ${roles.filter(r => r !== 'admin').map(rol => {
            const lista = getPerms()[rol] || [];
            return `
              <div class="rb-adm-role">
                <div class="rb-adm-role-h">
                  <strong>${esc(rol)}</strong>
                  ${rol !== 'invitado' ? `<button class="btn btn-ghost adm-role-del" data-r="${esc(rol)}" style="font-size:0.72rem;padding:2px 8px;color:var(--rose);">eliminar rol</button>` : ''}
                </div>
                <div class="rb-adm-tabs">
                  ${ALL_TABS.map(t => `
                    <label class="m3-checkbox tiny">
                      <input type="checkbox" class="adm-perm" data-rol="${esc(rol)}" data-tab="${t.id}" ${lista.includes(t.id)?'checked':''}/>
                      <span>${esc(t.label)}</span>
                    </label>
                  `).join('')}
                </div>
              </div>`;
          }).join('')}
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-h"><h2>⚙️ Configuración y herramientas</h2></div>
        <div class="row gap-2" style="flex-wrap:wrap;">
          <button class="btn btn-ghost" id="adm-go-config" style="font-size:0.85rem;padding:6px 12px;">🏠 Configuración de Inicio</button>
          <button class="btn btn-ghost" id="adm-backup-exp" style="font-size:0.85rem;padding:6px 12px;">💾 Respaldar todo</button>
          <button class="btn btn-ghost" id="adm-backup-imp" style="font-size:0.85rem;padding:6px 12px;">📂 Restaurar</button>
          <button class="btn btn-ghost" id="adm-order" style="font-size:0.85rem;padding:6px 12px;">↕️ Orden de pestañas</button>
        </div>
        <div class="row gap-2 mt-2" style="flex-wrap:wrap;border-top:1px solid var(--rule-soft);padding-top:var(--space-3);">
          <button class="btn btn-ghost" id="adm-users-exp" style="font-size:0.85rem;padding:6px 12px;">👥 Respaldar usuarios</button>
          <button class="btn btn-ghost" id="adm-users-imp" style="font-size:0.85rem;padding:6px 12px;">📥 Restaurar usuarios</button>
        </div>
        <div class="row gap-2 mt-2" style="flex-wrap:wrap;border-top:1px solid var(--rule-soft);padding-top:var(--space-3);">
          <button class="btn btn-primary" id="adm-gen-server" style="font-size:0.85rem;padding:6px 12px;">📤 Generar archivos para el servidor</button>
        </div>
        <p class="tiny muted mt-2">El respaldo de usuarios incluye los roles y las contraseñas (cifradas como hash, nunca en texto plano).<br>
        <strong>Generar archivos para el servidor:</strong> descarga las bases de datos y usuarios ya modificados como archivos <code>.js</code>, listos para reemplazar en la carpeta de la web y subir. Así tus cambios quedan disponibles para todos, no solo en este equipo.</p>
      </div>

      <div class="card mt-4">
        <div class="card-h"><h2>📋 Registro de actividad (audit log)</h2>
          <button class="btn btn-ghost" id="adm-audit-clear" style="margin-left:auto;font-size:0.78rem;padding:4px 10px;">Limpiar</button>
        </div>
        <div class="rb-adm-audit">
          ${(window.Auth.getAuditLog() || []).slice(-50).reverse().map(e => `
            <div class="rb-adm-audit-row">
              <span class="tiny mono muted">${new Date(e.ts).toLocaleString('es-BO')}</span>
              <span class="tiny"><strong>${esc(e.user)}</strong> · ${esc(e.action)}${e.detail?' · '+esc(e.detail):''}</span>
            </div>
          `).join('') || '<p class="tiny muted">Sin actividad registrada.</p>'}
        </div>
      </div>
    `;

    bindAdmin(panel);
  };

  function bindAdmin(panel) {
    // Nuevo usuario
    panel.querySelector('#adm-user-new')?.addEventListener('click', () => userDialog(panel, null));
    panel.querySelectorAll('.adm-user-edit').forEach(b =>
      b.addEventListener('click', () => userDialog(panel, b.dataset.u)));
    panel.querySelectorAll('.adm-user-del').forEach(b =>
      b.addEventListener('click', async () => {
        if (!confirm(`¿Eliminar al usuario "${b.dataset.u}"?`)) return;
        const r = window.Auth.deleteUser(b.dataset.u);
        if (!r.ok) window.State?.toast(r.error, 'error');
        else { window.State?.toast('✓ Usuario eliminado', 'ok'); window.render_admin(panel); }
      }));

    // Permisos por rol (checkbox)
    panel.querySelectorAll('.adm-perm').forEach(cb =>
      cb.addEventListener('change', () => {
        const rol = cb.dataset.rol, tab = cb.dataset.tab;
        const perms = getPerms();
        if (!perms[rol]) perms[rol] = [];
        if (cb.checked) { if (!perms[rol].includes(tab)) perms[rol].push(tab); }
        else { perms[rol] = perms[rol].filter(t => t !== tab); }
        savePerms();
        document.dispatchEvent(new CustomEvent('rb:auth-changed'));
      }));

    // Nuevo rol
    panel.querySelector('#adm-role-new')?.addEventListener('click', () => {
      const nombre = prompt('Nombre del nuevo rol (ej. enfermería, recepción):');
      if (!nombre) return;
      const rol = nombre.trim().toLowerCase();
      if (!rol || rol === 'admin') { window.State?.toast('Nombre inválido', 'error'); return; }
      const perms = getPerms();
      if (!perms[rol]) perms[rol] = ['dashboard'];
      savePerms();
      window.render_admin(panel);
    });
    panel.querySelectorAll('.adm-role-del').forEach(b =>
      b.addEventListener('click', () => {
        if (!confirm(`¿Eliminar el rol "${b.dataset.r}"? Los usuarios con ese rol quedarán sin permisos definidos.`)) return;
        const perms = getPerms();
        delete perms[b.dataset.r];
        savePerms();
        window.render_admin(panel);
      }));

    // Herramientas
    panel.querySelector('#adm-go-config')?.addEventListener('click', () => window.App?.activateTab('dashboard'));
    panel.querySelector('#adm-backup-exp')?.addEventListener('click', () => window.Backup?.exportAll());
    panel.querySelector('#adm-backup-imp')?.addEventListener('click', () => window.Backup?.importAll());
    panel.querySelector('#adm-order')?.addEventListener('click', () => window.openTabOrderManager?.());
    panel.querySelector('#adm-users-exp')?.addEventListener('click', () => window.Auth?.exportUsers?.());
    panel.querySelector('#adm-users-imp')?.addEventListener('click', () => window.Auth?.importUsers?.());
    panel.querySelector('#adm-gen-server')?.addEventListener('click', () => window.Backup?.generarArchivosServidor?.());
    panel.querySelector('#adm-audit-clear')?.addEventListener('click', () => {
      if (!confirm('¿Limpiar todo el registro de actividad?')) return;
      window.Auth.clearAuditLog(); window.render_admin(panel);
    });
  }

  function userDialog(panel, username) {
    if (!window.ModalEditor) return;
    const editing = !!username;
    const u = editing ? (window.Auth.listUsers().find(x => x.username === username) || {}) : {};
    const roles = getRoles();
    window.ModalEditor.open({
      title: editing ? `Editar usuario: ${username}` : 'Nuevo usuario',
      schema: [
        { key: 'username', label: 'Usuario (login)', type: 'text', required: !editing,
          help: editing ? 'No se puede cambiar el nombre de usuario' : 'Sin espacios' },
        { key: 'display', label: 'Nombre para mostrar', type: 'text' },
        { key: 'role', label: 'Rol', type: 'select',
          options: roles.map(r => ({ value: r, label: r })), allowEmpty: false, default: u.role || 'editor' },
        { key: 'password', label: editing ? 'Nueva contraseña (dejar vacío = no cambiar)' : 'Contraseña',
          type: 'text', required: !editing },
      ],
      data: { username: u.username || '', display: u.display || '', role: u.role || 'editor', password: '' },
      onSave: async (data) => {
        let r;
        if (editing) {
          r = await window.Auth.updateUser(username, { password: data.password, role: data.role, display: data.display });
        } else {
          r = await window.Auth.createUser({ username: data.username.trim(), password: data.password, role: data.role, display: data.display });
        }
        if (!r.ok) { window.State?.toast(r.error, 'error'); return; }
        window.State?.toast('✓ Guardado', 'ok');
        window.render_admin(panel);
      },
    });
  }

  // Mantener compatibilidad con el antiguo openRoleManager (abre la pestaña admin)
  function openRoleManager() { window.App?.activateTab('admin'); }

  window.Roles = { isTabAllowed, openRoleManager, ALL_TABS, getRoles };
  window.openRoleManager = openRoleManager;
})();
