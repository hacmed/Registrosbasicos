/* ============================================================================
   announcement.js — Anuncio flotante al cargar la app

   El admin configura desde ⚙️ Configuración del Dashboard:
     - activo: on/off
     - titulo, mensaje, imagen (URL), link (URL), textoBoton
     - frecuencia: 'always' | 'daily' | 'version'
   Se guarda en DB_AGENDA.announcement (persiste en localStorage vía agenda_data).

   Frecuencias:
     - always:  se muestra cada vez que carga la app
     - daily:   una vez al día
     - version: solo cuando cambia el contenido del anuncio (hash simple)
   ============================================================================ */
(function () {
  'use strict';

  const SEEN_KEY = 'rb_announcement_seen_v1';

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  function getConfig() {
    const agenda = window.DB_AGENDA;
    return (agenda && agenda.announcement) || null;
  }

  // Hash simple del contenido para la frecuencia 'version'
  function contentHash(cfg) {
    const s = `${cfg.titulo}|${cfg.mensaje}|${cfg.imagen}|${cfg.link}`;
    let h = 0;
    for (let i = 0; i < s.length; i++) { h = ((h << 5) - h + s.charCodeAt(i)) | 0; }
    return String(h);
  }

  function shouldShow(cfg) {
    if (!cfg || !cfg.activo) return false;
    if (!cfg.titulo && !cfg.mensaje && !cfg.imagen) return false;

    let seen = {};
    try { seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '{}'); } catch (e) {}

    const freq = cfg.frecuencia || 'always';
    if (freq === 'always') return true;
    if (freq === 'daily') {
      const today = new Date().toISOString().slice(0, 10);
      return seen.lastDay !== today;
    }
    if (freq === 'version') {
      return seen.lastHash !== contentHash(cfg);
    }
    return true;
  }

  function markSeen(cfg) {
    let seen = {};
    try { seen = JSON.parse(localStorage.getItem(SEEN_KEY) || '{}'); } catch (e) {}
    seen.lastDay = new Date().toISOString().slice(0, 10);
    seen.lastHash = contentHash(cfg);
    try { localStorage.setItem(SEEN_KEY, JSON.stringify(seen)); } catch (e) {}
  }

  // Detecta si un URL es imagen directa
  function isImageUrl(url) {
    return /\.(png|jpe?g|gif|webp|svg)(\?|$)/i.test(url || '');
  }
  // Detecta YouTube y devuelve el id
  function youtubeId(url) {
    const m = String(url || '').match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([\w-]{11})/);
    return m ? m[1] : null;
  }

  function render(cfg, opts = {}) {
    const preview = opts.preview;
    document.getElementById('rb-announcement')?.remove();

    const yt = youtubeId(cfg.imagen) || youtubeId(cfg.link);
    const hasLink = !!cfg.link;

    let media = '';
    if (yt) {
      media = `<div class="rb-ann-media"><iframe width="100%" height="220" src="https://www.youtube.com/embed/${esc(yt)}" frameborder="0" allowfullscreen></iframe></div>`;
    } else if (isImageUrl(cfg.imagen)) {
      // La imagen ES el botón: al hacer click lleva al destino (si hay link)
      if (hasLink) {
        media = `<a href="${esc(cfg.link)}" target="_blank" rel="noopener noreferrer" class="rb-ann-media rb-ann-media-link" title="Abrir enlace">
          <img src="${esc(cfg.imagen)}" alt="" loading="lazy"/>
        </a>`;
      } else {
        media = `<div class="rb-ann-media"><img src="${esc(cfg.imagen)}" alt="" loading="lazy"/></div>`;
      }
    }

    // Si no hay imagen pero sí link, el título/mensaje son clickeables
    const bodyClickable = (!isImageUrl(cfg.imagen) && !yt && hasLink);

    const overlay = document.createElement('div');
    overlay.id = 'rb-announcement';
    overlay.className = 'rb-ann-overlay';
    overlay.innerHTML = `
      <div class="rb-ann-modal" role="dialog" aria-modal="true">
        <button class="rb-ann-close" aria-label="Cerrar">✕</button>
        ${media}
        ${(cfg.titulo || cfg.mensaje) ? `
          <div class="rb-ann-body ${bodyClickable ? 'rb-ann-body-link' : ''}" ${bodyClickable ? `data-link="${esc(cfg.link)}"` : ''}>
            ${cfg.titulo ? `<h2 class="rb-ann-title">${esc(cfg.titulo)}</h2>` : ''}
            ${cfg.mensaje ? `<p class="rb-ann-msg">${esc(cfg.mensaje)}</p>` : ''}
            ${bodyClickable ? '<span class="rb-ann-cta">Toca para abrir →</span>' : ''}
            ${preview ? '<p class="tiny muted" style="margin-top:8px;">— Vista previa —</p>' : ''}
          </div>
        ` : ''}
      </div>
    `;
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    overlay.querySelector('.rb-ann-close')?.addEventListener('click', close);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    // Cuerpo clickeable lleva al link
    const bodyLink = overlay.querySelector('.rb-ann-body-link');
    if (bodyLink) {
      bodyLink.style.cursor = 'pointer';
      bodyLink.addEventListener('click', () => window.open(bodyLink.dataset.link, '_blank', 'noopener'));
    }

    if (!preview) markSeen(cfg);
  }

  // API pública: mostrar si corresponde
  window.showAnnouncement = function () {
    const cfg = getConfig();
    if (shouldShow(cfg)) render(cfg);
  };
  // API: forzar preview (para el editor del admin)
  window.previewAnnouncement = function (cfg) {
    render(cfg, { preview: true });
  };
})();
