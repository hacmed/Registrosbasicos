/* ============================================================================
   app.js — Bootstrap principal
   - Define las 9 tabs / módulos
   - Carga progresiva: BD básica al inicio (vademécum + pai + vigilancia),
     patologías solo cuando se entra a Módulo 6.
   - Inicializa el buscador omnipotente
   ============================================================================ */
(function () {
  'use strict';

  // === Definición de módulos ================================================
  const MODULES = [
    { id: 'dashboard',  num: '01', label: 'Inicio',       deps: [] },
    { id: 'nutricion',  num: '02', label: 'Nutrición',    deps: ['lms'] },
    { id: 'gestante',   num: '03', label: 'Gestante',     deps: [] },
    { id: 'vademecum',  num: '04', label: 'Vademécum',    deps: ['vademecum'] },
    { id: 'agenda',     num: '05', label: 'Agenda',       deps: [], adminOnly: true },
    { id: 'clinica',    num: '06', label: 'Clínica',      deps: ['patologias'] },
    { id: 'pai-vigil',  num: '07', label: 'PAI / Vigilancia', deps: ['pai', 'vigilancia'] },
    { id: 'suppv-bja',  num: '08', label: 'SUPPV / BJA',  deps: [] },
    { id: 'enlaces',    num: '09', label: 'Enlaces',      deps: [] },
    { id: 'seguimiento',num: '10', label: 'Seguimiento Gestante', deps: [] },
    { id: 'admin',      num: '⚙',  label: 'Administración', deps: [], adminOnly: true },
  ];

  const DB_FILES = {
    patologias: { var: 'DB_PATOLOGIAS', src: 'data/db_patologias.js' },
    vademecum:  { var: 'DB_VADEMECUM',  src: 'data/db_vademecum.js' },
    pai:        { var: 'DB_PAI',        src: 'data/db_pai.js' },
    vigilancia: { var: 'DB_VIGILANCIA', src: 'data/db_vigilancia.js' },
    lms:        { var: 'DB_LMS',        src: 'data/db_lms.js' },
    dosis_ped:  { var: 'DB_DOSIS_PED',  src: 'data/db_dosis_pediatricas.js' },
  };

  // === Carga de BD ==========================================================
  const dbLoaded = {};
  async function ensureDB(name) {
    if (dbLoaded[name]) return window[DB_FILES[name].var];
    const cfg = DB_FILES[name];
    if (!cfg) throw new Error(`BD desconocida: ${name}`);
    try {
      await window.State.loadScript(cfg.src);
      dbLoaded[name] = true;
      // Reindexar buscador con la nueva BD
      reindexSearch();
      return window[cfg.var];
    } catch (e) {
      window.State.toast(`Error cargando ${cfg.src}`, 'error', 5000);
      throw e;
    }
  }

  function reindexSearch() {
    if (!window.Search) return;
    window.Search.buildIndex({
      patologias: window.DB_PATOLOGIAS?.patologias,
      vademecum:  window.DB_VADEMECUM?.vademecum,
      pai:        window.DB_PAI?.pai,
      vigilancia: window.DB_VIGILANCIA?.vigilancia,
    });
  }

  // === Ruteo de tabs ========================================================
  async function activateTab(id) {
    const mod = MODULES.find(m => m.id === id);
    if (!mod) return;

    // Guard: si la pestaña no está permitida para el rol actual, redirigir
    if (mod.adminOnly && !window.Auth?.isAdmin()) { id = 'dashboard'; }
    if (window.Roles && !window.Roles.isTabAllowed(id)) { id = 'dashboard'; }
    const mod2 = MODULES.find(m => m.id === id) || mod;

    // Botones
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.setAttribute('aria-selected', btn.dataset.tab === id ? 'true' : 'false');
    });
    // Paneles
    document.querySelectorAll('.tab-panel').forEach(p => {
      p.classList.toggle('is-active', p.dataset.panel === id);
    });
    window.State.setActiveTab(id);

    // Cargar dependencias necesarias
    for (const dep of mod2.deps) {
      if (!dbLoaded[dep]) {
        const panel = document.querySelector(`.tab-panel[data-panel="${id}"]`);
        if (panel && !panel.dataset.loaded) {
          panel.innerHTML = `<div class="empty-state"><div class="skel" style="height:200px"></div></div>`;
        }
        try { await ensureDB(dep); } catch (e) { return; }
      }
    }

    // Renderizar contenido (si el módulo definió un renderer)
    const renderer = window[`render_${id.replace(/-/g, '_')}`];
    const panel = document.querySelector(`.tab-panel[data-panel="${id}"]`);
    if (renderer && panel) {
      await renderer(panel);
      panel.dataset.loaded = '1';
    } else if (panel && !panel.dataset.loaded) {
      panel.innerHTML = renderPlaceholder(mod2);
      panel.dataset.loaded = '1';
    }
  }

  function renderPlaceholder(mod) {
    return `
      <div class="empty-state">
        <div class="empty-state-title">Módulo ${mod.num} · ${mod.label}</div>
        <p>Este módulo aún no tiene contenido implementado.</p>
        <p class="tiny mt-2">Se construirá en una fase posterior según el plan.</p>
      </div>`;
  }

  // === Construcción del header & nav ========================================
  function buildHeader() {
    const html = `
      <header class="app-header">
        <div class="app-header-inner">
          <div class="brand" id="brand-trigger" title="Registros Básicos">
            <div class="brand-mark">R</div>
            <div class="brand-text">
              <span class="brand-title">Registros Básicos</span>
              <span class="brand-sub">Sistema clínico</span>
            </div>
          </div>
          <div class="omni-search">
            <svg class="omni-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
            </svg>
            <input type="search" class="omni-input" id="omni-input"
                   placeholder="Buscar por CIE-10, patología, fármaco, vacuna…"
                   autocomplete="off" spellcheck="false" />
            <div class="omni-results" id="omni-results" role="listbox"></div>
          </div>
          <div id="auth-status" class="row gap-2"></div>
        </div>
      </header>

      <nav class="tab-rail">
        <div class="tab-rail-inner" id="tab-rail"></div>
      </nav>

      <main class="app-main" id="app-main">
        ${MODULES.map(m => `
          <section class="tab-panel" data-panel="${m.id}" role="tabpanel"></section>
        `).join('')}
      </main>

      <footer style="max-width:1280px;margin:48px auto 32px;padding:0 16px;color:var(--ink-mute);font-size:0.78rem;text-align:center;">
        <p><span id="rb-version-trigger" style="cursor:default;user-select:none;-webkit-user-select:none;">Registros Básicos · v2.6.2</span></p>
        <p class="tiny" style="margin-top:4px;">Desarrollado por <strong>HACMED</strong></p>
        <button id="rb-force-update" class="btn btn-ghost" style="margin-top:10px;font-size:0.75rem;padding:4px 12px;">🔄 Forzar actualización (limpiar caché)</button>
      </footer>
    `;
    document.body.insertAdjacentHTML('afterbegin', html);

    // Acceso admin alternativo (móvil-friendly): 3 toques en la versión del footer
    (function () {
      let n = 0, t = null, last = 0;
      const trig = document.getElementById('rb-version-trigger');
      if (trig) {
        const handler = () => {
          if (window.Auth?.isAdmin?.()) return;
          const now = Date.now();
          if (now - last > 1500) n = 0;
          last = now; n++;
          clearTimeout(t); t = setTimeout(() => { n = 0; }, 1600);
          if (n >= 3) { n = 0; clearTimeout(t); window.Auth?.gateAdmin?.(() => {}); }
        };
        trig.addEventListener('click', handler);
        trig.addEventListener('touchend', (e) => { e.preventDefault(); handler(); });
      }
    })();

    // Botón de actualización forzada: limpia todos los caches y recarga
    document.getElementById('rb-force-update')?.addEventListener('click', async () => {
      try {
        if ('caches' in window) {
          const names = await caches.keys();
          await Promise.all(names.map(n => caches.delete(n)));
        }
        if ('serviceWorker' in navigator) {
          const regs = await navigator.serviceWorker.getRegistrations();
          await Promise.all(regs.map(r => r.unregister()));
        }
        window.State?.toast('Caché limpiado. Recargando...', 'ok', 1500);
        setTimeout(() => window.location.reload(true), 800);
      } catch (e) {
        window.location.reload(true);
      }
    });
  }

  // Devuelve los módulos ordenados según preferencia guardada del admin.
  function getOrderedModules() {
    const saved = window.State?.get('tab_order');  // array de ids
    if (!Array.isArray(saved) || !saved.length) return MODULES.slice();
    const byId = {};
    MODULES.forEach(m => { byId[m.id] = m; });
    const ordered = [];
    saved.forEach(id => { if (byId[id]) { ordered.push(byId[id]); delete byId[id]; } });
    // Añadir cualquier módulo nuevo no presente en el orden guardado
    MODULES.forEach(m => { if (byId[m.id]) ordered.push(m); });
    return ordered;
  }

  function renderNav() {
    const rail = document.getElementById('tab-rail');
    if (!rail) return;
    const isAdmin = window.Auth?.isAdmin();
    // Filtrar por adminOnly Y por permisos de rol (anónimo), respetando orden
    const visibleModules = getOrderedModules().filter(m => {
      if (m.adminOnly && !isAdmin) return false;
      if (window.Roles && !window.Roles.isTabAllowed(m.id)) return false;
      return true;
    });
    rail.innerHTML = visibleModules.map(m => `
      <button class="tab-btn" data-tab="${m.id}" role="tab" aria-selected="false">
        <span class="tab-label">${m.label}</span>
      </button>`).join('');
    const current = window.State.getActiveTab();
    if (!visibleModules.find(m => m.id === current)) {
      activateTab('dashboard');
    }
    bindNav();
  }

  // Editor del orden de pestañas (admin) usando rank_priorities
  window.openTabOrderManager = function () {
    const ordered = getOrderedModules();
    // Usamos ask_user_input no está aquí; usamos ModalEditor con una lista ordenable simple
    if (!window.ModalEditor) { window.State?.toast('No disponible', 'error'); return; }
    // Representamos el orden como una lista editable de items con su posición
    window.ModalEditor.open({
      title: '↕️ Orden de pestañas',
      size: 'lg',
      schema: [
        { key: '_help', label: '', type: 'info',
          text: 'Escribe un número de orden para cada pestaña (menor = más a la izquierda). La pestaña Inicio normalmente va primera. Guarda para aplicar.' },
        ...ordered.map((m, i) => ({
          key: 'ord_' + m.id,
          label: `${m.label}`,
          type: 'number',
          default: i + 1,
        })),
      ],
      data: Object.fromEntries(ordered.map((m, i) => ['ord_' + m.id, i + 1])),
      onSave: (data) => {
        const withOrder = ordered.map(m => ({ id: m.id, ord: parseInt(data['ord_' + m.id]) || 99 }));
        withOrder.sort((a, b) => a.ord - b.ord);
        window.State.set('tab_order', withOrder.map(x => x.id));
        window.Auth?.audit('reorder_tabs', withOrder.map(x => x.id).join(','));
        window.State?.toast('✓ Orden actualizado', 'ok');
        renderNav();
      },
    });
  };

  function bindNav() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
      // Evitar doble bind
      btn.replaceWith(btn.cloneNode(true));
    });
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => activateTab(btn.dataset.tab));
    });
    // Re-marcar la activa
    const current = window.State.getActiveTab();
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.setAttribute('aria-selected', btn.dataset.tab === current ? 'true' : 'false');
    });
  }

  // === Manejo de resultados de búsqueda → activar tab y scroll ============
  document.addEventListener('rb:search-select', async (e) => {
    const item = e.detail;
    const targetMap = {
      patologia: 'clinica',
      farmaco: 'vademecum',
      vacuna: 'pai-vigil',
      vigilancia: 'pai-vigil',
    };
    const targetTab = targetMap[item.kind];
    if (targetTab) {
      await activateTab(targetTab);
      // El módulo destino escucha este evento para hacer scroll/highlight
      document.dispatchEvent(new CustomEvent(`rb:focus-${item.kind}`, { detail: item }));
    }
    document.getElementById('omni-input').value = '';
    document.getElementById('omni-results').classList.remove('is-open');
  });

  // === Inicialización ======================================================
  async function bootstrap() {
    buildHeader();
    renderNav();

    // Bind buscador
    window.Search?.bindInput(
      document.getElementById('omni-input'),
      document.getElementById('omni-results')
    );

    // Re-renderizar nav cuando cambia sesión (admin login/logout)
    document.addEventListener('rb:auth-changed', () => {
      renderNav();
      // Si la pestaña actual ya no es accesible (ej. se cerró admin estando en Agenda),
      // redirigir al dashboard.
      const current = window.State.getActiveTab();
      const mod = MODULES.find(m => m.id === current);
      const isAdmin = window.Auth?.isAdmin();
      const allowed = mod && (!mod.adminOnly || isAdmin) && (!window.Roles || window.Roles.isTabAllowed(current));
      if (!allowed) {
        activateTab('dashboard');
      } else {
        // Re-renderizar la pestaña actual para reflejar permisos (botones admin)
        const panel = document.querySelector(`.tab-panel[data-panel="${current}"]`);
        if (panel) { panel.dataset.loaded = ''; activateTab(current); }
      }
    });

    // Carga inicial: solo las BD ligeras (vademécum, pai, vigilancia, dosis ped)
    // Patologías (1.9 MB) se carga al entrar a Módulo 6
    const splashMsg = document.getElementById('rb-splash-msg');
    if (splashMsg) splashMsg.textContent = 'Cargando bases de datos…';
    try {
      await Promise.all([
        ensureDB('vademecum'),
        ensureDB('pai'),
        ensureDB('vigilancia'),
        ensureDB('dosis_ped'),
      ]);
      window.State.toast(`Sistema listo · ${window.Search.stats().items} entradas indexadas`, 'ok', 2500);
    } catch (e) {
      console.error('[bootstrap] error cargando BD', e);
    }

    // Activar la tab guardada (o dashboard por defecto)
    if (splashMsg) splashMsg.textContent = 'Listo';
    const initial = window.State.getActiveTab();
    const isAdmin = window.Auth?.isAdmin();
    const initialValid = MODULES.find(m => m.id === initial && (!m.adminOnly || isAdmin));
    await activateTab(initialValid ? initial : 'dashboard');

    // Ocultar splash
    const splash = document.getElementById('rb-splash');
    if (splash) {
      splash.classList.add('is-hidden');
      setTimeout(() => splash.remove(), 500);
    }

    // Mostrar anuncio flotante si el admin lo configuró
    setTimeout(() => { if (window.showAnnouncement) window.showAnnouncement(); }, 700);
  }

  document.addEventListener('DOMContentLoaded', bootstrap);

  // Exportar para uso de módulos
  window.App = {
    activateTab,
    ensureDB,
    MODULES,
  };
})();
