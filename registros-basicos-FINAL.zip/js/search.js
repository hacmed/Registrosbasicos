/* ============================================================================
   search.js — Motor de búsqueda omnipotente
   Estrategia en cascada (corta circuita):
     1. CIE-10 exacto         (Map → O(1))
     2. Prefijo del nombre    (Map de tokens → O(1))
     3. Fuzzy (Fuse.js)       (solo si los anteriores fallan)
   Indexa: patologías, fármacos, vacunas (PAI), protocolos epidemiológicos.
   Debounce 220ms para no bloquear el thread en cada keystroke.
   ============================================================================ */
(function () {
  'use strict';

  const DEBOUNCE_MS = 220;
  const MAX_RESULTS_PER_GROUP = 8;

  // === Estado interno =======================================================
  let indices = {
    cie10: new Map(),        // CIE-10 → [{kind, id, title, sub}]
    prefix: new Map(),       // token de 2+ chars → Set de items
    items: [],               // todos los items indexados (para Fuse)
  };
  let fuseInstance = null;
  let isReady = false;
  let pendingTimer = null;

  // === Utilidades ===========================================================
  function normalize(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, ''); // strip acentos
  }

  function tokens(s) {
    return normalize(s)
      .split(/[^a-z0-9]+/)
      .filter(t => t.length >= 2);
  }

  function highlight(text, query) {
    if (!query || !text) return escapeHtml(text);
    const nq = normalize(query);
    const nt = normalize(text);
    const idx = nt.indexOf(nq);
    if (idx < 0) return escapeHtml(text);
    return escapeHtml(text.slice(0, idx))
      + '<mark class="hl">' + escapeHtml(text.slice(idx, idx + query.length)) + '</mark>'
      + escapeHtml(text.slice(idx + query.length));
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  // === Indexación ===========================================================
  function addItem(item) {
    indices.items.push(item);
    // CIE-10
    if (item.cie10) {
      for (const c of item.cie10) {
        const key = c.toUpperCase();
        if (!indices.cie10.has(key)) indices.cie10.set(key, []);
        indices.cie10.get(key).push(item);
      }
    }
    // Tokens del título (prefix index)
    const allTokens = tokens(item.title + ' ' + (item.sub || ''));
    for (const tok of allTokens) {
      // indexamos prefijos de longitud 2-8 para búsqueda incremental
      for (let len = 2; len <= Math.min(tok.length, 8); len++) {
        const pfx = tok.slice(0, len);
        if (!indices.prefix.has(pfx)) indices.prefix.set(pfx, new Set());
        indices.prefix.get(pfx).add(item);
      }
    }
  }

  function buildIndex({ patologias, vademecum, pai, vigilancia }) {
    console.time('[search] index build');
    indices = { cie10: new Map(), prefix: new Map(), items: [] };

    if (patologias) {
      for (const p of patologias) {
        addItem({
          kind: 'patologia',
          id: p.id,
          title: p.nombre,
          sub: p.especialidad || '',
          cie10: p.cie10 || [],
          ref: p,
        });
      }
    }
    if (vademecum) {
      for (const f of vademecum) {
        addItem({
          kind: 'farmaco',
          id: f.id,
          title: f.medicamento,
          sub: [f.forma, f.concentracion].filter(Boolean).join(' · '),
          cie10: [],
          ref: f,
        });
      }
    }
    if (pai) {
      for (const v of pai) {
        addItem({
          kind: 'vacuna',
          id: v.id,
          title: v.vacuna,
          sub: v.tipo || '',
          cie10: [],
          ref: v,
        });
      }
    }
    if (vigilancia) {
      for (const e of vigilancia) {
        addItem({
          kind: 'vigilancia',
          id: e.id,
          title: e.patologia,
          sub: 'Vigilancia epidemiológica',
          cie10: [],
          ref: e,
        });
      }
    }

    // Construir Fuse para fuzzy fallback (solo si Fuse está disponible)
    if (window.Fuse) {
      fuseInstance = new window.Fuse(indices.items, {
        keys: [
          { name: 'title', weight: 2 },
          { name: 'sub',   weight: 1 },
        ],
        threshold: 0.4,
        ignoreLocation: true,
        minMatchCharLength: 3,
        includeScore: true,
      });
    }
    isReady = true;
    console.timeEnd('[search] index build');
    console.log(`[search] indexado: ${indices.items.length} items, ${indices.cie10.size} CIE-10, ${indices.prefix.size} prefijos`);
  }

  // === Búsqueda en cascada ==================================================
  function search(query) {
    if (!isReady) return { groups: {}, total: 0, took: 0 };
    const t0 = performance.now();
    const q = query.trim();
    if (!q) return { groups: {}, total: 0, took: 0 };

    const seen = new Set();
    const results = [];

    // 1. CIE-10 exacto (case-insensitive, 1-3 letras + dígitos)
    const cieMatch = q.toUpperCase().match(/^[A-Z]\d[0-9.]*$/);
    if (cieMatch) {
      const code = q.toUpperCase().replace(/\./g, '');
      // exact
      const hits = indices.cie10.get(code) || [];
      for (const it of hits) {
        if (!seen.has(it.id)) { seen.add(it.id); results.push({ ...it, matchType: 'cie10' }); }
      }
      // prefix: si buscan "B69", también traer B690, B691...
      if (results.length < MAX_RESULTS_PER_GROUP * 3) {
        for (const [k, items] of indices.cie10) {
          if (k !== code && k.startsWith(code)) {
            for (const it of items) {
              if (!seen.has(it.id)) { seen.add(it.id); results.push({ ...it, matchType: 'cie10' }); }
            }
          }
        }
      }
    }

    // 2. Prefijo de nombre (cualquier token del query)
    if (results.length < 20) {
      const qToks = tokens(q);
      // Estrategia: buscar items que contengan TODOS los tokens del query
      // (intersección de sets para múltiples palabras)
      let candidates = null;
      for (const tok of qToks) {
        const pfx = tok.slice(0, Math.min(tok.length, 8));
        const matches = indices.prefix.get(pfx);
        if (!matches) { candidates = new Set(); break; }
        if (candidates === null) candidates = new Set(matches);
        else {
          const next = new Set();
          for (const m of candidates) if (matches.has(m)) next.add(m);
          candidates = next;
        }
        if (candidates.size === 0) break;
      }
      if (candidates) {
        for (const it of candidates) {
          if (!seen.has(it.id)) { seen.add(it.id); results.push({ ...it, matchType: 'prefix' }); }
        }
      }
    }

    // 3. Fuzzy fallback (solo si seguimos sin suficientes resultados)
    if (results.length < 8 && fuseInstance) {
      const fuzzyHits = fuseInstance.search(q, { limit: 20 });
      for (const h of fuzzyHits) {
        if (!seen.has(h.item.id)) {
          seen.add(h.item.id);
          results.push({ ...h.item, matchType: 'fuzzy', score: h.score });
        }
      }
    }

    // Agrupar por kind y limitar
    const groups = {};
    for (const r of results) {
      if (!groups[r.kind]) groups[r.kind] = [];
      if (groups[r.kind].length < MAX_RESULTS_PER_GROUP) groups[r.kind].push(r);
    }

    return {
      groups,
      total: results.length,
      took: Math.round(performance.now() - t0),
    };
  }

  // === Renderizado del dropdown ============================================
  const GROUP_LABELS = {
    patologia:  { label: 'Patologías',                       icon: '⚕' },
    farmaco:    { label: 'Vademécum (fármacos)',             icon: '℞' },
    vacuna:     { label: 'Vacunas (PAI)',                    icon: '💉' },
    vigilancia: { label: 'Vigilancia epidemiológica',        icon: '⚠' },
  };

  function renderResults(query, results, containerEl) {
    if (!query.trim()) { containerEl.classList.remove('is-open'); containerEl.innerHTML = ''; return; }

    if (results.total === 0) {
      containerEl.innerHTML = `
        <div class="omni-empty">
          <p>Sin resultados para <strong>${escapeHtml(query)}</strong></p>
          <p class="tiny mt-2 muted">
            Sugerencias: revisa la ortografía, prueba con el código CIE-10
            o usa el nombre genérico del fármaco.
          </p>
        </div>`;
      containerEl.classList.add('is-open');
      return;
    }

    let html = '';
    for (const [kind, items] of Object.entries(results.groups)) {
      const meta = GROUP_LABELS[kind] || { label: kind, icon: '' };
      html += `<div class="omni-group-h">${meta.icon} ${meta.label}</div>`;
      for (const it of items) {
        const cieBadge = (it.cie10 && it.cie10.length)
          ? `<span class="badge badge-cie">${it.cie10[0]}</span>` : '';
        const matchHint = it.matchType === 'fuzzy' ? '<span class="badge badge-mute" title="Coincidencia aproximada">≈</span>' : '';
        html += `
          <a class="omni-item" href="#" data-kind="${it.kind}" data-id="${it.id}">
            <div class="omni-item-title">${highlight(it.title, query)}</div>
            <div class="omni-item-meta">
              ${cieBadge}${matchHint}
              <span>${escapeHtml(it.sub || '')}</span>
            </div>
          </a>`;
      }
    }
    html += `<div class="omni-empty tiny">${results.total} resultado(s) · ${results.took} ms</div>`;
    containerEl.innerHTML = html;
    containerEl.classList.add('is-open');

    // Click handlers
    containerEl.querySelectorAll('.omni-item').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        const kind = el.dataset.kind;
        const id   = el.dataset.id;
        const item = indices.items.find(x => x.id === id && x.kind === kind);
        if (item) {
          document.dispatchEvent(new CustomEvent('rb:search-select', { detail: item }));
        }
        containerEl.classList.remove('is-open');
      });
    });
  }

  // === Binding al input del header ==========================================
  function bindInput(inputEl, containerEl) {
    if (!inputEl || !containerEl) return;
    inputEl.addEventListener('input', () => {
      const q = inputEl.value;
      clearTimeout(pendingTimer);
      pendingTimer = setTimeout(() => {
        if (!isReady) {
          containerEl.innerHTML = '<div class="omni-empty">Cargando base de datos…</div>';
          containerEl.classList.add('is-open');
          return;
        }
        const r = search(q);
        renderResults(q, r, containerEl);
      }, DEBOUNCE_MS);
    });
    inputEl.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        inputEl.value = '';
        containerEl.classList.remove('is-open');
      }
    });
    // Click fuera → cerrar
    document.addEventListener('click', e => {
      if (!containerEl.contains(e.target) && e.target !== inputEl) {
        containerEl.classList.remove('is-open');
      }
    });
  }

  // === API pública =========================================================
  window.Search = {
    buildIndex,
    search,
    bindInput,
    isReady: () => isReady,
    stats: () => ({
      items: indices.items.length,
      cie10: indices.cie10.size,
      prefix: indices.prefix.size,
    }),
  };
})();
