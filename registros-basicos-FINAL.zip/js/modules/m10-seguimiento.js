/* ============================================================================
   m10-seguimiento.js — Módulo 10: Seguimiento Gestante (3 trimestres)

   Clon extendido de M3 con:
     - Cabecera única por paciente (CUS/CI/HC, nombre, antecedentes, FUM, etc.)
     - 3 controles trimestrales (Trim I, II, III) con datos antropométricos,
       laboratorio, ecografía, notas, plan, factores de riesgo
     - Bloque postparto (opcional)
     - Gráficas de evolución: peso sobre IOM, TA, altura uterina CLAP, Hb
     - Export/Import JSON (sin localStorage por privacidad)

   IMPORTANTE: NO modifica las fórmulas obstétricas existentes ni los cálculos
   de M3. Reutiliza window.Obstetric.* tal cual.
   ============================================================================ */
(function () {
  'use strict';

  // === Esquema del paciente =================================================
  function emptyPatient() {
    return {
      _meta: {
        version: '1.0',
        creado: new Date().toISOString(),
        actualizado: new Date().toISOString(),
      },
      // Cabecera (una sola vez)
      cabecera: {
        tipoDoc: 'CUS',      // 'CUS' | 'CI' | 'HC'
        numDoc: '',
        nombre: '',
        apellido: '',
        edad: null,
        telefono: '',
        direccion: '',
        fum: '',             // ISO 'YYYY-MM-DD'
        ciclo: 28,
        fpp: '',             // FPP por ecografía directa (opcional)
        talla: null,         // cm
        pesoPre: null,       // kg
        embarazoMultiple: false,
        antecedentes: {
          gestas: 0, paras: 0, cesareas: 0, abortos: 0, mortinatos: 0,
          notas: '',
        },
        factoresRiesgo: [],  // array de strings (HTA, DM, infección, etc.)
      },
      // Controles trimestrales
      controles: [
        emptyControl(1),
        emptyControl(2),
        emptyControl(3),
      ],
      // Postparto (opcional)
      postparto: {
        completado: false,
        fecha: '',
        viaParto: '',         // 'vaginal' | 'cesárea' | 'instrumentado'
        pesoRN: null,         // kg
        tallaRN: null,        // cm
        apgar1: null,
        apgar5: null,
        complicaciones: '',
        lactancia: '',        // 'exclusiva' | 'mixta' | 'fórmula'
        notas: '',
      },
    };
  }

  function emptyControl(trimestre) {
    return {
      trimestre,
      fecha: '',
      eg: null,           // calculada al render
      // Antropometría
      peso: null, talla: null, ta_sistolica: null, ta_diastolica: null, pulso: null,
      // Examen obstétrico
      au: null, fcf: null, movimientos: '', presentacion: '',
      // Laboratorio
      hb: null, hto: null, glicemia: null, ego: '', vdrl: '', vih: '',
      laboratorio_otros: '',
      // Ecografía
      eco_fecha: '', eco_sg: null, eco_bpd: null, eco_cc: null, eco_ca: null,
      eco_lf: null, eco_peso_fetal: null, eco_liquido: '', eco_placenta: '',
      eco_notas: '',
      // Notas y plan
      notas: '',
      plan: '',
      factoresRiesgo: [],
      // Diagnósticos del trimestre: [{ dx, fecha, nota }]
      diagnosticos: [],
    };
  }

  // Factores de riesgo más comunes (checkboxes en cabecera y en cada control)
  const FACTORES_RIESGO = [
    'Hipertensión gestacional', 'Preeclampsia', 'Diabetes gestacional',
    'Anemia (<11 g/dL)', 'Infección urinaria', 'ITS (sífilis/VIH)',
    'Antecedente de aborto', 'Antecedente de cesárea', 'Antecedente de preeclampsia',
    'Embarazo en adolescente (<18a)', 'Embarazo añoso (≥35a)',
    'Tabaquismo', 'Alcoholismo', 'Drogas',
    'Talla baja (<1.45m)', 'Obesidad pregestacional',
    'Hemorragia del embarazo', 'Amenaza de parto prematuro',
    'RPM', 'Oligohidramnios', 'Polihidramnios',
    'RCIU sospechoso', 'Macrosomía sospechosa', 'Otros',
  ];

  // Diagnósticos frecuentes en el embarazo (con opción "Otro")
  const DIAGNOSTICOS_FRECUENTES = [
    'Infección urinaria (ITU)',
    'Bacteriuria asintomática',
    'Hiperémesis gravídica',
    'Amenaza de aborto',
    'Hemorragia del primer trimestre',
    'Hemorragia del tercer trimestre',
    'Hipertensión gestacional',
    'Preeclampsia',
    'Eclampsia',
    'Diabetes gestacional',
    'Anemia gestacional',
    'Amenaza de parto pretérmino',
    'Ruptura prematura de membranas (RPM)',
    'Restricción del crecimiento intrauterino (RCIU)',
    'Oligohidramnios',
    'Polihidramnios',
    'Placenta previa',
    'Vaginosis / candidiasis',
    'Sífilis gestacional',
    'Colestasis intrahepática',
    'Otro (especificar)',
  ];

  // Opciones para dropdowns clínicos
  const OPC = {
    movimientos:  ['Presentes', 'Disminuidos', 'Ausentes', 'No valorable'],
    presentacion: ['Cefálica', 'Pélvica', 'Transversa', 'Oblicua', 'No determinada'],
    liquido:      ['Normal', 'Oligohidramnios', 'Polihidramnios', 'No valorado'],
    serologia:    ['No reactivo', 'Reactivo', 'Pendiente', 'No realizado'],
    ego:          ['Normal', 'Bacterias', 'Leucocitos', 'Nitritos +', 'Proteinuria', 'Otro'],
  };

  function selectOptions(arr, val) {
    return '<option value="">—</option>' + arr.map(o =>
      `<option value="${esc(o)}" ${o === val ? 'selected' : ''}>${esc(o)}</option>`
    ).join('');
  }

  // === Estado en memoria (sin localStorage) =================================
  const state = {
    patient: emptyPatient(),
    activeTab: 'cabecera',  // 'cabecera' | 'trim1' | 'trim2' | 'trim3' | 'postparto' | 'evolucion'
  };

  // === Utilidades ===========================================================
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso + 'T12:00:00Z');
      return new Intl.DateTimeFormat('es-BO', { day: '2-digit', month: 'short', year: 'numeric' }).format(d);
    } catch (e) { return iso; }
  }
  function todayISO() {
    const d = new Date();
    return d.toISOString().slice(0, 10);
  }

  // === Validación documento (CUS/CI/HC flexible) ============================
  function validateDoc(tipo, num) {
    const v = String(num || '').trim().toUpperCase().replace(/\s+/g, '');
    if (!v) return { ok: false, value: '', error: 'Documento requerido' };
    if (!/^[A-Z0-9]+$/.test(v)) return { ok: false, value: v, error: 'Solo letras y números' };
    if (v.length < 6) return { ok: false, value: v, error: 'Mínimo 6 caracteres' };
    if (v.length > 15) return { ok: false, value: v, error: 'Máximo 15 caracteres' };
    return { ok: true, value: v, error: null };
  }

  // === Render del shell del módulo ==========================================
  function renderShell(panel) {
    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Seguimiento Gestante</h1>
          <p class="muted small">3 controles trimestrales · CLAP/OPS · Sin almacenamiento local de pacientes</p>
        </div>
        <div class="row gap-2" style="flex-wrap:wrap;">
          <button class="btn btn-primary" id="m10-new">+ Nuevo paciente</button>
          <button class="btn btn-ghost" id="m10-load">📂 Cargar JSON</button>
          <button class="btn btn-ghost" id="m10-save">💾 Guardar JSON</button>
        </div>
      </div>

      <div class="m10-warn">
        🔒 <strong>Privacidad:</strong> los datos del paciente están solo en memoria.
        Al cerrar la pestaña se pierden si no los guardaste como JSON. No se almacena nada en este dispositivo.
      </div>

      <div id="m10-patient-summary"></div>

      <div class="m7-tabs" style="margin-top:var(--space-3);">
        <button class="m10-tab is-active" data-tab="cabecera">📝 Cabecera</button>
        <button class="m10-tab" data-tab="trim1">1° Trimestre</button>
        <button class="m10-tab" data-tab="trim2">2° Trimestre</button>
        <button class="m10-tab" data-tab="trim3">3° Trimestre</button>
        <button class="m10-tab" data-tab="postparto">👶 Postparto</button>
        <button class="m10-tab" data-tab="evolucion">📈 Evolución</button>
      </div>

      <div id="m10-content"></div>
    `;

    document.getElementById('m10-new')?.addEventListener('click', () => {
      if (anyDataEntered() && !window.confirm('Se perderán los datos no guardados del paciente actual. ¿Continuar?')) return;
      state.patient = emptyPatient();
      state.activeTab = 'cabecera';
      renderAll(panel);
    });
    document.getElementById('m10-save')?.addEventListener('click', () => saveJSON());
    document.getElementById('m10-load')?.addEventListener('click', () => loadJSON(panel));

    panel.querySelectorAll('.m10-tab').forEach(b => {
      b.addEventListener('click', () => {
        state.activeTab = b.dataset.tab;
        renderAll(panel);
      });
    });
  }

  function anyDataEntered() {
    const c = state.patient.cabecera;
    return !!(c.numDoc || c.nombre || c.fum);
  }

  function renderAll(panel) {
    panel.querySelectorAll('.m10-tab').forEach(b => {
      b.classList.toggle('is-active', b.dataset.tab === state.activeTab);
    });
    renderPatientSummary();
    renderContent(panel);
  }

  // === Resumen del paciente (encabezado fijo) ===============================
  function renderPatientSummary() {
    const out = document.getElementById('m10-patient-summary');
    if (!out) return;
    const c = state.patient.cabecera;
    if (!c.nombre && !c.numDoc) {
      out.innerHTML = '';
      return;
    }
    const O = window.Obstetric;
    const eg = c.fum ? O.calcEG(O.isoToDate(c.fum)) : null;
    out.innerHTML = `
      <div class="m10-summary">
        <div class="m10-summary-main">
          <strong>${esc(c.nombre)} ${esc(c.apellido)}</strong>
          <span class="badge badge-mute tiny mono">${esc(c.tipoDoc)} ${esc(c.numDoc)}</span>
          ${c.edad != null ? `<span class="muted small">· ${c.edad} años</span>` : ''}
          ${eg ? `<span class="badge badge-clinic">EG ${eg.weeks}s ${eg.days}d</span>` : ''}
        </div>
        ${c.factoresRiesgo.length > 0 ? `
          <div class="m10-summary-risk">
            ⚠ ${c.factoresRiesgo.length} factor(es) de riesgo
          </div>
        ` : ''}
      </div>
    `;
  }

  // === Render del contenido según pestaña activa ============================
  function renderContent(panel) {
    const out = document.getElementById('m10-content');
    if (!out) return;
    switch (state.activeTab) {
      case 'cabecera':  return renderCabecera(out, panel);
      case 'trim1':     return renderControl(out, panel, 0);
      case 'trim2':     return renderControl(out, panel, 1);
      case 'trim3':     return renderControl(out, panel, 2);
      case 'postparto': return renderPostparto(out, panel);
      case 'evolucion': return renderEvolucion(out);
    }
  }

  // === Cabecera =============================================================
  function renderCabecera(out, panel) {
    const c = state.patient.cabecera;
    out.innerHTML = `
      <div class="card mt-4">
        <div class="card-h"><h2>Datos de la paciente</h2></div>
        <div class="m3-section">
          <h3 class="m3-sec-h">Identificación</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Tipo de documento</span>
              <select class="field-select" id="c-tipoDoc">
                <option value="CUS"${c.tipoDoc==='CUS'?' selected':''}>CUS — Código Único en Salud</option>
                <option value="CI"${c.tipoDoc==='CI'?' selected':''}>CI — Cédula de Identidad</option>
                <option value="HC"${c.tipoDoc==='HC'?' selected':''}>HC — Historia Clínica interna</option>
              </select>
            </label>
            <label class="field">
              <span class="field-label">Número (6-15 caracteres)</span>
              <input type="text" class="field-input" id="c-numDoc" value="${esc(c.numDoc)}"
                     placeholder="Ej: 12345678" maxlength="15" autocomplete="off" />
              <span class="tiny muted" id="c-numDoc-feedback"></span>
            </label>
            <label class="field">
              <span class="field-label">Nombre(s)</span>
              <input type="text" class="field-input" id="c-nombre" value="${esc(c.nombre)}" />
            </label>
            <label class="field">
              <span class="field-label">Apellido(s)</span>
              <input type="text" class="field-input" id="c-apellido" value="${esc(c.apellido)}" />
            </label>
            <label class="field">
              <span class="field-label">Edad (años)</span>
              <input type="number" class="field-input" id="c-edad" value="${c.edad != null ? c.edad : ''}" min="10" max="60" />
            </label>
            <label class="field">
              <span class="field-label">Teléfono</span>
              <input type="tel" class="field-input" id="c-telefono" value="${esc(c.telefono)}" placeholder="+591..." />
            </label>
          </div>
          <label class="field mt-2">
            <span class="field-label">Dirección</span>
            <input type="text" class="field-input" id="c-direccion" value="${esc(c.direccion)}" placeholder="Calle, zona, ciudad" />
          </label>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Fecha y datos del embarazo</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">FUM (último período menstrual)</span>
              <input type="date" class="field-input" id="c-fum" value="${esc(c.fum)}" />
            </label>
            <label class="field">
              <span class="field-label">Ciclo (días)</span>
              <input type="number" class="field-input" id="c-ciclo" value="${c.ciclo}" min="20" max="45" />
            </label>
            <label class="field">
              <span class="field-label">FPP por ecografía (directa)</span>
              <input type="date" class="field-input" id="c-fpp" value="${esc(c.fpp)}" />
            </label>
          </div>
          <div class="m2-form-grid mt-2">
            <label class="field">
              <span class="field-label">Talla (cm)</span>
              <input type="number" class="field-input" id="c-talla" value="${c.talla != null ? c.talla : ''}" min="120" max="200" step="0.5" />
            </label>
            <label class="field">
              <span class="field-label">Peso pregestacional (kg)</span>
              <input type="number" class="field-input" id="c-pesoPre" value="${c.pesoPre != null ? c.pesoPre : ''}" min="30" max="200" step="0.1" />
            </label>
            <label class="m3-checkbox" style="grid-column:1/-1;">
              <input type="checkbox" id="c-mult" ${c.embarazoMultiple ? 'checked' : ''} />
              <span>Embarazo múltiple</span>
            </label>
          </div>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Antecedentes obstétricos</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Gestas (G)</span>
              <input type="number" class="field-input" id="c-gestas" value="${c.antecedentes.gestas}" min="0" max="20" />
            </label>
            <label class="field">
              <span class="field-label">Paras (P)</span>
              <input type="number" class="field-input" id="c-paras" value="${c.antecedentes.paras}" min="0" max="20" />
            </label>
            <label class="field">
              <span class="field-label">Cesáreas</span>
              <input type="number" class="field-input" id="c-cesareas" value="${c.antecedentes.cesareas}" min="0" max="20" />
            </label>
            <label class="field">
              <span class="field-label">Abortos</span>
              <input type="number" class="field-input" id="c-abortos" value="${c.antecedentes.abortos}" min="0" max="20" />
            </label>
            <label class="field">
              <span class="field-label">Mortinatos</span>
              <input type="number" class="field-input" id="c-mortinatos" value="${c.antecedentes.mortinatos}" min="0" max="20" />
            </label>
          </div>
          <label class="field mt-2">
            <span class="field-label">Notas sobre antecedentes</span>
            <textarea class="field-input" id="c-ant-notas" rows="2">${esc(c.antecedentes.notas)}</textarea>
          </label>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Factores de riesgo (basales)</h3>
          <div class="m10-fr-grid">
            ${FACTORES_RIESGO.map(fr => `
              <label class="m3-checkbox">
                <input type="checkbox" class="c-fr" value="${esc(fr)}" ${c.factoresRiesgo.includes(fr) ? 'checked' : ''} />
                <span>${esc(fr)}</span>
              </label>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    bindCabecera(panel);
    accordionizeSections(out);
  }

  function bindCabecera(panel) {
    const $ = id => document.getElementById(id);
    const c = state.patient.cabecera;

    $('c-tipoDoc')?.addEventListener('change', e => { c.tipoDoc = e.target.value; touch(); });
    $('c-numDoc')?.addEventListener('input', e => {
      const v = validateDoc(c.tipoDoc, e.target.value);
      c.numDoc = v.value;
      const fb = $('c-numDoc-feedback');
      if (fb) {
        if (!e.target.value) { fb.textContent = ''; fb.style.color = ''; }
        else if (v.ok) { fb.textContent = '✓ Válido'; fb.style.color = 'var(--clinic)'; }
        else { fb.textContent = '⚠ ' + v.error; fb.style.color = 'var(--rose)'; }
      }
      touch();
    });
    $('c-nombre')?.addEventListener('input', e => { c.nombre = e.target.value; touch(); renderPatientSummary(); });
    $('c-apellido')?.addEventListener('input', e => { c.apellido = e.target.value; touch(); renderPatientSummary(); });
    $('c-edad')?.addEventListener('input', e => { c.edad = parseFloat(e.target.value) || null; touch(); renderPatientSummary(); });
    $('c-telefono')?.addEventListener('input', e => { c.telefono = e.target.value; touch(); });
    $('c-direccion')?.addEventListener('input', e => { c.direccion = e.target.value; touch(); });

    $('c-fum')?.addEventListener('change', e => { c.fum = e.target.value; touch(); renderPatientSummary(); });
    $('c-ciclo')?.addEventListener('change', e => { c.ciclo = parseInt(e.target.value) || 28; touch(); });
    $('c-fpp')?.addEventListener('change', e => { c.fpp = e.target.value; touch(); });
    $('c-talla')?.addEventListener('change', e => { c.talla = parseFloat(e.target.value) || null; touch(); });
    $('c-pesoPre')?.addEventListener('change', e => { c.pesoPre = parseFloat(e.target.value) || null; touch(); });
    $('c-mult')?.addEventListener('change', e => { c.embarazoMultiple = e.target.checked; touch(); });

    $('c-gestas')?.addEventListener('change', e => { c.antecedentes.gestas = parseInt(e.target.value) || 0; touch(); });
    $('c-paras')?.addEventListener('change', e => { c.antecedentes.paras = parseInt(e.target.value) || 0; touch(); });
    $('c-cesareas')?.addEventListener('change', e => { c.antecedentes.cesareas = parseInt(e.target.value) || 0; touch(); });
    $('c-abortos')?.addEventListener('change', e => { c.antecedentes.abortos = parseInt(e.target.value) || 0; touch(); });
    $('c-mortinatos')?.addEventListener('change', e => { c.antecedentes.mortinatos = parseInt(e.target.value) || 0; touch(); });
    $('c-ant-notas')?.addEventListener('input', e => { c.antecedentes.notas = e.target.value; touch(); });

    panel.querySelectorAll('.c-fr').forEach(cb => {
      cb.addEventListener('change', () => {
        c.factoresRiesgo = Array.from(panel.querySelectorAll('.c-fr:checked')).map(x => x.value);
        touch();
        renderPatientSummary();
      });
    });
  }

  // === Control trimestral ===================================================
  function renderControl(out, panel, idx) {
    const ctrl = state.patient.controles[idx];
    const O = window.Obstetric;
    const fumDate = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;
    const fechaCtrl = ctrl.fecha ? O.isoToDate(ctrl.fecha) : null;
    const eg = (fumDate && fechaCtrl) ? O.calcEG(fumDate, fechaCtrl) : null;
    ctrl.eg = eg;

    out.innerHTML = `
      <div class="card mt-4">
        <div class="card-h">
          <h2>${idx + 1}° Trimestre</h2>
          <span class="badge badge-clinic mono" id="t-eg-badge" style="${eg ? '' : 'display:none;'}">${eg ? `EG ${eg.weeks}s ${eg.days}d` : ''}</span>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Fecha del control y constantes vitales</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Fecha del control</span>
              <input type="date" class="field-input" id="t-fecha" value="${esc(ctrl.fecha)}" />
            </label>
            <label class="field">
              <span class="field-label">Peso (kg)</span>
              <input type="number" class="field-input" id="t-peso" value="${ctrl.peso != null ? ctrl.peso : ''}" min="30" max="200" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">TA sistólica (mmHg)</span>
              <input type="number" class="field-input" id="t-tas" value="${ctrl.ta_sistolica != null ? ctrl.ta_sistolica : ''}" min="60" max="220" />
            </label>
            <label class="field">
              <span class="field-label">TA diastólica (mmHg)</span>
              <input type="number" class="field-input" id="t-tad" value="${ctrl.ta_diastolica != null ? ctrl.ta_diastolica : ''}" min="40" max="140" />
            </label>
            <label class="field">
              <span class="field-label">Pulso (lpm)</span>
              <input type="number" class="field-input" id="t-pulso" value="${ctrl.pulso != null ? ctrl.pulso : ''}" min="40" max="160" />
            </label>
          </div>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Examen obstétrico</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Altura uterina (cm)</span>
              <input type="number" class="field-input" id="t-au" value="${ctrl.au != null ? ctrl.au : ''}" min="0" max="50" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">FCF (lpm)</span>
              <input type="number" class="field-input" id="t-fcf" value="${ctrl.fcf != null ? ctrl.fcf : ''}" min="80" max="200" />
            </label>
            <label class="field">
              <span class="field-label">Movimientos fetales</span>
              <select class="field-select" id="t-mov">${selectOptions(OPC.movimientos, ctrl.movimientos)}</select>
            </label>
            <label class="field">
              <span class="field-label">Presentación</span>
              <select class="field-select" id="t-pres">${selectOptions(OPC.presentacion, ctrl.presentacion)}</select>
            </label>
          </div>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Laboratorio</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Hb (g/dL)</span>
              <input type="number" class="field-input" id="t-hb" value="${ctrl.hb != null ? ctrl.hb : ''}" min="0" max="20" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">Hto (%)</span>
              <input type="number" class="field-input" id="t-hto" value="${ctrl.hto != null ? ctrl.hto : ''}" min="0" max="60" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">Glicemia (mg/dL)</span>
              <input type="number" class="field-input" id="t-gli" value="${ctrl.glicemia != null ? ctrl.glicemia : ''}" min="20" max="500" />
            </label>
            <label class="field">
              <span class="field-label">EGO (resultado)</span>
              <select class="field-select" id="t-ego">${selectOptions(OPC.ego, ctrl.ego)}</select>
            </label>
            <label class="field">
              <span class="field-label">VDRL</span>
              <select class="field-select" id="t-vdrl">${selectOptions(OPC.serologia, ctrl.vdrl)}</select>
            </label>
            <label class="field">
              <span class="field-label">VIH</span>
              <select class="field-select" id="t-vih">${selectOptions(OPC.serologia, ctrl.vih)}</select>
            </label>
          </div>
          <label class="field mt-2">
            <span class="field-label">Otros laboratorios</span>
            <textarea class="field-input" id="t-lab-otros" rows="2">${esc(ctrl.laboratorio_otros)}</textarea>
          </label>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Ecografía</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Fecha de ecografía</span>
              <input type="date" class="field-input" id="t-eco-fecha" value="${esc(ctrl.eco_fecha)}" />
            </label>
            <label class="field">
              <span class="field-label">SG por eco (sem)</span>
              <input type="number" class="field-input" id="t-eco-sg" value="${ctrl.eco_sg != null ? ctrl.eco_sg : ''}" min="4" max="42" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">BPD (mm)</span>
              <input type="number" class="field-input" id="t-eco-bpd" value="${ctrl.eco_bpd != null ? ctrl.eco_bpd : ''}" min="10" max="120" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">CC (mm)</span>
              <input type="number" class="field-input" id="t-eco-cc" value="${ctrl.eco_cc != null ? ctrl.eco_cc : ''}" min="50" max="400" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">CA (mm)</span>
              <input type="number" class="field-input" id="t-eco-ca" value="${ctrl.eco_ca != null ? ctrl.eco_ca : ''}" min="50" max="400" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">LF (mm)</span>
              <input type="number" class="field-input" id="t-eco-lf" value="${ctrl.eco_lf != null ? ctrl.eco_lf : ''}" min="5" max="100" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">Peso fetal estimado (g)</span>
              <input type="number" class="field-input" id="t-eco-pf" value="${ctrl.eco_peso_fetal != null ? ctrl.eco_peso_fetal : ''}" min="0" max="6000" />
            </label>
            <label class="field">
              <span class="field-label">Líquido amniótico</span>
              <select class="field-select" id="t-eco-liq">${selectOptions(OPC.liquido, ctrl.eco_liquido)}</select>
            </label>
            <label class="field">
              <span class="field-label">Placenta</span>
              <input type="text" class="field-input" id="t-eco-pla" value="${esc(ctrl.eco_placenta)}" placeholder="Anterior / Fúndica / Previa / Grado..." />
            </label>
          </div>
          <label class="field mt-2">
            <span class="field-label">Notas de la ecografía</span>
            <textarea class="field-input" id="t-eco-notas" rows="2">${esc(ctrl.eco_notas)}</textarea>
          </label>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Notas clínicas y plan</h3>
          <label class="field">
            <span class="field-label">Notas del control</span>
            <textarea class="field-input" id="t-notas" rows="4">${esc(ctrl.notas)}</textarea>
          </label>
          <label class="field mt-2">
            <span class="field-label">Plan / próxima cita</span>
            <textarea class="field-input" id="t-plan" rows="3">${esc(ctrl.plan)}</textarea>
          </label>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Diagnósticos de este trimestre</h3>
          <p class="tiny muted" style="margin-bottom:var(--space-2);">Registra cada diagnóstico con su fecha. Aparecerán en la línea de tiempo de Evolución.</p>
          <div id="t-dx-list"></div>
          <button class="btn btn-ghost" id="t-dx-add" style="font-size:0.85rem;padding:6px 12px;margin-top:var(--space-2);">+ Añadir diagnóstico</button>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Factores de riesgo identificados este trimestre</h3>
          <div class="m10-fr-grid">
            ${FACTORES_RIESGO.map(fr => `
              <label class="m3-checkbox">
                <input type="checkbox" class="t-fr" value="${esc(fr)}" ${ctrl.factoresRiesgo.includes(fr) ? 'checked' : ''} />
                <span>${esc(fr)}</span>
              </label>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    bindControl(panel, idx);
    renderDxList(idx);
    accordionizeSections(out);
  }

  // Convierte los .m3-section en acordeones colapsables (más amigable).
  // La primera sección queda abierta; el resto cerradas.
  function accordionizeSections(container) {
    const secciones = container.querySelectorAll('.m3-section');
    secciones.forEach((sec, i) => {
      if (sec.dataset.acc) return;            // ya convertida
      sec.dataset.acc = '1';
      const h = sec.querySelector('.m3-sec-h');
      if (!h) return;
      sec.classList.add('m10-acc');
      if (i === 0) sec.classList.add('is-open');  // primera abierta
      // El encabezado actúa como toggle
      h.classList.add('m10-acc-head');
      h.insertAdjacentHTML('beforeend', '<span class="m10-acc-chev">▾</span>');
      h.addEventListener('click', (e) => {
        // No colapsar si se hizo click en un botón dentro del encabezado
        if (e.target.closest('button')) return;
        sec.classList.toggle('is-open');
      });
    });
  }

  // === Render de la lista de diagnósticos de un control ====================
  function renderDxList(idx) {
    const ctrl = state.patient.controles[idx];
    const box = document.getElementById('t-dx-list');
    if (!box) return;
    if (!ctrl.diagnosticos || ctrl.diagnosticos.length === 0) {
      box.innerHTML = '<p class="tiny muted">Sin diagnósticos registrados en este trimestre.</p>';
      return;
    }
    box.innerHTML = ctrl.diagnosticos.map((d, i) => `
      <div class="m10-dx-row">
        <div class="m10-dx-info">
          <strong>${esc(d.dx)}</strong>
          ${d.fecha ? `<span class="badge badge-mute tiny mono">${fmtDate(d.fecha)}</span>` : ''}
          ${d.nota ? `<div class="tiny muted">${esc(d.nota)}</div>` : ''}
        </div>
        <button class="m10-dx-del" data-i="${i}" title="Eliminar">×</button>
      </div>
    `).join('');
    box.querySelectorAll('.m10-dx-del').forEach(b => {
      b.addEventListener('click', () => {
        ctrl.diagnosticos.splice(parseInt(b.dataset.i), 1);
        touch();
        renderDxList(idx);
      });
    });
  }

  // === Modal para añadir diagnóstico =======================================
  function promptAddDx(idx) {
    if (!window.ModalEditor) return;
    const ctrl = state.patient.controles[idx];
    window.ModalEditor.open({
      title: 'Añadir diagnóstico',
      schema: [
        { key: 'dx',    label: 'Diagnóstico', type: 'select', options: DIAGNOSTICOS_FRECUENTES, required: true, allowEmpty: false },
        { key: 'dxOtro',label: 'Si elegiste "Otro", especifica', type: 'text' },
        { key: 'fecha', label: 'Fecha del diagnóstico', type: 'date', default: ctrl.fecha || todayISO() },
        { key: 'nota',  label: 'Nota (opcional)', type: 'textarea', rows: 2 },
      ],
      onSave: (data) => {
        let dx = data.dx;
        if (/otro/i.test(dx) && data.dxOtro) dx = data.dxOtro;
        if (!ctrl.diagnosticos) ctrl.diagnosticos = [];
        ctrl.diagnosticos.push({ dx, fecha: data.fecha || ctrl.fecha || todayISO(), nota: data.nota || '' });
        touch();
        renderDxList(idx);
        window.State?.toast(`✓ Diagnóstico agregado`, 'ok');
      },
    });
  }

  function actualizarBadgeEG(idx) {
    const ctrl = state.patient.controles[idx];
    const O = window.Obstetric;
    const fumDate = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;
    const fechaCtrl = ctrl.fecha ? O.isoToDate(ctrl.fecha) : null;
    const badge = document.getElementById('t-eg-badge');
    if (!badge) return;
    if (fumDate && fechaCtrl) {
      const eg = O.calcEG(fumDate, fechaCtrl);
      ctrl.eg = eg;
      badge.textContent = `EG ${eg.weeks}s ${eg.days}d`;
      badge.style.display = '';
    } else {
      badge.style.display = 'none';
    }
  }

  function bindControl(panel, idx) {
    const $ = id => document.getElementById(id);
    const ctrl = state.patient.controles[idx];

    // FIX: usar 'input' para commit inmediato, no esperar 'change' que requiere blur.
    // Así los valores quedan disponibles para los gráficos en cuanto el usuario navega.
    const numField = (id, key) => {
      const el = $(id);
      if (!el) return;
      el.addEventListener('input', e => {
        const v = parseFloat(e.target.value);
        ctrl[key] = isNaN(v) ? null : v;
        touch();
      });
    };
    const textField = (id, key) => {
      $(id)?.addEventListener('input', e => { ctrl[key] = e.target.value; touch(); });
    };

    // Fecha: NO re-renderizar todo el formulario (eso causaba el salto de foco).
    // Solo actualizar el badge de EG en su lugar.
    $('t-fecha')?.addEventListener('change', e => {
      ctrl.fecha = e.target.value;
      touch();
      actualizarBadgeEG(idx);
    });
    numField('t-peso', 'peso');
    numField('t-tas', 'ta_sistolica');
    numField('t-tad', 'ta_diastolica');
    numField('t-pulso', 'pulso');
    numField('t-au', 'au');
    numField('t-fcf', 'fcf');
    textField('t-mov', 'movimientos');
    textField('t-pres', 'presentacion');
    numField('t-hb', 'hb');
    numField('t-hto', 'hto');
    numField('t-gli', 'glicemia');
    textField('t-ego', 'ego');
    textField('t-vdrl', 'vdrl');
    textField('t-vih', 'vih');
    textField('t-lab-otros', 'laboratorio_otros');
    $('t-eco-fecha')?.addEventListener('change', e => { ctrl.eco_fecha = e.target.value; touch(); });
    numField('t-eco-sg', 'eco_sg');
    numField('t-eco-bpd', 'eco_bpd');
    numField('t-eco-cc', 'eco_cc');
    numField('t-eco-ca', 'eco_ca');
    numField('t-eco-lf', 'eco_lf');
    numField('t-eco-pf', 'eco_peso_fetal');
    textField('t-eco-liq', 'eco_liquido');
    textField('t-eco-pla', 'eco_placenta');
    textField('t-eco-notas', 'eco_notas');
    textField('t-notas', 'notas');
    textField('t-plan', 'plan');

    panel.querySelectorAll('.t-fr').forEach(cb => {
      cb.addEventListener('change', () => {
        ctrl.factoresRiesgo = Array.from(panel.querySelectorAll('.t-fr:checked')).map(x => x.value);
        touch();
      });
    });

    document.getElementById('t-dx-add')?.addEventListener('click', () => promptAddDx(idx));
  }

  // === Postparto ============================================================
  function renderPostparto(out, panel) {
    const p = state.patient.postparto;
    out.innerHTML = `
      <div class="card mt-4">
        <div class="card-h"><h2>👶 Postparto / Cierre del seguimiento</h2></div>

        <label class="m3-checkbox" style="margin-bottom:var(--space-3);">
          <input type="checkbox" id="p-completado" ${p.completado ? 'checked' : ''} />
          <span><strong>Marcar como completado</strong> (la paciente dio a luz)</span>
        </label>

        <div class="m3-section">
          <h3 class="m3-sec-h">Datos del parto</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Fecha del parto</span>
              <input type="date" class="field-input" id="p-fecha" value="${esc(p.fecha)}" />
            </label>
            <label class="field">
              <span class="field-label">Vía del parto</span>
              <select class="field-select" id="p-via">
                <option value=""${p.viaParto===''?' selected':''}>—</option>
                <option value="vaginal"${p.viaParto==='vaginal'?' selected':''}>Vaginal eutócico</option>
                <option value="instrumentado"${p.viaParto==='instrumentado'?' selected':''}>Vaginal instrumentado</option>
                <option value="cesárea"${p.viaParto==='cesárea'?' selected':''}>Cesárea</option>
              </select>
            </label>
          </div>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Recién nacido</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Peso RN (g)</span>
              <input type="number" class="field-input" id="p-peso" value="${p.pesoRN != null ? p.pesoRN : ''}" min="500" max="6000" />
            </label>
            <label class="field">
              <span class="field-label">Talla RN (cm)</span>
              <input type="number" class="field-input" id="p-talla" value="${p.tallaRN != null ? p.tallaRN : ''}" min="20" max="60" step="0.1" />
            </label>
            <label class="field">
              <span class="field-label">APGAR 1'</span>
              <input type="number" class="field-input" id="p-apg1" value="${p.apgar1 != null ? p.apgar1 : ''}" min="0" max="10" />
            </label>
            <label class="field">
              <span class="field-label">APGAR 5'</span>
              <input type="number" class="field-input" id="p-apg5" value="${p.apgar5 != null ? p.apgar5 : ''}" min="0" max="10" />
            </label>
          </div>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Lactancia y complicaciones</h3>
          <label class="field">
            <span class="field-label">Lactancia</span>
            <select class="field-select" id="p-lact">
              <option value=""${p.lactancia===''?' selected':''}>—</option>
              <option value="exclusiva"${p.lactancia==='exclusiva'?' selected':''}>Lactancia materna exclusiva</option>
              <option value="mixta"${p.lactancia==='mixta'?' selected':''}>Mixta</option>
              <option value="fórmula"${p.lactancia==='fórmula'?' selected':''}>Fórmula</option>
            </select>
          </label>
          <label class="field mt-2">
            <span class="field-label">Complicaciones</span>
            <textarea class="field-input" id="p-comp" rows="3">${esc(p.complicaciones)}</textarea>
          </label>
          <label class="field mt-2">
            <span class="field-label">Notas finales</span>
            <textarea class="field-input" id="p-notas" rows="3">${esc(p.notas)}</textarea>
          </label>
        </div>
      </div>
    `;

    const $ = id => document.getElementById(id);
    $('p-completado')?.addEventListener('change', e => { p.completado = e.target.checked; touch(); });
    $('p-fecha')?.addEventListener('change', e => { p.fecha = e.target.value; touch(); });
    $('p-via')?.addEventListener('change', e => { p.viaParto = e.target.value; touch(); });
    $('p-peso')?.addEventListener('change', e => { p.pesoRN = parseFloat(e.target.value) || null; touch(); });
    $('p-talla')?.addEventListener('change', e => { p.tallaRN = parseFloat(e.target.value) || null; touch(); });
    $('p-apg1')?.addEventListener('change', e => { p.apgar1 = parseInt(e.target.value); touch(); });
    $('p-apg5')?.addEventListener('change', e => { p.apgar5 = parseInt(e.target.value); touch(); });
    $('p-lact')?.addEventListener('change', e => { p.lactancia = e.target.value; touch(); });
    $('p-comp')?.addEventListener('input', e => { p.complicaciones = e.target.value; touch(); });
    $('p-notas')?.addEventListener('input', e => { p.notas = e.target.value; touch(); });
  }

  // === Evolución (gráficos) =================================================
  function renderEvolucion(out) {
    // Diagnóstico: ¿qué falta? Mostrar al médico exactamente qué le impide ver los gráficos
    const c = state.patient.cabecera;
    const ctrls = state.patient.controles;
    const ctrlsConFecha = ctrls.filter(c => c.fecha);
    const ctrlsConDatos = ctrls.filter(c => c.peso != null || c.au != null || c.hb != null || c.ta_sistolica != null);

    const checks = [];
    if (!c.fum)                  checks.push('• FUM (cabecera) — necesaria para calcular semanas de gestación');
    if (!c.pesoPre)              checks.push('• Peso pregestacional (cabecera) — para gráfico de ganancia');
    if (!c.talla)                checks.push('• Talla materna (cabecera) — para clasificación IOM');
    if (ctrlsConFecha.length === 0 && ctrlsConDatos.length > 0) {
      checks.push('• Fecha del control en al menos un trimestre — tienes datos pero falta la fecha');
    } else if (ctrlsConFecha.length === 0) {
      checks.push('• Al menos un trimestre con fecha y datos antropométricos');
    }

    if (checks.length > 0) {
      out.innerHTML = `
        <div class="card mt-4">
          <div class="card-h">
            <h2>📈 Evolución</h2>
          </div>
          <div class="m10-evol-help">
            <strong>Para ver los gráficos de evolución, completa lo siguiente:</strong>
            <div class="m10-evol-checks">
              ${checks.map(c => `<div>${esc(c)}</div>`).join('')}
            </div>
            <p class="tiny muted mt-3">
              <strong>Recordatorio:</strong> los valores se guardan en cuanto los escribes.
              Si llenaste datos pero no aparecen los gráficos, verifica que cada control tenga
              al menos su fecha del control.
            </p>
          </div>
        </div>
      `;
      return;
    }

    out.innerHTML = `
      ${renderResumenTabla()}
      ${renderDiagnosticosTimeline()}
      <div class="m10-evol-grid">
        ${renderPesoEvolution()}
        ${renderTAEvolution()}
        ${renderAUEvolution()}
        ${renderHbEvolution()}
      </div>
      <div class="m10-evol-print">
        <button class="btn btn-ghost" id="m10-print-evol">🖨️ Imprimir resumen completo</button>
      </div>
    `;

    document.getElementById('m10-print-evol')?.addEventListener('click', () => {
      printResumen();
    });
  }

  // === Tabla resumen de las 3 visitas (con tendencias y alertas) ===========
  function renderResumenTabla() {
    const O = window.Obstetric;
    const fum = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;
    const ctrls = state.patient.controles;

    // Helper: EG en cada control
    const egDe = (c) => (fum && c.fecha) ? O.calcEG(fum, O.isoToDate(c.fecha)) : null;

    // Flecha de tendencia entre dos valores numéricos
    const trend = (prev, curr) => {
      if (prev == null || curr == null) return '';
      if (curr > prev) return ' <span class="m10-trend up">↑</span>';
      if (curr < prev) return ' <span class="m10-trend down">↓</span>';
      return ' <span class="m10-trend flat">→</span>';
    };

    // Filas: cada una es un parámetro, columnas = T1, T2, T3
    function fila(label, getter, opts = {}) {
      const cells = ctrls.map((c, i) => {
        const v = getter(c);
        if (v == null || v === '') return '<td class="muted">—</td>';
        let display = v;
        let cls = '';
        // Alertas de color
        if (opts.alert) {
          const a = opts.alert(v, c);
          if (a) cls = a;
        }
        // Tendencia respecto al control previo con dato
        let t = '';
        if (opts.numeric && i > 0) {
          let prevVal = null;
          for (let j = i - 1; j >= 0; j--) {
            const pv = getter(ctrls[j]);
            if (pv != null && pv !== '') { prevVal = pv; break; }
          }
          t = trend(prevVal, v);
        }
        return `<td class="${cls}">${esc(String(display))}${opts.unit ? ' ' + opts.unit : ''}${t}</td>`;
      });
      return `<tr><th>${esc(label)}</th>${cells.join('')}</tr>`;
    }

    const taFmt = (c) => (c.ta_sistolica != null && c.ta_diastolica != null) ? `${c.ta_sistolica}/${c.ta_diastolica}` : null;

    return `
      <div class="card mt-4">
        <div class="card-h">
          <h2>📋 Resumen de la evolución</h2>
          <span class="badge badge-mute tiny">3 controles</span>
        </div>
        <div class="m10-resumen-wrap">
          <table class="m10-resumen">
            <thead>
              <tr>
                <th>Parámetro</th>
                ${ctrls.map((c, i) => {
                  const eg = egDe(c);
                  return `<th>
                    <div>${i + 1}° Trim</div>
                    <div class="tiny muted">${c.fecha ? fmtDate(c.fecha) : '—'}</div>
                    ${eg ? `<div class="tiny mono">${eg.weeks}s ${eg.days}d</div>` : ''}
                  </th>`;
                }).join('')}
              </tr>
            </thead>
            <tbody>
              ${fila('Peso (kg)', c => c.peso, { numeric: true, unit: 'kg' })}
              ${fila('TA (mmHg)', taFmt, { alert: (v, c) => (c.ta_sistolica >= 140 || c.ta_diastolica >= 90) ? 'is-alert' : '' })}
              ${fila('Pulso (lpm)', c => c.pulso, { numeric: true })}
              ${fila('Altura uterina (cm)', c => c.au, { numeric: true, unit: 'cm' })}
              ${fila('FCF (lpm)', c => c.fcf, { numeric: true })}
              ${fila('Movim. fetales', c => c.movimientos)}
              ${fila('Presentación', c => c.presentacion)}
              ${fila('Hb (g/dL)', c => c.hb, { numeric: true, unit: 'g/dL', alert: (v) => v < 11 ? 'is-warn' : '' })}
              ${fila('Hto (%)', c => c.hto, { numeric: true, unit: '%' })}
              ${fila('Glicemia (mg/dL)', c => c.glicemia, { numeric: true, alert: (v) => v >= 126 ? 'is-warn' : '' })}
              ${fila('EGO', c => c.ego, { alert: (v) => (v && v !== 'Normal') ? 'is-warn' : '' })}
              ${fila('VDRL', c => c.vdrl, { alert: (v) => v === 'Reactivo' ? 'is-alert' : '' })}
              ${fila('VIH', c => c.vih, { alert: (v) => v === 'Reactivo' ? 'is-alert' : '' })}
              ${fila('Peso fetal eco (g)', c => c.eco_peso_fetal, { numeric: true, unit: 'g' })}
              ${fila('Líquido amniótico', c => c.eco_liquido, { alert: (v) => (v && v !== 'Normal' && v !== 'No valorado') ? 'is-warn' : '' })}
              ${fila('Placenta', c => c.eco_placenta)}
            </tbody>
          </table>
        </div>
        <div class="m10-resumen-legend tiny muted">
          <span><span class="m10-trend up">↑</span> sube · <span class="m10-trend down">↓</span> baja · <span class="m10-trend flat">→</span> igual</span>
          <span><span class="m10-leg-box is-warn"></span> revisar · <span class="m10-leg-box is-alert"></span> alerta</span>
        </div>
      </div>
    `;
  }

  // === Línea de tiempo de diagnósticos y factores de riesgo ================
  function renderDiagnosticosTimeline() {
    const O = window.Obstetric;
    const fum = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;

    // Reunir todos los diagnósticos de los 3 trimestres
    const eventos = [];
    state.patient.controles.forEach((c, ti) => {
      (c.diagnosticos || []).forEach(d => {
        eventos.push({ ...d, trim: ti + 1 });
      });
    });
    // Factores de riesgo basales (de cabecera)
    const frBasales = state.patient.cabecera.factoresRiesgo || [];

    if (eventos.length === 0 && frBasales.length === 0) {
      return `
        <div class="card mt-4">
          <div class="card-h"><h2>🔔 Diagnósticos y factores de riesgo</h2></div>
          <p class="muted small">Sin diagnósticos ni factores de riesgo registrados. Agrégalos en cada trimestre.</p>
        </div>
      `;
    }

    // Ordenar eventos por fecha
    eventos.sort((a, b) => (a.fecha || '').localeCompare(b.fecha || ''));

    return `
      <div class="card mt-4">
        <div class="card-h"><h2>🔔 Diagnósticos y factores de riesgo</h2></div>
        ${frBasales.length ? `
          <div class="m10-fr-basales">
            <strong class="tiny">Factores de riesgo basales:</strong>
            ${frBasales.map(f => `<span class="badge badge-ochre tiny">${esc(f)}</span>`).join(' ')}
          </div>
        ` : ''}
        ${eventos.length ? `
          <div class="m10-timeline">
            ${eventos.map(e => `
              <div class="m10-tl-item">
                <div class="m10-tl-dot"></div>
                <div class="m10-tl-body">
                  <div class="m10-tl-head">
                    <strong>${esc(e.dx)}</strong>
                    <span class="badge badge-clinic tiny">${e.fecha ? fmtDate(e.fecha) : 'sin fecha'}</span>
                    <span class="badge badge-mute tiny">${e.trim}° trim</span>
                  </div>
                  ${e.nota ? `<div class="tiny muted">${esc(e.nota)}</div>` : ''}
                </div>
              </div>
            `).join('')}
          </div>
        ` : '<p class="muted small">Sin diagnósticos registrados en los trimestres.</p>'}
      </div>
    `;
  }

  // === Impresión del resumen completo ======================================
  function printResumen() {
    const c = state.patient.cabecera;
    const O = window.Obstetric;
    const fum = c.fum ? O.isoToDate(c.fum) : null;
    const nombre = `${c.nombre || ''} ${c.apellido || ''}`.trim() || 'Paciente';

    // Construir tabla resumen en HTML plano
    const ctrls = state.patient.controles;
    const egDe = (ct) => (fum && ct.fecha) ? O.calcEG(fum, O.isoToDate(ct.fecha)) : null;
    const row = (label, getter, unit) => {
      const cells = ctrls.map(ct => {
        const v = getter(ct);
        return `<td>${(v == null || v === '') ? '—' : esc(String(v)) + (unit ? ' ' + unit : '')}</td>`;
      }).join('');
      return `<tr><th>${esc(label)}</th>${cells}</tr>`;
    };
    const taFmt = (ct) => (ct.ta_sistolica != null && ct.ta_diastolica != null) ? `${ct.ta_sistolica}/${ct.ta_diastolica}` : null;

    const eventos = [];
    ctrls.forEach((ct, ti) => (ct.diagnosticos || []).forEach(d => eventos.push({ ...d, trim: ti + 1 })));
    eventos.sort((a, b) => (a.fecha || '').localeCompare(b.fecha || ''));

    const html = `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<title>Seguimiento — ${esc(nombre)}</title>
<style>
  @page { size: letter; margin: 0.6in; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, system-ui, 'Segoe UI', sans-serif; color: #1a1a1a; font-size: 10pt; padding: 8px; }
  h1 { font-size: 16pt; text-align: center; margin-bottom: 4px; }
  h2 { font-size: 11pt; margin: 14px 0 6px; border-bottom: 2px solid #1F5F4A; padding-bottom: 2px; color: #1F5F4A; }
  .sub { text-align: center; color: #555; font-size: 9pt; margin-bottom: 10px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
  th, td { border: 1px solid #c8c0b0; padding: 4px 6px; text-align: left; font-size: 9pt; }
  thead th { background: #f0ece2; }
  tbody th { background: #faf8f4; font-weight: 600; width: 30%; }
  .dx { margin: 3px 0; padding: 3px 6px; background: #f5f5f0; border-left: 3px solid #1F5F4A; font-size: 9pt; }
  .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 2px 16px; font-size: 9pt; margin-bottom: 6px; }
  @media print { button { display: none; } }
</style></head><body>
  <h1>Seguimiento Gestante</h1>
  <div class="sub">${esc(nombre)} · ${esc(c.tipoDoc || '')} ${esc(c.numDoc || '')} ${c.edad ? '· ' + c.edad + ' años' : ''}</div>

  <h2>Datos generales</h2>
  <div class="meta">
    <div><b>FUM:</b> ${c.fum ? fmtDate(c.fum) : '—'}</div>
    <div><b>FPP:</b> ${c.fpp ? fmtDate(c.fpp) : '—'}</div>
    <div><b>Talla:</b> ${c.talla || '—'} cm</div>
    <div><b>Peso pregestacional:</b> ${c.pesoPre || '—'} kg</div>
    <div><b>Teléfono:</b> ${esc(c.telefono || '—')}</div>
    <div><b>Dirección:</b> ${esc(c.direccion || '—')}</div>
    <div><b>Antecedentes:</b> G${c.antecedentes.gestas} P${c.antecedentes.paras} C${c.antecedentes.cesareas} A${c.antecedentes.abortos}</div>
    <div><b>Embarazo múltiple:</b> ${c.embarazoMultiple ? 'Sí' : 'No'}</div>
  </div>

  <h2>Evolución por trimestre</h2>
  <table>
    <thead><tr><th>Parámetro</th>${ctrls.map((ct, i) => {
      const eg = egDe(ct);
      return `<th>${i+1}° Trim<br><span style="font-weight:400;font-size:8pt;">${ct.fecha ? fmtDate(ct.fecha) : '—'}${eg ? ' · ' + eg.weeks + 's' + eg.days + 'd' : ''}</span></th>`;
    }).join('')}</tr></thead>
    <tbody>
      ${row('Peso (kg)', ct => ct.peso, 'kg')}
      ${row('TA (mmHg)', taFmt, '')}
      ${row('Pulso', ct => ct.pulso, '')}
      ${row('Altura uterina', ct => ct.au, 'cm')}
      ${row('FCF', ct => ct.fcf, 'lpm')}
      ${row('Presentación', ct => ct.presentacion, '')}
      ${row('Hb', ct => ct.hb, 'g/dL')}
      ${row('Glicemia', ct => ct.glicemia, 'mg/dL')}
      ${row('EGO', ct => ct.ego, '')}
      ${row('VDRL', ct => ct.vdrl, '')}
      ${row('VIH', ct => ct.vih, '')}
      ${row('Peso fetal eco', ct => ct.eco_peso_fetal, 'g')}
      ${row('Líquido amniótico', ct => ct.eco_liquido, '')}
    </tbody>
  </table>

  ${eventos.length ? `
    <h2>Diagnósticos</h2>
    ${eventos.map(e => `<div class="dx"><b>${esc(e.dx)}</b> — ${e.fecha ? fmtDate(e.fecha) : 'sin fecha'} (${e.trim}° trim)${e.nota ? ' · ' + esc(e.nota) : ''}</div>`).join('')}
  ` : ''}

  ${state.patient.postparto.completado ? `
    <h2>Postparto</h2>
    <div class="meta">
      <div><b>Fecha parto:</b> ${state.patient.postparto.fecha ? fmtDate(state.patient.postparto.fecha) : '—'}</div>
      <div><b>Vía:</b> ${esc(state.patient.postparto.viaParto || '—')}</div>
      <div><b>Peso RN:</b> ${state.patient.postparto.pesoRN || '—'} g</div>
      <div><b>APGAR:</b> ${state.patient.postparto.apgar1 ?? '—'}/${state.patient.postparto.apgar5 ?? '—'}</div>
      <div><b>Lactancia:</b> ${esc(state.patient.postparto.lactancia || '—')}</div>
    </div>
  ` : ''}

  <button onclick="window.print()" style="margin:16px auto;display:block;padding:8px 20px;cursor:pointer;">🖨️ Imprimir</button>
  <script>setTimeout(function(){ window.print(); }, 400);<\/script>
</body></html>`;

    const win = window.open('', '_blank');
    if (!win) { window.State?.toast('Permite ventanas emergentes', 'warn'); return; }
    win.document.open(); win.document.write(html); win.document.close();
  }

  // === Evolución de peso sobre curva IOM ====================================
  function renderPesoEvolution() {
    const c = state.patient.cabecera;
    const pesoPre = c.pesoPre;
    const talla = c.talla;
    if (!pesoPre || !talla) {
      return `
        <div class="card">
          <div class="card-h"><h2>📊 Peso materno</h2></div>
          <p class="muted small">Necesita talla y peso pregestacional para mostrar el rango IOM.</p>
        </div>
      `;
    }
    const imc = pesoPre / Math.pow(talla / 100, 2);
    const escenario = c.embarazoMultiple ? 'multiple' : (talla < 157 ? 'tallaBaja' : 'unico');
    const categoria = imc < 18.5 ? 'Delgadez' : imc < 25 ? 'Normal' : imc < 30 ? 'Sobrepeso' : 'Obesidad';

    // Rangos IOM 2009
    const RANGOS = {
      unico:    { 'Delgadez': [12.5, 18], 'Normal': [11.5, 16], 'Sobrepeso': [7, 11.5], 'Obesidad': [5, 9] },
      multiple: { 'Delgadez': null, 'Normal': [17, 25], 'Sobrepeso': [14, 23], 'Obesidad': [11, 19] },
      tallaBaja:{ 'Delgadez': [0, 12.5], 'Normal': [0, 11.5], 'Sobrepeso': [0, 7], 'Obesidad': [0, 5] },
    };
    const rango = RANGOS[escenario]?.[categoria];

    // Puntos de los controles (ganancia desde pesoPre)
    const O = window.Obstetric;
    const fum = c.fum ? O.isoToDate(c.fum) : null;
    const puntos = state.patient.controles
      .filter(ctrl => ctrl.fecha && ctrl.peso != null && fum)
      .map(ctrl => {
        const eg = O.calcEG(fum, O.isoToDate(ctrl.fecha));
        return { sem: eg.fraction, ganancia: ctrl.peso - pesoPre, trim: ctrl.trimestre };
      });

    // SVG: x = semanas (10 a 42), y = ganancia (0 a 25 kg)
    const W = 560, H = 280;
    const pad = { l: 50, r: 20, t: 20, b: 40 };
    const innerW = W - pad.l - pad.r, innerH = H - pad.t - pad.b;
    const xMin = 10, xMax = 42;
    const yMin = -2, yMax = 28;
    const sx = w => pad.l + ((w - xMin) / (xMax - xMin)) * innerW;
    const sy = kg => pad.t + (1 - (kg - yMin) / (yMax - yMin)) * innerH;

    // Zona recomendada IOM (rectángulo si hay rango)
    const zonaSvg = rango ? `
      <rect x="${pad.l}" y="${sy(rango[1]).toFixed(1)}"
            width="${innerW}" height="${(sy(rango[0]) - sy(rango[1])).toFixed(1)}"
            fill="#1F5F4A" opacity="0.12" />
      <line x1="${pad.l}" y1="${sy(rango[0]).toFixed(1)}" x2="${W-pad.r}" y2="${sy(rango[0]).toFixed(1)}" stroke="#1F5F4A" stroke-dasharray="3,3" stroke-width="1"/>
      <line x1="${pad.l}" y1="${sy(rango[1]).toFixed(1)}" x2="${W-pad.r}" y2="${sy(rango[1]).toFixed(1)}" stroke="#1F5F4A" stroke-dasharray="3,3" stroke-width="1"/>
      <text x="${W-pad.r-5}" y="${(sy(rango[1])-3).toFixed(1)}" font-size="10" text-anchor="end" fill="#1F5F4A" font-weight="600">+${rango[1]} kg (máx)</text>
      <text x="${W-pad.r-5}" y="${(sy(rango[0])-3).toFixed(1)}" font-size="10" text-anchor="end" fill="#1F5F4A" font-weight="600">+${rango[0]} kg (mín)</text>
    ` : '';

    // Línea entre puntos
    let lineSvg = '';
    if (puntos.length >= 2) {
      const d = puntos.map((p, i) => (i === 0 ? 'M' : 'L') + sx(p.sem).toFixed(1) + ' ' + sy(p.ganancia).toFixed(1)).join(' ');
      lineSvg = `<path d="${d}" fill="none" stroke="#1F5F4A" stroke-width="2"/>`;
    }
    const dotsSvg = puntos.map(p => `
      <circle cx="${sx(p.sem).toFixed(1)}" cy="${sy(p.ganancia).toFixed(1)}" r="6" fill="#1F5F4A" stroke="white" stroke-width="2"/>
      <text x="${sx(p.sem).toFixed(1)}" y="${(sy(p.ganancia)-10).toFixed(1)}" font-size="10" text-anchor="middle" fill="#1F5F4A" font-weight="600">T${p.trim}: ${p.ganancia > 0 ? '+' : ''}${p.ganancia.toFixed(1)}</text>
    `).join('');

    // Ticks
    const xTicks = [10, 14, 20, 26, 32, 38, 42];
    const yTicks = [-2, 4, 10, 16, 22, 28];

    return `
      <div class="card">
        <div class="card-h">
          <h2>📊 Peso materno</h2>
          <span class="badge badge-mute tiny mono">IOM 2009 · ${esc(escenario)} · ${esc(categoria)}</span>
        </div>
        <svg viewBox="0 0 ${W} ${H}" class="m10-evol-svg">
          <rect x="${pad.l}" y="${pad.t}" width="${innerW}" height="${innerH}" fill="#fdfbf7" stroke="#e6ddd0" rx="8"/>
          ${yTicks.map(t => `<line x1="${pad.l}" y1="${sy(t).toFixed(1)}" x2="${W-pad.r}" y2="${sy(t).toFixed(1)}" stroke="#E8E2D4" stroke-width="0.5"/>`).join('')}
          ${xTicks.map(t => `<line x1="${sx(t).toFixed(1)}" y1="${pad.t}" x2="${sx(t).toFixed(1)}" y2="${H-pad.b}" stroke="#E8E2D4" stroke-width="0.5"/>`).join('')}
          <line x1="${pad.l}" y1="${sy(0).toFixed(1)}" x2="${W-pad.r}" y2="${sy(0).toFixed(1)}" stroke="#5A6A63" stroke-width="1"/>
          ${zonaSvg}
          ${lineSvg}
          ${dotsSvg}
          ${xTicks.map(t => `<text x="${sx(t).toFixed(1)}" y="${H-pad.b+15}" font-size="10" text-anchor="middle" fill="#5A6A63">${t}</text>`).join('')}
          ${yTicks.map(t => `<text x="${pad.l-6}" y="${(sy(t)+3).toFixed(1)}" font-size="10" text-anchor="end" fill="#5A6A63">${t > 0 ? '+' : ''}${t}</text>`).join('')}
          <text x="${W/2}" y="${H-5}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17">semanas</text>
          <text x="14" y="${H/2}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17" transform="rotate(-90 14 ${H/2})">ganancia (kg)</text>
        </svg>
        <p class="tiny muted mt-2">
          Zona verde: rango recomendado IOM 2009 para IMC pregestacional <strong>${imc.toFixed(1)}</strong> (${categoria}).
        </p>
      </div>
    `;
  }

  // === Evolución de TA ======================================================
  function renderTAEvolution() {
    const O = window.Obstetric;
    const fum = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;
    const puntos = state.patient.controles
      .filter(c => c.fecha && c.ta_sistolica != null && c.ta_diastolica != null && fum)
      .map(c => {
        const eg = O.calcEG(fum, O.isoToDate(c.fecha));
        return { sem: eg.fraction, tas: c.ta_sistolica, tad: c.ta_diastolica, trim: c.trimestre };
      });

    if (puntos.length === 0) {
      return `<div class="card"><div class="card-h"><h2>🩺 Tensión arterial</h2></div><p class="muted small">Sin datos.</p></div>`;
    }

    const W = 560, H = 280;
    const pad = { l: 50, r: 20, t: 20, b: 40 };
    const innerW = W - pad.l - pad.r, innerH = H - pad.t - pad.b;
    const xMin = 10, xMax = 42;
    const yMin = 40, yMax = 180;
    const sx = w => pad.l + ((w - xMin) / (xMax - xMin)) * innerW;
    const sy = mmHg => pad.t + (1 - (mmHg - yMin) / (yMax - yMin)) * innerH;

    const pathTAS = puntos.length >= 2
      ? `<path d="${puntos.map((p,i)=>(i===0?'M':'L')+sx(p.sem).toFixed(1)+' '+sy(p.tas).toFixed(1)).join(' ')}" fill="none" stroke="#B0413E" stroke-width="2"/>` : '';
    const pathTAD = puntos.length >= 2
      ? `<path d="${puntos.map((p,i)=>(i===0?'M':'L')+sx(p.sem).toFixed(1)+' '+sy(p.tad).toFixed(1)).join(' ')}" fill="none" stroke="#1F5F4A" stroke-width="2"/>` : '';

    const dots = puntos.map(p => `
      <circle cx="${sx(p.sem).toFixed(1)}" cy="${sy(p.tas).toFixed(1)}" r="5" fill="#B0413E" stroke="white" stroke-width="2"/>
      <circle cx="${sx(p.sem).toFixed(1)}" cy="${sy(p.tad).toFixed(1)}" r="5" fill="#1F5F4A" stroke="white" stroke-width="2"/>
      <text x="${sx(p.sem).toFixed(1)}" y="${(sy(p.tas)-10).toFixed(1)}" font-size="9" text-anchor="middle" fill="#B0413E" font-weight="600">${p.tas}</text>
      <text x="${sx(p.sem).toFixed(1)}" y="${(sy(p.tad)+15).toFixed(1)}" font-size="9" text-anchor="middle" fill="#1F5F4A" font-weight="600">${p.tad}</text>
    `).join('');

    // Líneas de referencia (140/90 = preeclampsia)
    const refLines = `
      <line x1="${pad.l}" y1="${sy(140).toFixed(1)}" x2="${W-pad.r}" y2="${sy(140).toFixed(1)}" stroke="#B0413E" stroke-dasharray="4,4" stroke-width="1"/>
      <text x="${W-pad.r-5}" y="${(sy(140)-3).toFixed(1)}" font-size="10" text-anchor="end" fill="#B0413E">140 (alerta)</text>
      <line x1="${pad.l}" y1="${sy(90).toFixed(1)}" x2="${W-pad.r}" y2="${sy(90).toFixed(1)}" stroke="#B0413E" stroke-dasharray="4,4" stroke-width="1"/>
      <text x="${W-pad.r-5}" y="${(sy(90)-3).toFixed(1)}" font-size="10" text-anchor="end" fill="#B0413E">90 (alerta)</text>
    `;

    const xTicks = [10, 16, 22, 28, 34, 40];
    const yTicks = [40, 60, 80, 100, 120, 140, 160, 180];

    return `
      <div class="card">
        <div class="card-h">
          <h2>🩺 Tensión arterial</h2>
          <span class="badge badge-mute tiny">${puntos.length} control(es)</span>
        </div>
        <svg viewBox="0 0 ${W} ${H}" class="m10-evol-svg">
          <rect x="${pad.l}" y="${pad.t}" width="${innerW}" height="${innerH}" fill="#fdfbf7" stroke="#e6ddd0" rx="8"/>
          ${yTicks.map(t => `<line x1="${pad.l}" y1="${sy(t).toFixed(1)}" x2="${W-pad.r}" y2="${sy(t).toFixed(1)}" stroke="#E8E2D4" stroke-width="0.5"/>`).join('')}
          ${refLines}
          ${pathTAS}
          ${pathTAD}
          ${dots}
          ${xTicks.map(t => `<text x="${sx(t).toFixed(1)}" y="${H-pad.b+15}" font-size="10" text-anchor="middle" fill="#5A6A63">${t}</text>`).join('')}
          ${yTicks.map(t => `<text x="${pad.l-6}" y="${(sy(t)+3).toFixed(1)}" font-size="10" text-anchor="end" fill="#5A6A63">${t}</text>`).join('')}
          <text x="${W/2}" y="${H-5}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17">semanas</text>
          <text x="14" y="${H/2}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17" transform="rotate(-90 14 ${H/2})">mmHg</text>
        </svg>
        <div class="m10-legend">
          <span><span class="m10-dot" style="background:#B0413E"></span>TA sistólica</span>
          <span><span class="m10-dot" style="background:#1F5F4A"></span>TA diastólica</span>
        </div>
      </div>
    `;
  }

  // === Evolución de altura uterina sobre curva CLAP =========================
  function renderAUEvolution() {
    const O = window.Obstetric;
    const fum = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;
    const ref = O.AU_REFERENCE;
    const weeks = Object.keys(ref).map(Number).sort((a, b) => a - b);
    const puntos = state.patient.controles
      .filter(c => c.fecha && c.au != null && fum)
      .map(c => {
        const eg = O.calcEG(fum, O.isoToDate(c.fecha));
        return { sem: eg.fraction, au: c.au, trim: c.trimestre };
      });

    if (puntos.length === 0) {
      return `<div class="card"><div class="card-h"><h2>📏 Altura uterina</h2></div><p class="muted small">Sin datos.</p></div>`;
    }

    const W = 560, H = 280;
    const pad = { l: 40, r: 20, t: 20, b: 40 };
    const innerW = W - pad.l - pad.r, innerH = H - pad.t - pad.b;
    const xMin = 13, xMax = 40, yMin = 0, yMax = 40;
    const sx = w => pad.l + ((w - xMin) / (xMax - xMin)) * innerW;
    const sy = au => pad.t + (1 - (au - yMin) / (yMax - yMin)) * innerH;
    const path = pts => pts.map((p, i) => (i === 0 ? 'M' : 'L') + sx(p.x).toFixed(1) + ' ' + sy(p.y).toFixed(1)).join(' ');
    const p10 = weeks.map(w => ({ x: w, y: ref[w].p10 }));
    const p50 = weeks.map(w => ({ x: w, y: ref[w].p50 }));
    const p90 = weeks.map(w => ({ x: w, y: ref[w].p90 }));

    const pathPaciente = puntos.length >= 2
      ? `<path d="${puntos.map((p,i)=>(i===0?'M':'L')+sx(p.sem).toFixed(1)+' '+sy(p.au).toFixed(1)).join(' ')}" fill="none" stroke="#1F5F4A" stroke-width="2.5"/>` : '';
    const dots = puntos.map(p => `
      <circle cx="${sx(p.sem).toFixed(1)}" cy="${sy(p.au).toFixed(1)}" r="6" fill="#1F5F4A" stroke="white" stroke-width="2"/>
      <text x="${sx(p.sem).toFixed(1)}" y="${(sy(p.au)-10).toFixed(1)}" font-size="10" text-anchor="middle" fill="#1F5F4A" font-weight="600">T${p.trim}: ${p.au}</text>
    `).join('');

    const xTicks = [13, 18, 23, 28, 33, 38];
    const yTicks = [0, 10, 20, 30, 40];

    return `
      <div class="card">
        <div class="card-h">
          <h2>📏 Altura uterina</h2>
          <span class="badge badge-mute tiny mono">CLAP/OPS</span>
        </div>
        <svg viewBox="0 0 ${W} ${H}" class="m10-evol-svg">
          <rect x="${pad.l}" y="${pad.t}" width="${innerW}" height="${innerH}" fill="#fdfbf7" stroke="#e6ddd0" rx="8"/>
          ${yTicks.map(t => `<line x1="${pad.l}" y1="${sy(t).toFixed(1)}" x2="${W-pad.r}" y2="${sy(t).toFixed(1)}" stroke="#E8E2D4" stroke-width="0.5"/>`).join('')}
          <path d="${path(p10)}" fill="none" stroke="#C9893E" stroke-width="1.5" stroke-dasharray="4,3"/>
          <path d="${path(p50)}" fill="none" stroke="#5A6A63" stroke-width="1.5"/>
          <path d="${path(p90)}" fill="none" stroke="#C9893E" stroke-width="1.5" stroke-dasharray="4,3"/>
          ${pathPaciente}
          ${dots}
          ${xTicks.map(t => `<text x="${sx(t).toFixed(1)}" y="${H-pad.b+15}" font-size="10" text-anchor="middle" fill="#5A6A63">${t}</text>`).join('')}
          ${yTicks.map(t => `<text x="${pad.l-6}" y="${(sy(t)+3).toFixed(1)}" font-size="10" text-anchor="end" fill="#5A6A63">${t}</text>`).join('')}
          <text x="${W/2}" y="${H-5}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17">semanas</text>
          <text x="14" y="${H/2}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17" transform="rotate(-90 14 ${H/2})">cm</text>
        </svg>
        <p class="tiny muted mt-2">Líneas punteadas: p10 y p90. Línea gris: mediana. Verde: trayectoria de la paciente.</p>
      </div>
    `;
  }

  // === Evolución de hemoglobina =============================================
  function renderHbEvolution() {
    const O = window.Obstetric;
    const fum = state.patient.cabecera.fum ? O.isoToDate(state.patient.cabecera.fum) : null;
    const puntos = state.patient.controles
      .filter(c => c.fecha && c.hb != null && fum)
      .map(c => {
        const eg = O.calcEG(fum, O.isoToDate(c.fecha));
        return { sem: eg.fraction, hb: c.hb, trim: c.trimestre };
      });

    if (puntos.length === 0) {
      return `<div class="card"><div class="card-h"><h2>🩸 Hemoglobina</h2></div><p class="muted small">Sin datos.</p></div>`;
    }

    const W = 560, H = 280;
    const pad = { l: 50, r: 20, t: 20, b: 40 };
    const innerW = W - pad.l - pad.r, innerH = H - pad.t - pad.b;
    const xMin = 10, xMax = 42, yMin = 6, yMax = 16;
    const sx = w => pad.l + ((w - xMin) / (xMax - xMin)) * innerW;
    const sy = hb => pad.t + (1 - (hb - yMin) / (yMax - yMin)) * innerH;

    const pathHb = puntos.length >= 2
      ? `<path d="${puntos.map((p,i)=>(i===0?'M':'L')+sx(p.sem).toFixed(1)+' '+sy(p.hb).toFixed(1)).join(' ')}" fill="none" stroke="#B0413E" stroke-width="2"/>` : '';
    const dots = puntos.map(p => `
      <circle cx="${sx(p.sem).toFixed(1)}" cy="${sy(p.hb).toFixed(1)}" r="6" fill="${p.hb < 11 ? '#B0413E' : '#1F5F4A'}" stroke="white" stroke-width="2"/>
      <text x="${sx(p.sem).toFixed(1)}" y="${(sy(p.hb)-10).toFixed(1)}" font-size="10" text-anchor="middle" fill="${p.hb < 11 ? '#B0413E' : '#1F5F4A'}" font-weight="600">T${p.trim}: ${p.hb}</text>
    `).join('');

    const yTicks = [6, 8, 10, 11, 12, 14, 16];

    return `
      <div class="card">
        <div class="card-h">
          <h2>🩸 Hemoglobina</h2>
          <span class="badge badge-mute tiny">${puntos.length} control(es)</span>
        </div>
        <svg viewBox="0 0 ${W} ${H}" class="m10-evol-svg">
          <rect x="${pad.l}" y="${pad.t}" width="${innerW}" height="${innerH}" fill="#fdfbf7" stroke="#e6ddd0" rx="8"/>
          <line x1="${pad.l}" y1="${sy(11).toFixed(1)}" x2="${W-pad.r}" y2="${sy(11).toFixed(1)}" stroke="#B0413E" stroke-dasharray="4,4" stroke-width="1.5"/>
          <text x="${W-pad.r-5}" y="${(sy(11)-3).toFixed(1)}" font-size="10" text-anchor="end" fill="#B0413E" font-weight="600">11 g/dL — corte anemia</text>
          ${pathHb}
          ${dots}
          ${yTicks.map(t => `<text x="${pad.l-6}" y="${(sy(t)+3).toFixed(1)}" font-size="10" text-anchor="end" fill="#5A6A63">${t}</text>`).join('')}
          <text x="${W/2}" y="${H-5}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17">semanas</text>
          <text x="14" y="${H/2}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17" transform="rotate(-90 14 ${H/2})">g/dL</text>
        </svg>
      </div>
    `;
  }

  // === Marca de "modificado" ================================================
  function touch() {
    state.patient._meta.actualizado = new Date().toISOString();
  }

  // === Export JSON ==========================================================
  function saveJSON() {
    const c = state.patient.cabecera;
    if (!c.numDoc || !c.apellido) {
      window.State?.toast('Ingresa al menos el número de documento y apellido antes de guardar', 'warn', 3500);
      return;
    }
    const v = validateDoc(c.tipoDoc, c.numDoc);
    if (!v.ok) {
      window.State?.toast('Documento inválido: ' + v.error, 'error');
      return;
    }
    // Nombre de archivo: seguimiento_<TIPO>_<NUMERO>_<APELLIDO>.json
    const apellidoSlug = String(c.apellido).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z]/g, '_').toUpperCase();
    const filename = `seguimiento_${c.tipoDoc}_${v.value}_${apellidoSlug}.json`;
    const payload = JSON.stringify(state.patient, null, 2);
    const blob = new Blob([payload], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 100);
    window.State?.toast(`✓ Guardado: ${filename}`, 'ok', 3500);
  }

  // === Import JSON ==========================================================
  function loadJSON(panel) {
    if (anyDataEntered() && !window.confirm('Se perderán los datos no guardados del paciente actual. ¿Continuar?')) return;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.style.display = 'none';
    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        const data = JSON.parse(text);
        // Validación básica
        if (!data.cabecera || !data.controles || !Array.isArray(data.controles)) {
          throw new Error('Archivo no tiene formato de seguimiento gestante');
        }
        // Migración suave: garantizar que tenga todos los campos
        const fresh = emptyPatient();
        state.patient = mergeDeep(fresh, data);
        state.activeTab = 'cabecera';
        renderAll(panel);
        window.State?.toast(`✓ Paciente cargado: ${data.cabecera.nombre || ''} ${data.cabecera.apellido || ''}`, 'ok');
      } catch (err) {
        window.State?.toast('Error: ' + err.message, 'error', 5000);
        console.error(err);
      }
    });
    document.body.appendChild(input);
    input.click();
    setTimeout(() => input.remove(), 1000);
  }

  function mergeDeep(target, source) {
    if (typeof source !== 'object' || source === null) return source;
    if (Array.isArray(target)) {
      // Para arrays como controles, sobrescribir
      return Array.isArray(source) ? source : target;
    }
    const out = { ...target };
    for (const k of Object.keys(source)) {
      if (typeof source[k] === 'object' && source[k] !== null && !Array.isArray(source[k]) && typeof target[k] === 'object') {
        out[k] = mergeDeep(target[k], source[k]);
      } else {
        out[k] = source[k];
      }
    }
    return out;
  }

  // === Entry point ==========================================================
  window.render_seguimiento = function (panel) {
    renderShell(panel);
    renderAll(panel);
  };
})();
