/* ============================================================================
   m8-suppv-bja.js — Módulo 8: Subsidio Universal Prenatal + Bono Juana Azurduy
   Reescritura del SUPPV-BJA original como tab nativa.
   **Fórmulas, offsets, plantilla y direcciones SEDEM son IDÉNTICAS al original.**
   ============================================================================ */
(function () {
  'use strict';

  // === Constantes EXACTAS del Excel heredado (valores por defecto) ==========
  // Ver imágenes de fórmulas:
  //   SUPPV: Ex = FUM + (7 * semanas) - 1   [semanas: 17, 22, 27, 32]
  //          el fin de cada rango es (inicio del siguiente - 1); el 4to va al parto (FUP)
  //   BJA:   encadenado por meses. A7=FUM; Cx = fin del mes (mesOffset) - 1 día
  //          mesOffsets acumulados: +3, +2, +2, +2 (control = inicio + meses, fin = ese -1 día)
  const GESTACION_DIAS = 280;

  // SUPPV: cada paquete se define por la SEMANA de inicio (multiplicador del Excel).
  const SUPPV_SEMANAS_DEFAULT = [
    { idx: 1, label: '1er paquete', semana: 17 },
    { idx: 2, label: '2do paquete', semana: 22 },
    { idx: 3, label: '3er paquete', semana: 27 },
    { idx: 4, label: '4to paquete', semana: 32 },
  ];
  // BJA: cada control se define por los MESES que se suman respecto al control anterior.
  const BJA_MESES_DEFAULT = [
    { idx: 1, label: '1er control', meses: 3 },  // C7 = FUM + 3 meses - 1 día
    { idx: 2, label: '2do control', meses: 2 },  // C8 = (C7+1) + 2 meses - 1 día
    { idx: 3, label: '3er control', meses: 2 },
    { idx: 4, label: '4to control', meses: 2 },
  ];
  // Plazos de recojo del subsidio (días tras el control) por área
  const PLAZO_AREA_DEFAULT = { urbano: 45, rural: 90 };

  const CONFIG_KEY = 'suppv_bja_config_v2';

  // Carga la config de plazos: usa override de admin si existe, si no los defaults.
  function loadConfig() {
    let cfg = null;
    try { cfg = window.State?.get(CONFIG_KEY); } catch (e) {}
    return {
      suppvSemanas: (cfg && cfg.suppvSemanas) || SUPPV_SEMANAS_DEFAULT.map(o => ({ ...o })),
      bjaMeses:     (cfg && cfg.bjaMeses)     || BJA_MESES_DEFAULT.map(o => ({ ...o })),
      plazo:        (cfg && cfg.plazo)        || { ...PLAZO_AREA_DEFAULT },
    };
  }
  function saveConfig(cfg) {
    try { window.State?.set(CONFIG_KEY, cfg); } catch (e) {}
  }

  // Configuración viva (se rellena en cada render)
  let SUPPV_SEMANAS = SUPPV_SEMANAS_DEFAULT.map(o => ({ ...o }));
  let BJA_MESES = BJA_MESES_DEFAULT.map(o => ({ ...o }));
  let PLAZO_AREA = { ...PLAZO_AREA_DEFAULT };

  // Deriva los rangos de SUPPV en DÍAS desde FUM, replicando E7..E10 del Excel.
  //   inicio_n = (7 * semana_n) - 1   (offset en días desde FUM)
  //   fin_n    = inicio_(n+1) - 1 ; el último va a null (parto)
  function suppvOffsets() {
    const ini = SUPPV_SEMANAS.map(s => (7 * s.semana) - 1);
    return SUPPV_SEMANAS.map((s, i) => ({
      idx: s.idx, label: s.label,
      start: ini[i],
      end: (i < SUPPV_SEMANAS.length - 1) ? (ini[i + 1] - 1) : null,
    }));
  }

  // BJA: calcula los rangos como FECHAS REALES encadenadas desde la FUM,
  // replicando exactamente las fórmulas del Excel (imagen):
  //   A7 = FUM;        C7 = FECHA(año, mes(A7)+meses1, día) - 1 día
  //   A8 = C7 + 1 día; C8 = FECHA(año, mes(A8)+meses2, día) - 1 día
  //   ... y así. Los "meses" son meses de calendario (no de 30 días).
  // Devuelve [{ idx, label, startDate, endDate(null=parto) }]
  function bjaRangos(fum) {
    if (!fum) return [];
    const out = [];
    let inicio = new Date(fum);  // A7 = FUM
    BJA_MESES.forEach((m, i) => {
      // C = FECHA(inicio + meses) - 1 día
      const fin = addDays(addMonths(inicio, m.meses), -1);
      const esUltimo = (i === BJA_MESES.length - 1);
      out.push({
        idx: m.idx,
        label: m.label,
        startDate: new Date(inicio),
        endDate: esUltimo ? null : new Date(fin),
      });
      inicio = addDays(fin, 1);  // siguiente A = C + 1 día
    });
    return out;
  }

  // Compatibilidad: deriva offsets en días desde FUM para "control activo" y grilla.
  // Para BJA, los offsets dependen de la FUM real (meses de calendario), así que
  // se calculan con bjaRangos cuando hay FUM; si no, con una aproximación neutra.
  function getBJA_OFFSETS() {
    if (state.fum) {
      return bjaRangos(state.fum).map(r => ({
        idx: r.idx, label: r.label,
        start: diffDays(state.fum, r.startDate),
        end: r.endDate ? diffDays(state.fum, r.endDate) : null,
      }));
    }
    // Sin FUM: aproximación solo para mostrar algo (no se usa en cálculos finales)
    let inicioDia = 0; const out = [];
    BJA_MESES.forEach((m, i) => {
      const fin = inicioDia + m.meses * 30 - 1;
      out.push({ idx: m.idx, label: m.label, start: inicioDia, end: (i < BJA_MESES.length-1) ? fin : null });
      inicioDia = fin + 1;
    });
    return out;
  }

  function refreshConfig() {
    const c = loadConfig();
    SUPPV_SEMANAS = c.suppvSemanas;
    BJA_MESES = c.bjaMeses;
    PLAZO_AREA = c.plazo;
  }

  // Compatibilidad: el resto del código usa SUPPV_OFFSETS / BJA_OFFSETS (en días).
  function getSUPPV_OFFSETS() { return suppvOffsets(); }

  // Direcciones SEDEM: ahora se leen de DB_SEDEM (editable por admin).
  // Si no está cargada, fallback a la lista embebida.
  const SEDEM_FALLBACK = [
    { id: 1,  area: 'urbano', nombre: 'LA PAZ – Distribuidora La Paz: Av. Jaimes Freyre esq. Calle 1 Nro. 2344, zona Sopocachi.' },
    { id: 2,  area: 'urbano', nombre: 'EL ALTO I – Distribuidora El Alto: Av. Cívica s/n, Mercado Campesino, zona Santa Rosa.' },
    { id: 3,  area: 'urbano', nombre: 'EL ALTO II – Agencia Villa Tunari: Av. Antonio José de Sucre, Mercado Campesino, frente al retén policial.' },
    { id: 4,  area: 'rural',  nombre: 'SAN BUENAVENTURA – Agencia San Buenaventura: Municipio de San Buenaventura, distrito Tumupasa.' },
    { id: 5,  area: 'rural',  nombre: 'LA ASUNTA – Agencia La Asunta: Coliseo Cerrado La Asunta, zona 3 Las Palmeras, calle José Guamán.' },
    { id: 6,  area: 'rural',  nombre: 'CHULUMANI – Agencia Chulumani: Zona central, calle Murillo s/n, media cuadra del Banco Prodem.' },
    { id: 7,  area: 'rural',  nombre: 'IRUPANA – Agencia Irupana: Calle Cochabamba esq. Héroes del Chaco, planta baja del mercado municipal.' },
    { id: 8,  area: 'rural',  nombre: 'CARANAVI – Agencia Caranavi: Zona River Yara, predios de la sede de la Junta de Vecinos.' },
    { id: 9,  area: 'rural',  nombre: 'TUMUPASA – Agencia Tumupasa: Media cuadra de la plaza principal.' },
    { id: 10, area: 'rural',  nombre: 'PATACAMAYA – Agencia Patacamaya: Av. Manco Kapac, zona Villa Lealtad, frente a la Plaza del Estudiante.' },
    { id: 11, area: 'rural',  nombre: 'ACHACHI – Agencia Achachi: Av. Manco Kapac, zona Villa Lealtad, frente a la Plaza del Estudiante.' },
  ];

  function getSedemDirecciones() {
    return (window.DB_SEDEM && window.DB_SEDEM.direcciones) || SEDEM_FALLBACK;
  }

  const STORAGE_KEY = 'suppv_bja_state_v1';

  // === Estado ================================================================
  const state = {
    fum: null, fpp: null, cpn: null,
    area: 'urbano', dirId: '', dirCustom: '', dob: null,
    activeSubtab: 'gestante',  // 'gestante' | 'ninos'
    // Bloque ecográfico (replicado de M3, pero independiente)
    ecoFecha: null, ecoSG: null, fppEco: null,
    // WhatsApp
    waNumero: '',         // último número usado (8 dígitos sin +591)
    msgCustom: '',        // contenido personalizado del textarea (si el usuario editó)
  };

  // === Utilidades de fecha (reutilizan window.Obstetric pero con addMonths) ===
  const O = () => window.Obstetric;
  const isoToDate = (iso) => O().isoToDate(iso);
  const dateToISO = (d) => O().dateToISO(d);
  const addDays   = (d, n) => O().addDays(d, n);
  const diffDays  = (a, b) => O().diffDays(a, b);
  const todayUTC  = () => O().todayUTC();

  function addMonths(date, months) {
    const y = date.getUTCFullYear();
    const m = date.getUTCMonth();
    const d = date.getUTCDate();
    const targetMonth = m + months;
    const lastDay = new Date(Date.UTC(y, targetMonth + 1, 0)).getUTCDate();
    const finalDay = Math.min(d, lastDay);
    return new Date(Date.UTC(y, targetMonth, finalDay));
  }
  function shortDateMini(d) {
    if (!d || isNaN(d.getTime())) return '—';
    const dd = String(d.getUTCDate()).padStart(2,'0');
    const mm = String(d.getUTCMonth()+1).padStart(2,'0');
    const yy = String(d.getUTCFullYear()).slice(-2);
    return `${dd}/${mm}/${yy}`;
  }
  const HUMAN_FMT = new Intl.DateTimeFormat('es-ES', { day:'numeric', month:'long', year:'numeric', timeZone:'UTC' });
  function humanizeDate(d) { return (d && !isNaN(d.getTime())) ? HUMAN_FMT.format(d) : '—'; }
  // Fecha corta para el mensaje de WhatsApp: "26 de agosto" (sin año, más legible)
  const HUMAN_FMT_SHORT = new Intl.DateTimeFormat('es-ES', { day:'numeric', month:'long', timeZone:'UTC' });
  function humanizeDateShort(d) { return (d && !isNaN(d.getTime())) ? HUMAN_FMT_SHORT.format(d) : '—'; }

  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  // === Persistencia (mismo formato que el original, para compatibilidad) =====
  function saveState() {
    try {
      const d = {
        fum: state.fum ? dateToISO(state.fum) : '',
        fpp: state.fpp ? dateToISO(state.fpp) : '',
        cpn: state.cpn ? dateToISO(state.cpn) : '',
        area: state.area, dirId: state.dirId, dirCustom: state.dirCustom,
        dob: state.dob ? dateToISO(state.dob) : '',
        ecoFecha: state.ecoFecha ? dateToISO(state.ecoFecha) : '',
        ecoSG: state.ecoSG,
        fppEco: state.fppEco ? dateToISO(state.fppEco) : '',
        waNumero: state.waNumero || '',
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(d));
    } catch (e) {}
  }
  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (d.fum) state.fum = isoToDate(d.fum);
      if (d.fpp) state.fpp = isoToDate(d.fpp);
      if (d.cpn) state.cpn = isoToDate(d.cpn);
      if (d.area) state.area = d.area;
      if (d.dirId !== undefined) state.dirId = d.dirId;
      if (d.dirCustom) state.dirCustom = d.dirCustom;
      if (d.dob) state.dob = isoToDate(d.dob);
      if (d.ecoFecha) state.ecoFecha = isoToDate(d.ecoFecha);
      if (d.ecoSG != null) state.ecoSG = d.ecoSG;
      if (d.fppEco) state.fppEco = isoToDate(d.fppEco);
      if (d.waNumero) state.waNumero = d.waNumero;
    } catch (e) {}
  }

  // === Lógica obstétrica bidireccional (idéntica al original) ===============
  function calcularSG(fum, ref) {
    if (!fum || !ref) return null;
    const dias = diffDays(ref, fum);
    if (dias < 0) return null;
    return dias / 7;
  }
  function fechaRef() { return state.cpn || todayUTC(); }
  function recalcFPPDesdeFUM() {
    if (state.fum) state.fpp = addDays(state.fum, GESTACION_DIAS);
  }
  function calcularFUMDesdeSG(sg) {
    const dias = Math.round(sg * 7);
    return addDays(fechaRef(), -dias);
  }
  function calcularFUMDesdeFPP(fpp) {
    return addDays(fpp, -GESTACION_DIAS);
  }
  function determinarControlActivo(fum, cpn, offsets) {
    if (!fum || !cpn) return null;
    const dias = diffDays(cpn, fum);
    if (dias < 0) return null;
    for (const off of offsets) {
      const inRange = (off.end === null) ? (dias >= off.start) : (dias >= off.start && dias <= off.end);
      if (inRange) return { ...off, dias };
    }
    return null;
  }

  function direccionSeleccionada() {
    const idStr = String(state.dirId || '');
    if (idStr === '__otro__') return state.dirCustom?.trim() || '[Dirección no especificada]';
    const f = getSedemDirecciones().find(d => String(d.id) === idStr);
    return f ? f.nombre : '[Dirección no especificada]';
  }

  // === Render subtab Gestante (SUPPV + BJA) =================================
  function renderGestanteSubtab() {
    return `
      <div class="m8-grid-2col">
        <div class="card">
          <div class="card-h"><h2>Datos de la gestante</h2></div>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">FUM</span>
              <input type="date" class="field-input" id="m8-fum" />
            </label>
            <label class="field">
              <span class="field-label">SG (semanas)</span>
              <input type="number" class="field-input" id="m8-sg" min="0" max="42" step="0.1" placeholder="ej. 24.5" />
            </label>
            <label class="field">
              <span class="field-label">FPP (Naegele)</span>
              <input type="date" class="field-input" id="m8-fpp" />
            </label>
            <label class="field">
              <span class="field-label">CPN (último control)</span>
              <input type="date" class="field-input" id="m8-cpn" />
            </label>
          </div>
          <div class="m3-section">
            <h3 class="m3-sec-h">Área SEDEM
              <button class="btn btn-ghost m8-edit-plazos" style="font-size:0.75rem;padding:2px 8px;margin-left:8px;display:none;">⚙️ Editar plazos</button>
            </h3>
            <div class="row gap-2">
              <label class="m8-radio">
                <input type="radio" name="m8-area" value="urbano" /> Urbano (${PLAZO_AREA.urbano} días)
              </label>
              <label class="m8-radio">
                <input type="radio" name="m8-area" value="rural" /> Rural (${PLAZO_AREA.rural} días)
              </label>
            </div>
          </div>
          <div class="m3-section">
            <h3 class="m3-sec-h">Dirección SEDEM</h3>
            <select class="field-select" id="m8-dir">
              <option value="">— Seleccionar —</option>
              ${getSedemDirecciones().map(d => `<option value="${d.id}" data-area="${d.area}">${esc(d.nombre)}</option>`).join('')}
              <option value="__otro__">Otra (especificar)</option>
            </select>
            <input type="text" class="field-input mt-2 hidden" id="m8-dir-custom" placeholder="Escribir dirección personalizada" />
            <div id="m8-sedem-admin" class="mt-2"></div>
            <div id="m8-sedem-list" class="mt-2"></div>
          </div>

          <!-- Bloque ecográfico replicado de M3 (no afecta cálculos SUPPV/BJA) -->
          <div class="m3-section">
            <h3 class="m3-sec-h">Datación ecográfica (opcional)</h3>
            <div class="m2-form-grid">
              <label class="field">
                <span class="field-label">Fecha de ecografía</span>
                <input type="date" class="field-input" id="m8-eco-fecha" />
              </label>
              <label class="field">
                <span class="field-label">SG por ecografía (sem)</span>
                <input type="number" class="field-input" id="m8-eco-sg" min="4" max="42" step="0.1" placeholder="ej. 12.4" />
              </label>
              <label class="field">
                <span class="field-label">FPP por ecografía (directa)</span>
                <input type="date" class="field-input" id="m8-fpp-eco" />
              </label>
            </div>
            <div id="m8-eco-compare" class="m3-eco-compare hidden" style="margin-top:var(--space-3);"></div>
            <p class="tiny muted mt-2">Comparación informativa con FUM. No modifica los cálculos SUPPV/BJA.</p>
          </div>
        </div>

        <div>
          <div class="card m8-diag-card" id="m8-diag">
            <div class="card-h">
              <h2>Diagnóstico del control</h2>
            </div>
            <div id="m8-diag-empty" class="empty-state">
              <p class="muted small">Ingresa FUM y CPN para diagnosticar el paquete activo.</p>
            </div>
            <div id="m8-diag-content" class="hidden">
              <div class="m8-diag-grid">
                <div class="m8-diag-cell m8-diag-suppv">
                  <span class="m8-diag-lbl">SUPPV</span>
                  <span class="m8-diag-num" id="m8-suppv-num">—</span>
                  <span class="m8-diag-name" id="m8-suppv-label"></span>
                  <span class="m8-diag-range" id="m8-suppv-range"></span>
                </div>
                <div class="m8-diag-cell m8-diag-bja">
                  <span class="m8-diag-lbl">BJA</span>
                  <span class="m8-diag-num" id="m8-bja-num">—</span>
                  <span class="m8-diag-name" id="m8-bja-label"></span>
                  <span class="m8-diag-range" id="m8-bja-range"></span>
                </div>
              </div>
              <div class="m8-plazo" id="m8-plazo">
                <div class="m8-plazo-lbl">Plazo límite de recojo</div>
                <div class="m8-plazo-date" id="m8-plazo-fecha">—</div>
                <div class="m8-plazo-detail" id="m8-plazo-detalle"></div>
              </div>
            </div>
          </div>

          <div class="card mt-4">
            <div class="card-h"><h2>SUPPV — 4 paquetes</h2><span class="badge badge-mute tiny">desde día 119</span></div>
            <div class="m8-paq-grid" id="m8-suppv-grid"></div>
          </div>

          <div class="card mt-4">
            <div class="card-h"><h2>BJA — 4 controles</h2><span class="badge badge-mute tiny">desde día 0</span></div>
            <div class="m8-paq-grid" id="m8-bja-grid"></div>
          </div>

          <div class="card mt-4">
            <div class="card-h">
              <h2>Mensaje WhatsApp</h2>
              <button class="btn btn-primary" id="m8-gen" style="margin-left:auto;font-size:0.85rem;padding:6px 12px;">Generar plantilla</button>
            </div>
            <p class="tiny muted">Puedes escribir un mensaje libre o presionar <strong>Generar plantilla</strong> para reemplazar con el mensaje estándar SEDEM.</p>
            <textarea class="field-input m8-msg" id="m8-msg" rows="14"
                      placeholder="Escribe un mensaje personalizado o usa 'Generar plantilla' para el mensaje SEDEM estándar..."></textarea>

            <div class="m8-wa-row mt-2">
              <label class="field" style="flex:1;min-width:180px;margin-bottom:0;">
                <span class="field-label">Número WhatsApp (8 dígitos)</span>
                <div class="m8-wa-input">
                  <span class="m8-wa-prefix">+591</span>
                  <input type="tel" class="field-input" id="m8-wa-num"
                         maxlength="8" inputmode="numeric"
                         placeholder="67123456" autocomplete="tel" />
                </div>
                <span class="tiny muted" id="m8-wa-status"></span>
              </label>
              <button class="btn btn-wa" id="m8-send" disabled>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="margin-right:6px;vertical-align:-3px;">
                  <path d="M17.5 14.4c-.3-.1-1.8-.9-2-1s-.5-.1-.7.1-.8 1-.9 1.2-.3.2-.6.1c-.3-.1-1.3-.5-2.5-1.6-.9-.8-1.6-1.8-1.7-2.1-.2-.3 0-.5.1-.6.1-.1.3-.4.4-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5-.1-.1-.7-1.7-1-2.3-.2-.6-.5-.5-.7-.5h-.5c-.2 0-.5.1-.7.4-.3.3-1 1-1 2.4 0 1.4 1 2.8 1.2 3 .1.2 2 3.1 4.8 4.3 1.7.7 2.3.8 3.1.7.5-.1 1.6-.6 1.8-1.3.2-.7.2-1.3.2-1.4-.1-.2-.3-.2-.6-.4zM12 2C6.5 2 2 6.5 2 12c0 1.8.5 3.4 1.3 4.9L2 22l5.3-1.4c1.4.8 3 1.2 4.7 1.2 5.5 0 10-4.5 10-10S17.5 2 12 2z"/>
                </svg>
                Enviar vía WhatsApp
              </button>
              <button class="btn btn-ghost" id="m8-copy" style="white-space:nowrap;">📋 Copiar</button>
            </div>
            <span class="tiny muted" id="m8-msg-status"></span>
          </div>
        </div>
      </div>
    `;
  }

  // === Render subtab Niños (Bono BJA 12 bimestrales) ========================
  function renderNinosSubtab() {
    return `
      <div class="card">
        <div class="card-h"><h2>Datos del menor</h2></div>
        <div class="m2-form-grid">
          <label class="field">
            <span class="field-label">Fecha de nacimiento</span>
            <input type="date" class="field-input" id="m8-dob" />
          </label>
          <div class="field">
            <span class="field-label">Edad calculada</span>
            <div class="m8-edad-display hidden" id="m8-edad-display">
              <span id="m8-edad-texto" class="m3-eg-big" style="font-size:1.4rem;">—</span>
            </div>
          </div>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-h">
          <h2>12 bonos bimestrales</h2>
          <span class="badge badge-mute tiny">Bono Juana Azurduy</span>
          <button class="btn btn-ghost m8-edit-vacunas" style="margin-left:auto;font-size:0.78rem;padding:4px 10px;display:none;">💉 Editar vacunas</button>
        </div>
        <div class="m8-tabla-wrap">
          <table class="m8-tabla">
            <thead>
              <tr>
                <th>#</th><th>Edad</th><th>Período del bono</th><th>Vacunas (PAI)</th>
              </tr>
            </thead>
            <tbody id="m8-ninos-tbody">
              <tr><td colspan="4" class="muted small" style="text-align:center;padding:24px;">Ingresa fecha de nacimiento para generar la tabla.</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  // === Render del grid de paquetes ===========================================
  function renderPaqGrid(containerId, offsets, kind) {
    const c = document.getElementById(containerId);
    if (!c) return;
    if (!state.fum) {
      c.innerHTML = `<div class="empty-state"><p class="muted small">Ingresa la FUM para calcular los rangos.</p></div>`;
      return;
    }
    const activo = state.cpn ? determinarControlActivo(state.fum, state.cpn, offsets) : null;
    const isSuppv = kind === 'suppv';

    // Para BJA usamos las FECHAS REALES encadenadas (meses de calendario),
    // no la conversión a días — así no hay ninguna ambigüedad de redondeo.
    const bjaFechas = (!isSuppv) ? bjaRangos(state.fum) : null;

    c.innerHTML = offsets.map(({ idx, label, start, end }, i) => {
      let startDate, endText;
      if (bjaFechas && bjaFechas[i]) {
        // BJA: fecha real directa
        startDate = bjaFechas[i].startDate;
        const ed = bjaFechas[i].endDate;
        endText = ed ? shortDateMini(ed)
                     : (state.fpp ? `Parto ${shortDateMini(state.fpp)}` : 'Parto');
      } else {
        // SUPPV: offset en días desde FUM (fórmula 7×semana−1)
        startDate = addDays(state.fum, start);
        const endDate = end !== null ? addDays(state.fum, end) : (state.fpp || null);
        endText = end !== null ? shortDateMini(endDate)
                               : (state.fpp ? `Parto ${shortDateMini(state.fpp)}` : 'Parto');
      }
      const isActive = activo && activo.idx === idx;
      return `
        <div class="m8-paq ${isSuppv ? 'is-suppv' : 'is-bja'} ${isActive ? 'is-active' : ''}">
          <div class="m8-paq-num">${idx}</div>
          <div class="m8-paq-body">
            <div class="m8-paq-lbl">${esc(label)}${isActive ? ' ★' : ''}</div>
            <div class="m8-paq-dates">
              <span class="mono">${shortDateMini(startDate)}</span>
              <span class="tiny muted">al</span>
              <span class="mono">${endText}</span>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  // === Render del diagnóstico ===============================================
  function renderDiagnostico() {
    const empty = document.getElementById('m8-diag-empty');
    const content = document.getElementById('m8-diag-content');
    if (!empty || !content) return;

    if (!state.fum || !state.cpn) {
      empty.classList.remove('hidden');
      content.classList.add('hidden');
      return;
    }
    empty.classList.add('hidden');
    content.classList.remove('hidden');

    // SUPPV
    const aSuppv = determinarControlActivo(state.fum, state.cpn, getSUPPV_OFFSETS());
    const $ = id => document.getElementById(id);
    if (!aSuppv) {
      $('m8-suppv-num').textContent = '—';
      $('m8-suppv-label').textContent = 'Aún no corresponde paquete';
      $('m8-suppv-range').textContent = `1er paquete inicia ${shortDateMini(addDays(state.fum, getSUPPV_OFFSETS()[0].start))}`;
    } else {
      $('m8-suppv-num').textContent = aSuppv.idx;
      $('m8-suppv-label').textContent = `${aSuppv.label} (de 4)`;
      const ini = shortDateMini(addDays(state.fum, aSuppv.start));
      const fin = aSuppv.end !== null ? shortDateMini(addDays(state.fum, aSuppv.end))
                                     : (state.fpp ? `Parto ${shortDateMini(state.fpp)}` : 'Parto');
      $('m8-suppv-range').textContent = `${ini} – ${fin}`;
    }

    // BJA
    const aBja = determinarControlActivo(state.fum, state.cpn, getBJA_OFFSETS());
    if (!aBja) {
      $('m8-bja-num').textContent = '—';
      $('m8-bja-label').textContent = 'Aún no corresponde control';
      $('m8-bja-range').textContent = '';
    } else {
      $('m8-bja-num').textContent = aBja.idx;
      $('m8-bja-label').textContent = `${aBja.label} (de 4)`;
      const ini = shortDateMini(addDays(state.fum, aBja.start));
      const fin = aBja.end !== null ? shortDateMini(addDays(state.fum, aBja.end))
                                   : (state.fpp ? `Parto ${shortDateMini(state.fpp)}` : 'Parto');
      $('m8-bja-range').textContent = `${ini} – ${fin}`;
    }

    // Plazo
    const dias = state.area === 'rural' ? 90 : 45;
    const limite = addDays(state.cpn, dias);
    const restantes = diffDays(limite, todayUTC());
    $('m8-plazo-fecha').textContent = humanizeDate(limite);
    const plazoBox = $('m8-plazo');
    if (restantes < 0) {
      $('m8-plazo-detalle').innerHTML = `<strong>Vencido</strong> hace ${Math.abs(restantes)} día(s) · ${state.area === 'rural' ? 'Rural 90d' : 'Urbano 45d'}`;
      plazoBox.classList.remove('is-warn');
      plazoBox.classList.add('is-alert');
    } else {
      $('m8-plazo-detalle').innerHTML = `Faltan <strong>${restantes}</strong> día(s) · ${state.area === 'rural' ? 'Rural 90d' : 'Urbano 45d'}`;
      plazoBox.classList.remove('is-alert');
      plazoBox.classList.add('is-warn');
    }
  }

  // === Tabla de Bono Niños ==================================================
  // Esquema de vacunas por edad (en meses), editable por el admin.
  // Cada entrada: { mes, id (vacuna PAI), nombre }. El id enlaza al módulo 07.
  // CORRECCIÓN: la Antihepatitis B del RN se retiró del esquema por defecto
  // (no corresponde administrarla en ese punto del esquema boliviano vigente).
  const VACUNAS_BONO_DEFAULT = [
    { mes: 0,  id: 'V001', nombre: 'BCG' },
    { mes: 2,  id: 'V002', nombre: 'IPV (1ª)' },
    { mes: 2,  id: 'V004', nombre: 'Pentavalente (1ª)' },
    { mes: 2,  id: 'V005', nombre: 'Antirotavírica (1ª)' },
    { mes: 2,  id: 'V006', nombre: 'Antineumocócica (1ª)' },
    { mes: 4,  id: 'V003', nombre: 'bOPV (1ª)' },
    { mes: 4,  id: 'V004', nombre: 'Pentavalente (2ª)' },
    { mes: 4,  id: 'V005', nombre: 'Antirotavírica (2ª)' },
    { mes: 4,  id: 'V006', nombre: 'Antineumocócica (2ª)' },
    { mes: 6,  id: 'V004', nombre: 'Pentavalente (3ª)' },
    { mes: 6,  id: 'V006', nombre: 'Antineumocócica (3ª)' },
    { mes: 6,  id: 'V009', nombre: 'Anti Influenza' },
    { mes: 12, id: 'V007', nombre: 'SRP (1ª)' },
    { mes: 12, id: 'V013', nombre: 'Antiamarílica' },
    { mes: 18, id: 'V003', nombre: 'bOPV (refuerzo)' },
    { mes: 18, id: 'V004', nombre: 'Pentavalente (refuerzo)' },
    { mes: 18, id: 'V007', nombre: 'SRP (2ª)' },
  ];
  const VACUNAS_BONO_KEY = 'bono_vacunas_v1';

  function getVacunasBono() {
    let v = null;
    try { v = window.State?.get(VACUNAS_BONO_KEY); } catch (e) {}
    return (Array.isArray(v) && v.length) ? v : VACUNAS_BONO_DEFAULT.map(x => ({ ...x }));
  }
  function saveVacunasBono(arr) {
    try { window.State?.set(VACUNAS_BONO_KEY, arr); } catch (e) {}
  }

  // Devuelve las vacunas que caen en el rango [mesMin, mesMax)
  function vacunasEnRango(mesMin, mesMax) {
    return getVacunasBono()
      .filter(v => v.mes >= mesMin && v.mes < mesMax)
      .map(v => ({ ...v }));
  }

  // Editor de vacunas del Bono Niños (admin)
  function promptEditVacunasBono(panel) {
    if (!window.ModalEditor) { window.State?.toast('ModalEditor no disponible', 'error'); return; }
    // Opciones de vacunas desde DB_PAI (para el dropdown de id)
    const paiOpts = (window.DB_PAI?.pai || []).map(v => ({ value: v.id, label: `${v.id} — ${v.vacuna}` }));
    window.ModalEditor.open({
      title: '💉 Esquema de vacunas — Bono Niños',
      size: 'lg',
      schema: [
        { key: '_help', label: '', type: 'info',
          text: 'Define qué vacunas corresponden a cada edad (en meses). El nombre es lo que se muestra; la vacuna PAI es el enlace al módulo 07. Puedes añadir, editar o eliminar filas.' },
        { key: 'vacunas', label: 'Vacunas por edad', type: 'list',
          itemSchema: [
            { key: 'mes',    label: 'Edad (meses)', type: 'number', required: true },
            { key: 'nombre', label: 'Nombre a mostrar', type: 'text', required: true },
            { key: 'id',     label: 'Vacuna en PAI (enlace)', type: 'select',
              options: paiOpts.length ? paiOpts : [{ value: '', label: '(PAI no cargado)' }],
              allowEmpty: true },
          ],
        },
      ],
      data: { vacunas: getVacunasBono() },
      extraButtons: [
        { label: '↺ Restaurar esquema por defecto', onClick: () => {
          saveVacunasBono(VACUNAS_BONO_DEFAULT.map(x => ({ ...x })));
          window.State?.toast('✓ Esquema restaurado', 'ok');
          window.render_suppv_bja(panel);
        }},
      ],
      onSave: (data) => {
        const arr = (data.vacunas || [])
          .filter(v => v.nombre && v.mes != null && v.mes !== '')
          .map(v => ({ mes: parseInt(v.mes), id: v.id || '', nombre: v.nombre }))
          .sort((a, b) => a.mes - b.mes);
        saveVacunasBono(arr);
        window.Auth?.audit('edit_vacunas_bono', `${arr.length} vacunas`);
        window.State?.toast('✓ Esquema de vacunas actualizado', 'ok');
        window.render_suppv_bja(panel);
      },
    });
  }
  window.__m8_promptEditVacunasBono = promptEditVacunasBono;

  function renderNinosTabla() {
    const tbody = document.getElementById('m8-ninos-tbody');
    const box = document.getElementById('m8-edad-display');
    const txt = document.getElementById('m8-edad-texto');
    if (!tbody) return;

    if (!state.dob) {
      if (box) box.classList.add('hidden');
      tbody.innerHTML = `<tr><td colspan="4" class="muted small" style="text-align:center;padding:24px;">Ingresa fecha de nacimiento.</td></tr>`;
      return;
    }
    const hoy = todayUTC();
    let aniosCompletos = hoy.getUTCFullYear() - state.dob.getUTCFullYear();
    const mDiff = hoy.getUTCMonth() - state.dob.getUTCMonth();
    if (mDiff < 0 || (mDiff === 0 && hoy.getUTCDate() < state.dob.getUTCDate())) aniosCompletos--;
    let totalMeses = (hoy.getUTCFullYear() - state.dob.getUTCFullYear()) * 12 + (hoy.getUTCMonth() - state.dob.getUTCMonth());
    if (hoy.getUTCDate() < state.dob.getUTCDate()) totalMeses--;
    const mesesResid = totalMeses - aniosCompletos * 12;

    if (box) box.classList.remove('hidden');
    if (txt) txt.textContent = `${aniosCompletos} año${aniosCompletos !== 1 ? 's' : ''}, ${mesesResid} mes${mesesResid !== 1 ? 'es' : ''} (${totalMeses} m totales)`;

    const rows = [];
    for (let n = 1; n <= 12; n++) {
      const inicio = addMonths(state.dob, (n - 1) * 2);
      const fin = addDays(addMonths(state.dob, n * 2), -1);
      const isCurrent = (hoy >= inicio && hoy <= fin);
      const mesesMin = (n - 1) * 2;
      const mesesMax = n * 2;
      // Vacunas que corresponden en este bimestre
      const vacs = vacunasEnRango(mesesMin, mesesMax);
      const vacHTML = vacs.length
        ? vacs.map(v => `<a class="m8-vac-link" data-vac-id="${v.id}" title="Ver en PAI">💉 ${esc(v.nombre)}</a>`).join(' ')
        : '<span class="tiny muted">Sin vacunas en este periodo</span>';
      rows.push(`
        <tr class="${isCurrent ? 'is-current' : ''}">
          <td><span class="m8-bono-n">${n}</span></td>
          <td class="mono">${mesesMin}–${mesesMax}m${isCurrent ? ' <span class="badge badge-clinic tiny">Actual</span>' : ''}</td>
          <td class="mono small">${shortDateMini(inicio)} <span class="muted tiny">al</span> ${shortDateMini(fin)}</td>
          <td class="m8-tabla-vacunas">${vacHTML}</td>
        </tr>
      `);
    }
    tbody.innerHTML = rows.join('');

    // Bind enlaces a vacunas → módulo PAI
    tbody.querySelectorAll('.m8-vac-link').forEach(a => {
      a.addEventListener('click', () => {
        const id = a.dataset.vacId;
        window.App?.activateTab('pai-vigil');
        setTimeout(() => {
          document.dispatchEvent(new CustomEvent('rb:focus-vacuna', { detail: { id } }));
        }, 300);
      });
    });
  }

  // === Datos completos de la dirección SEDEM seleccionada ==================
  function direccionDataSeleccionada() {
    if (state.dirId === '__otro__') {
      return { nombre: state.dirCustom || '(dirección personalizada)', horario: '', telefono: '', maps_url: '' };
    }
    const d = getSedemDirecciones().find(x => String(x.id) === String(state.dirId));
    return d || null;
  }

  // === Generar mensaje WhatsApp (plantilla EXACTA del original) =============
  // Mejora: solo lista los paquetes PENDIENTES (del control activo en adelante)
  // e incluye horario/teléfono/maps de la oficina seleccionada.
  function generarMensaje() {
    const ta = document.getElementById('m8-msg');
    const status = document.getElementById('m8-msg-status');
    if (!ta) return;
    if (!state.fum || !state.cpn) {
      ta.value = '⚠️ Para generar el mensaje, ingrese al menos la F.U.M. y la fecha del control prenatal (CPN).';
      if (status) status.textContent = 'Faltan datos para generar el mensaje';
      return;
    }
    const dias = PLAZO_AREA[state.area] ?? (state.area === 'rural' ? 90 : 45);
    const fechaLimite = addDays(state.cpn, dias);

    // Determinar el paquete activo (el que se habilita con este control)
    const activo = determinarControlActivo(state.fum, state.cpn, getSUPPV_OFFSETS());
    const activoIdx = activo ? activo.idx : 0;  // 0 = aún no corresponde ninguno

    // Construir SOLO la programación de paquetes PENDIENTES (idx > activoIdx)
    const ordinales = { 1: '1er', 2: '2do', 3: '3er', 4: '4to' };
    const lineasPendientes = getSUPPV_OFFSETS()
      .filter(p => p.idx > activoIdx)
      .map(p => {
        const ini = addDays(state.fum, p.start);
        if (p.end !== null) {
          const fin = addDays(state.fum, p.end);
          return `El *${ordinales[p.idx]}* paquete con un control entre el ${humanizeDateShort(ini)} y el ${humanizeDateShort(fin)}.`;
        }
        return `El *${ordinales[p.idx]}* paquete con un control entre el ${humanizeDateShort(ini)} y el parto.`;
      });

    // Encabezado dinámico según el paquete que se habilita hoy
    let bloquePaquete;
    if (activoIdx === 0) {
      // Aún no corresponde: mostrar todos los plazos como guía
      bloquePaquete =
`*PROGRAMACION DE LOS PAQUETES DE SUBSIDIO*
*TIENE QUE REALIZAR UN CONTROL MEDICO PARA HABILITAR:*
${lineasPendientes.join('\n')}`;
    } else if (lineasPendientes.length > 0) {
      bloquePaquete =
`✅ *Hoy se habilita su ${ordinales[activoIdx]} paquete.*

*SUS PRÓXIMOS PAQUETES PENDIENTES:*
*TIENE QUE REALIZAR UN CONTROL MEDICO PARA HABILITAR:*
${lineasPendientes.join('\n')}`;
    } else {
      // Era el último paquete
      bloquePaquete =
`✅ *Hoy se habilita su ${ordinales[activoIdx]} (último) paquete.*
Este es el último paquete del subsidio, que se habilita con el control previo al parto.`;
    }

    // Datos de la oficina SEDEM seleccionada
    const dir = direccionDataSeleccionada();
    let bloqueDireccion = `📍*DIRECCION*\n${direccionSeleccionada()}`;
    if (dir) {
      if (dir.telefono)  bloqueDireccion += `\n📞 *Teléfono:* ${dir.telefono}`;
      if (dir.horario)   bloqueDireccion += `\n🕐 *Atención:* ${dir.horario}`;
      if (dir.maps_url)  bloqueDireccion += `\n🗺️ *Ubicación:* ${dir.maps_url}`;
    }

    const msg =
`*🌟 SUBSIDIO UNIVERSAL PRENATAL POR LA VIDA 🌟* 
¡Buenas noticias! 😊 Como esta señora, su subsidio se habilitó satisfactoriamente. ¡Puede recogerlo si quiere hoy mismo! 💰. 
*PLAZO PARA RECOGERLO*
El plazo para recoger este subsidio vence el "${humanizeDateShort(fechaLimite)}" (${dias} días, área ${state.area}). Si hasta esa fecha no lo ha recogido, pierde este paquete. ¡Recójalo lo antes posible! ⏱️

*⏰REQUISITOS PARA EL RECOJO DEL SUBSIDIO EN SEDEM*
☑ *Primera vez* presentar cedula de identidad original y vigente más 2 fotocopias de la cedula de Identidad. 
☑ *Posteriormente* solo presentar la cedula de identidad. 

${bloqueDireccion}

${bloquePaquete}

*Todos los controles deben ser realizados en el centro de salud.*
*Una vez realizado el control prenatal debe aproximarse a la oficina del Bono Juana Azurduy y se procederá a la habilitación de un nuevo paquete de subsidio*`;
    ta.value = msg;
    if (status) status.textContent = `Mensaje generado · ${msg.length} caracteres · paquete activo: ${activoIdx || 'ninguno aún'}`;
  }

  // === Render del bloque ecográfico comparativo (M8) =======================
  // Compara la EG por FUM contra la EG por ecografía (vía SG o vía FPP).
  // No afecta los cálculos SUPPV/BJA — es solo informativo.
  function renderEcoCompare() {
    const box = document.getElementById('m8-eco-compare');
    if (!box) return;
    if (!state.fum) {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }
    const O = window.Obstetric;
    if (!O) { box.classList.add('hidden'); return; }

    // EG por FUM al día del CPN (o hoy si no hay CPN)
    const refDate = state.cpn || todayUTC();
    const egFum = O.calcEG(state.fum, refDate);
    const fppN = O.fppNaegele(state.fum);

    // Vía SG por ecografía
    let egEcoSG = null, fppEcoSG = null;
    if (state.ecoFecha && state.ecoSG) {
      const fumEco = O.fumFromEcoSG(state.ecoSG, state.ecoFecha);
      egEcoSG = O.calcEG(fumEco, refDate);
      fppEcoSG = O.fppNaegele(fumEco);
    }
    // Vía FPP eco directa
    let fumDesdeFppEco = null;
    if (state.fppEco) {
      fumDesdeFppEco = addDays(state.fppEco, -GESTACION_DIAS);
    }

    if (!egEcoSG && !state.fppEco) {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }
    box.classList.remove('hidden');

    const rows = [];
    if (egEcoSG && fppEcoSG) {
      const diffSem = (egEcoSG.fraction - egFum.fraction);
      const diffDiasFPP = O.diffDays(fppEcoSG, fppN);
      const tier = Math.abs(diffSem) > 1 ? 'badge-rose' : Math.abs(diffSem) > 0.5 ? 'badge-ochre' : 'badge-clinic';
      rows.push(`
        <div><strong>Eco vía SG:</strong> ${egEcoSG.weeks} sem ${egEcoSG.days} d
        (Δ ${diffSem.toFixed(1)} sem vs FUM) · FPP eco: ${shortDateMini(fppEcoSG)}
        <span class="badge ${tier}">${diffDiasFPP >= 0 ? '+' : ''}${diffDiasFPP} d vs Naegele</span></div>
      `);
    }
    if (state.fppEco) {
      const diffDiasFPP = O.diffDays(state.fppEco, fppN);
      const diffFUM = O.diffDays(fumDesdeFppEco, state.fum);
      const tier = Math.abs(diffDiasFPP) > 7 ? 'badge-rose' : Math.abs(diffDiasFPP) > 3 ? 'badge-ochre' : 'badge-clinic';
      rows.push(`
        <div><strong>FPP eco directa:</strong> ${shortDateMini(state.fppEco)}
        <span class="badge ${tier}">${diffDiasFPP >= 0 ? '+' : ''}${diffDiasFPP} d vs Naegele</span>
        · FUM derivada: ${shortDateMini(fumDesdeFppEco)} (${diffFUM >= 0 ? '+' : ''}${diffFUM} d vs FUM declarada)</div>
      `);
    }

    box.innerHTML = rows.join('');
  }

  // === Re-render global =====================================================
  // skipInput: id del input que NO debe ser sobreescrito (el que el usuario está editando)
  function rerenderGestante(skipInput) {
    const $ = id => document.getElementById(id);
    if ($('m8-fum') && skipInput !== 'm8-fum') {
      $('m8-fum').value = state.fum ? dateToISO(state.fum) : '';
    }
    if ($('m8-sg') && skipInput !== 'm8-sg' && state.fum) {
      const sg = calcularSG(state.fum, fechaRef());
      $('m8-sg').value = sg ? sg.toFixed(1) : '';
    }
    if ($('m8-fpp') && skipInput !== 'm8-fpp') {
      $('m8-fpp').value = state.fpp ? dateToISO(state.fpp) : '';
    }
    if ($('m8-cpn') && skipInput !== 'm8-cpn') {
      $('m8-cpn').value = state.cpn ? dateToISO(state.cpn) : '';
    }
    // Bloque ecográfico replicado
    if ($('m8-eco-fecha') && skipInput !== 'm8-eco-fecha') {
      $('m8-eco-fecha').value = state.ecoFecha ? dateToISO(state.ecoFecha) : '';
    }
    if ($('m8-eco-sg') && skipInput !== 'm8-eco-sg') {
      $('m8-eco-sg').value = state.ecoSG != null ? state.ecoSG : '';
    }
    if ($('m8-fpp-eco') && skipInput !== 'm8-fpp-eco') {
      $('m8-fpp-eco').value = state.fppEco ? dateToISO(state.fppEco) : '';
    }

    renderPaqGrid('m8-suppv-grid', getSUPPV_OFFSETS(), 'suppv');
    renderPaqGrid('m8-bja-grid', getBJA_OFFSETS(), 'bja');
    renderDiagnostico();
    renderEcoCompare();
  }

  // === Bind del formulario ==================================================
  function bindGestanteForm() {
    const $ = id => document.getElementById(id);

    // === FUM: fix del bug del salto ===
    // Solo procesar cuando el valor parseado es una fecha VÁLIDA y completa.
    // No re-renderizar el propio campo (skipInput).
    $('m8-fum')?.addEventListener('change', e => {
      const val = e.target.value;
      // El input type=date dispara 'change' solo cuando hay una fecha completa o se borra
      const parsed = val ? isoToDate(val) : null;
      state.fum = parsed;
      if (parsed) recalcFPPDesdeFUM();
      else state.fpp = null;
      saveState();
      rerenderGestante('m8-fum');
    });

    $('m8-sg')?.addEventListener('change', e => {
      const sg = parseFloat(e.target.value);
      if (sg > 0 && isFinite(sg)) {
        state.fum = calcularFUMDesdeSG(sg);
        recalcFPPDesdeFUM();
        saveState();
        rerenderGestante('m8-sg');
      }
    });
    $('m8-fpp')?.addEventListener('change', e => {
      const fpp = isoToDate(e.target.value);
      if (fpp) {
        state.fpp = fpp;
        state.fum = calcularFUMDesdeFPP(fpp);
        saveState();
        rerenderGestante('m8-fpp');
      }
    });
    $('m8-cpn')?.addEventListener('change', e => {
      state.cpn = isoToDate(e.target.value);
      saveState();
      rerenderGestante('m8-cpn');
    });

    // === Bloque ecográfico (informativo, no afecta SUPPV/BJA) ===
    $('m8-eco-fecha')?.addEventListener('change', e => {
      state.ecoFecha = isoToDate(e.target.value);
      saveState();
      rerenderGestante('m8-eco-fecha');
    });
    $('m8-eco-sg')?.addEventListener('change', e => {
      const v = parseFloat(e.target.value);
      state.ecoSG = (v > 0 && isFinite(v)) ? v : null;
      saveState();
      rerenderGestante('m8-eco-sg');
    });
    $('m8-fpp-eco')?.addEventListener('change', e => {
      state.fppEco = isoToDate(e.target.value);
      saveState();
      rerenderGestante('m8-fpp-eco');
    });

    // === Área SEDEM ===
    document.querySelectorAll('input[name="m8-area"]').forEach(r => {
      r.addEventListener('change', e => {
        state.area = e.target.value;
        saveState();
        rerenderGestante();
      });
    });

    // === Dirección SEDEM ===
    $('m8-dir')?.addEventListener('change', e => {
      state.dirId = e.target.value;
      const cust = $('m8-dir-custom');
      if (state.dirId === '__otro__') cust.classList.remove('hidden');
      else cust.classList.add('hidden');
      saveState();
    });
    $('m8-dir-custom')?.addEventListener('input', e => {
      state.dirCustom = e.target.value;
      saveState();
    });

    // === Mensaje WhatsApp ===
    const ta = $('m8-msg');
    ta?.addEventListener('input', () => {
      // Capturar mensaje personalizado para no perderlo si el usuario escribe
      state.msgCustom = ta.value;
    });
    $('m8-gen')?.addEventListener('click', () => {
      generarMensaje();         // sobrescribe ta.value con la plantilla SEDEM
      state.msgCustom = ta.value;
    });
    $('m8-copy')?.addEventListener('click', async () => {
      if (!ta || !ta.value) {
        window.State?.toast('No hay mensaje para copiar', 'warn');
        return;
      }
      try {
        await navigator.clipboard.writeText(ta.value);
        window.State?.toast('Mensaje copiado al portapapeles', 'ok');
      } catch (err) {
        ta.select();
        window.State?.toast('Selecciona y copia con Ctrl+C', 'warn');
      }
    });

    // === Número WhatsApp + enviar ===
    const waInput = $('m8-wa-num');
    const waStatus = $('m8-wa-status');
    const sendBtn = $('m8-send');

    function validateWa() {
      const v = (waInput?.value || '').replace(/\D/g, '').slice(0, 8);
      if (waInput && waInput.value !== v) waInput.value = v;  // normaliza
      const ok = /^[6-7]\d{7}$/.test(v);  // celular Bolivia empieza con 6 o 7
      if (sendBtn) sendBtn.disabled = !ok || !ta?.value;
      if (waStatus) {
        if (!v) {
          waStatus.textContent = '';
          waStatus.className = 'tiny muted';
        } else if (ok) {
          waStatus.textContent = `✓ Número válido: +591 ${v.slice(0,4)} ${v.slice(4)}`;
          waStatus.className = 'tiny';
          waStatus.style.color = 'var(--clinic)';
        } else {
          waStatus.textContent = '⚠ El celular boliviano debe empezar con 6 ó 7 y tener 8 dígitos';
          waStatus.className = 'tiny';
          waStatus.style.color = 'var(--rose)';
        }
      }
      return ok ? v : null;
    }

    waInput?.addEventListener('input', () => {
      validateWa();
      state.waNumero = waInput.value.replace(/\D/g, '').slice(0, 8);
      saveState();
    });
    // Pre-cargar último número usado
    if (state.waNumero && waInput) {
      waInput.value = state.waNumero;
      validateWa();
    }

    // Re-validar cada vez que cambia el mensaje
    ta?.addEventListener('input', validateWa);

    sendBtn?.addEventListener('click', () => {
      const num = validateWa();
      if (!num) {
        window.State?.toast('Número inválido', 'warn');
        return;
      }
      if (!ta?.value) {
        window.State?.toast('Escribe o genera un mensaje primero', 'warn');
        return;
      }
      // wa.me requiere número internacional sin '+' ni espacios
      const url = `https://wa.me/591${num}?text=${encodeURIComponent(ta.value)}`;
      window.open(url, '_blank', 'noopener,noreferrer');
      window.Auth?.audit('whatsapp_send', `+591${num} (${ta.value.length} chars)`);
    });

    // Reflejar el estado inicial en los inputs
    document.querySelectorAll('input[name="m8-area"]').forEach(r => {
      r.checked = (r.value === state.area);
    });
    if (state.dirId) {
      $('m8-dir').value = state.dirId;
      if (state.dirId === '__otro__') {
        $('m8-dir-custom').classList.remove('hidden');
        $('m8-dir-custom').value = state.dirCustom || '';
      }
    }
    // CPN: si no hay valor guardado, inicializar a HOY
    if (!state.cpn) {
      state.cpn = todayUTC();
      saveState();
    }
    // Refrescar valores iniciales en inputs (sin saltarse ninguno)
    rerenderGestante();
    // Validar número al cargar
    validateWa();
  }

  function bindNinosForm() {
    const $ = id => document.getElementById(id);
    $('m8-dob')?.addEventListener('change', e => {
      state.dob = isoToDate(e.target.value);
      saveState(); renderNinosTabla();
    });
    if (state.dob) $('m8-dob').value = dateToISO(state.dob);
  }

  // === Cambio de subtab =====================================================
  function switchSubtab(s) {
    state.activeSubtab = s;
    document.querySelectorAll('.m8-subtab').forEach(b => {
      b.classList.toggle('is-active', b.dataset.subtab === s);
    });
    document.querySelectorAll('.m8-subpanel').forEach(p => {
      p.classList.toggle('is-active', p.dataset.subpanel === s);
    });
  }

  // === Entry point ==========================================================
  window.render_suppv_bja = function (panel) {
    if (!window.Obstetric) {
      panel.innerHTML = '<div class="empty-state">Módulo obstétrico no disponible</div>';
      return;
    }
    refreshConfig();  // cargar plazos (defaults u override de admin)
    loadState();

    // Cargar DB_SEDEM si aún no está
    const renderSelf = () => {
      if (window.State?.applyAdminOverride('DB_SEDEM', 'sedem')) {
        // override aplicado
      }
      doRender();
    };

    if (!window.DB_SEDEM) {
      window.State.loadScript('data/db_sedem.js')
        .then(renderSelf)
        .catch(() => doRender());  // fallback silencioso si falla
    } else {
      renderSelf();
    }

    function doRender() {
      panel.innerHTML = `
        <div class="m6-header">
          <div>
            <h1>SUPPV · Bono Juana Azurduy</h1>
            <p class="muted small">Subsidio Universal Prenatal por la Vida + BJA · Bolivia</p>
          </div>
        </div>
        <div class="m7-tabs">
          <button class="m7-tab m8-subtab is-active" data-subtab="gestante">🤰 Gestante (SUPPV + BJA)</button>
          <button class="m7-tab m8-subtab" data-subtab="ninos">👶 Bono Niños (12 bimestrales)</button>
        </div>
        <div class="m7-section is-active m8-subpanel" data-subpanel="gestante">
          ${renderGestanteSubtab()}
        </div>
        <div class="m7-section m8-subpanel" data-subpanel="ninos">
          ${renderNinosSubtab()}
        </div>
      `;

      panel.querySelectorAll('.m8-subtab').forEach(b => {
        b.addEventListener('click', () => switchSubtab(b.dataset.subtab));
      });

      // Toolbar admin SEDEM (dentro del card de dirección)
      const sedemBox = document.getElementById('m8-sedem-admin');
      if (sedemBox && window.Auth?.isAdmin()) {
        sedemBox.innerHTML = window.State.renderAdminToolbar('DB_SEDEM', { ns: 'sedem' });
        const bar = sedemBox.querySelector('.rb-admin-tools');
        window.State.bindAdminToolbar(bar, {
          filename: 'db_sedem.js',
          onChange: () => window.render_suppv_bja(panel),
          onAdd: () => promptNewSedem(panel),
        });
      }

      // Lista admin con editar/eliminar por oficina
      if (typeof window.__m8_renderSedemAdminList === 'function') {
        window.__m8_renderSedemAdminList(panel);
      }

      // Botón editar plazos (solo admin)
      const btnPlazos = panel.querySelector('.m8-edit-plazos');
      if (btnPlazos && window.Auth?.isAdmin()) {
        btnPlazos.style.display = '';
        btnPlazos.addEventListener('click', () => {
          window.Auth?.gateAdmin(() => promptEditPlazos(panel));
        });
      }

      // Botón editar vacunas del Bono Niños (solo admin)
      const btnVac = panel.querySelector('.m8-edit-vacunas');
      if (btnVac && window.Auth?.isAdmin()) {
        btnVac.style.display = '';
        btnVac.addEventListener('click', () => {
          window.Auth?.gateAdmin(() => promptEditVacunasBono(panel));
        });
      }

      bindGestanteForm();
      bindNinosForm();
      renderNinosTabla();
    }
  };

  // === Admin: gestión de direcciones SEDEM =================================
  const SEDEM_SCHEMA = [
    { key: 'nombre',        label: 'Nombre completo de la oficina/dirección', type: 'text', required: true,
      help: 'Ej: "LA PAZ – Distribuidora La Paz: Av. Jaimes Freyre esq. Calle 1 Nro. 2344, zona Sopocachi."' },
    { key: 'area',          label: 'Área',                        type: 'select',
      options: [
        { value: 'urbano', label: 'Urbano' },
        { value: 'rural',  label: 'Rural' },
      ], required: true, allowEmpty: false, default: 'urbano' },
    { key: 'maps_url',      label: 'Link de Google Maps',         type: 'text',
      help: 'Pega aquí la URL de Google Maps de la oficina. Ej: https://maps.app.goo.gl/...' },
    { key: 'telefono',      label: 'Teléfono / contacto',         type: 'text', help: 'Ej: "+591 2 2123456" o "+591 71234567"' },
    { key: 'horarios',      label: 'Horarios de atención (hasta 3 bloques)', type: 'list',
      help: 'Marca los días y pon hora de entrada y salida. La app arma la frase automáticamente.',
      itemSchema: [
        { key: 'dias',    label: 'Días',          type: 'weekdays' },
        { key: 'entrada', label: 'Hora entrada',  type: 'time' },
        { key: 'salida',  label: 'Hora salida',   type: 'time' },
      ],
    },
    { key: 'observaciones', label: 'Observaciones',               type: 'textarea', rows: 3,
      help: 'Indicaciones para llegar, referencias, etc.' },
  ];

  // Compone la frase de horarios a partir de los bloques estructurados
  function composeHorario(horarios) {
    if (!Array.isArray(horarios) || horarios.length === 0) return '';
    const ordenDias = ['lunes','martes','miércoles','jueves','viernes','sábado','domingo'];
    const partes = horarios
      .filter(b => b.dias && b.dias.length && b.entrada && b.salida)
      .map(b => {
        const dias = b.dias.slice().sort((a, c) => ordenDias.indexOf(a) - ordenDias.indexOf(c));
        let diasStr;
        if (dias.length === 1) {
          diasStr = dias[0];
        } else {
          diasStr = dias.slice(0, -1).join(', ') + ' y ' + dias[dias.length - 1];
        }
        return `${diasStr} de ${b.entrada} a ${b.salida}`;
      });
    if (partes.length === 0) return '';
    return 'Los horarios de atención son: ' + partes.join('; ') + '.';
  }

  function promptNewSedem(panel) {
    if (!window.ModalEditor) {
      window.State?.toast('ModalEditor no disponible', 'error');
      return;
    }
    window.ModalEditor.open({
      title: 'Nueva oficina SEDEM',
      schema: SEDEM_SCHEMA,
      data: { area: 'urbano' },
      size: 'lg',
      onSave: (data) => {
        if (!window.DB_SEDEM) window.DB_SEDEM = { direcciones: [], meta: {} };
        data.horario = composeHorario(data.horarios);
        const maxId = window.DB_SEDEM.direcciones.reduce((m, d) => Math.max(m, +d.id || 0), 0);
        const nueva = { id: maxId + 1, ...data };
        window.DB_SEDEM.direcciones.push(nueva);
        window.State.persistAdminDB('DB_SEDEM', 'sedem');
        window.Auth?.audit('add_sedem', `#${nueva.id}: ${data.nombre}`);
        window.State?.toast(`✓ Oficina #${nueva.id} agregada`, 'ok');
        window.render_suppv_bja(panel);
      },
    });
  }

  function promptEditSedem(dirObj, panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: `Editar oficina SEDEM #${dirObj.id}`,
      schema: SEDEM_SCHEMA,
      data: dirObj,
      size: 'lg',
      onSave: (data) => {
        data.horario = composeHorario(data.horarios);
        Object.assign(dirObj, data);
        window.State.persistAdminDB('DB_SEDEM', 'sedem');
        window.Auth?.audit('edit_sedem', `#${dirObj.id}: ${data.nombre}`);
        window.State?.toast(`✓ Oficina actualizada`, 'ok');
        window.render_suppv_bja(panel);
      },
    });
  }

  function deleteSedem(id, panel) {
    if (!window.DB_SEDEM) return;
    const d = window.DB_SEDEM.direcciones.find(x => x.id === id);
    if (!d) return;
    if (!window.confirm(`¿Eliminar oficina "${d.nombre}"?`)) return;
    window.DB_SEDEM.direcciones = window.DB_SEDEM.direcciones.filter(x => x.id !== id);
    window.State.persistAdminDB('DB_SEDEM', 'sedem');
    window.Auth?.audit('delete_sedem', `#${id}`);
    window.State?.toast('✓ Oficina eliminada', 'ok');
    window.render_suppv_bja(panel);
  }

  // Renderiza la lista admin de SEDEM (con editar/eliminar) debajo del select
  function renderSedemAdminList(panel) {
    const adminListBox = document.getElementById('m8-sedem-list');
    if (!adminListBox) return;
    if (!window.Auth?.isAdmin()) {
      adminListBox.innerHTML = '';
      return;
    }
    const dirs = getSedemDirecciones();
    adminListBox.innerHTML = `
      <div class="m8-sedem-admin-list">
        <div class="tiny muted" style="margin-bottom:4px;font-weight:600;">${dirs.length} oficina(s) configurada(s):</div>
        ${dirs.map(d => `
          <div class="m8-sedem-row">
            <div class="m8-sedem-info">
              <strong>#${d.id}</strong> ${esc(d.nombre)}
              <div class="tiny muted">
                <span class="badge badge-mute tiny mono">${esc(d.area || 'urbano')}</span>
                ${d.horario ? ' · 🕐 ' + esc(d.horario) : ''}
                ${d.telefono ? ' · 📞 ' + esc(d.telefono) : ''}
                ${d.maps_url ? ' · <a href="'+esc(d.maps_url)+'" target="_blank" rel="noopener">📍 Maps</a>' : ''}
              </div>
            </div>
            <div class="m8-sedem-actions">
              <button class="btn btn-ghost m8-sedem-edit" data-id="${d.id}" style="font-size:0.78rem;padding:4px 8px;">✏️</button>
              <button class="btn btn-ghost m8-sedem-del"  data-id="${d.id}" style="font-size:0.78rem;padding:4px 8px;color:var(--rose);">🗑️</button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    adminListBox.querySelectorAll('.m8-sedem-edit').forEach(b => {
      b.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => {
          const dir = window.DB_SEDEM.direcciones.find(d => String(d.id) === b.dataset.id);
          if (dir) promptEditSedem(dir, panel);
        });
      });
    });
    adminListBox.querySelectorAll('.m8-sedem-del').forEach(b => {
      b.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => deleteSedem(parseInt(b.dataset.id), panel));
      });
    });
  }

  // Exponer para llamada desde el render principal del módulo
  window.__m8_renderSedemAdminList = renderSedemAdminList;

  // === Admin: editar plazos del cálculo (SUPPV, BJA, días por área) =========
  function promptEditPlazos(panel) {
    if (!window.ModalEditor) {
      window.State?.toast('ModalEditor no disponible', 'error');
      return;
    }
    refreshConfig();
    window.ModalEditor.open({
      title: 'Editar plazos del cálculo',
      size: 'lg',
      schema: [
        { key: '_help', label: '', type: 'info',
          text: 'Estos valores replican las fórmulas del Excel heredado.\n\nSUPPV: cada paquete inicia en FUM + (7 × semana) − 1 día. Edita la SEMANA de cada paquete (Excel: 17, 22, 27, 32). El fin de cada rango se calcula solo (un día antes del siguiente).\n\nBJA: cada control suma MESES al control anterior (Excel: +3, +2, +2, +2). Edita los meses de cada control.\n\nSolo cambia los números si la normativa se actualiza. Las etiquetas no cambian.' },
        { key: 'plazoUrbano', label: 'Plazo de recojo URBANO (días tras control)', type: 'number', default: PLAZO_AREA.urbano },
        { key: 'plazoRural',  label: 'Plazo de recojo RURAL (días tras control)',  type: 'number', default: PLAZO_AREA.rural },
        { key: 'suppv', label: 'SUPPV — 4 paquetes (semana de inicio)', type: 'list',
          help: 'Fórmula: FUM + (7 × semana) − 1. Valores del Excel: 17, 22, 27, 32.',
          itemSchema: [
            { key: 'label',  label: 'Etiqueta', type: 'text' },
            { key: 'semana', label: 'Semana (multiplicador ×7)', type: 'number' },
          ],
        },
        { key: 'bja', label: 'BJA — 4 controles (meses a sumar)', type: 'list',
          help: 'Cada control = control anterior + estos meses − 1 día. Valores del Excel: 3, 2, 2, 2.',
          itemSchema: [
            { key: 'label', label: 'Etiqueta', type: 'text' },
            { key: 'meses', label: 'Meses a sumar', type: 'number' },
          ],
        },
      ],
      data: {
        plazoUrbano: PLAZO_AREA.urbano,
        plazoRural: PLAZO_AREA.rural,
        suppv: SUPPV_SEMANAS.map(o => ({ label: o.label, semana: o.semana })),
        bja: BJA_MESES.map(o => ({ label: o.label, meses: o.meses })),
      },
      extraButtons: [
        { label: '↺ Restaurar valores del Excel', onClick: () => {
          saveConfig({
            suppvSemanas: SUPPV_SEMANAS_DEFAULT.map(o => ({ ...o })),
            bjaMeses: BJA_MESES_DEFAULT.map(o => ({ ...o })),
            plazo: { ...PLAZO_AREA_DEFAULT },
          });
          refreshConfig();
          window.State?.toast('✓ Restaurado a valores del Excel', 'ok');
          window.render_suppv_bja(panel);
        }},
      ],
      onSave: (data) => {
        const cfg = {
          plazo: {
            urbano: parseInt(data.plazoUrbano) || PLAZO_AREA_DEFAULT.urbano,
            rural:  parseInt(data.plazoRural)  || PLAZO_AREA_DEFAULT.rural,
          },
          suppvSemanas: (data.suppv || []).map((o, i) => ({
            idx: i + 1,
            label: o.label || SUPPV_SEMANAS_DEFAULT[i]?.label || `${i+1}º paquete`,
            semana: parseInt(o.semana) || SUPPV_SEMANAS_DEFAULT[i]?.semana,
          })),
          bjaMeses: (data.bja || []).map((o, i) => ({
            idx: i + 1,
            label: o.label || BJA_MESES_DEFAULT[i]?.label || `${i+1}º control`,
            meses: parseInt(o.meses) || BJA_MESES_DEFAULT[i]?.meses,
          })),
        };
        saveConfig(cfg);
        refreshConfig();
        window.Auth?.audit('edit_plazos', `urbano=${cfg.plazo.urbano} rural=${cfg.plazo.rural}`);
        window.State?.toast('✓ Plazos actualizados', 'ok');
        window.render_suppv_bja(panel);
      },
    });
  }
  window.__m8_promptEditPlazos = promptEditPlazos;
})();
