/* ============================================================================
   m4-vademecum.js — Módulo 4: Vademécum LINAME + Calculadora de Dosis
   Lista filtrable de 777 fármacos.
   Calculadora adaptativa por peso/dosis/concentración con detección de unidades.
   ============================================================================ */
(function () {
  'use strict';

  const state = {
    db: null,
    selected: null,
    filter: { query: '', programa: '', forma: '' },
  };

  // === Utilidades ===========================================================
  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }
  function normalize(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }
  function paragraphs(text) {
    if (!text) return '';
    return text.split(/\n+/).map(l => l.trim()).filter(Boolean)
      .map(l => `<p>${esc(l)}</p>`).join('');
  }

  // === Parser de concentración ==============================================
  /**
   * De "100 mg/5 ml" → {mg: 100, ml: 5}
   *    "300 mg"      → {mg: 300, unit: 'comprimido'}
   *    "0.4"         → {raw: '0.4'} (formato no reconocido)
   *    "500 mg/ml"   → {mg: 500, ml: 1}
   *    "1 g"         → {mg: 1000, unit: 'comprimido'}
   */
  function parseConcentration(text, forma) {
    const t = String(text || '').trim();
    if (!t) return null;

    // mg/ml o mg/X ml
    let m = t.match(/(\d+(?:[.,]\d+)?)\s*(mg|mcg|µg|g)\s*\/\s*(\d+(?:[.,]\d+)?)?\s*(ml|l|gota)/i);
    if (m) {
      const cant = parseFloat(m[1].replace(',', '.'));
      const factor = m[2].toLowerCase() === 'g' ? 1000
                  : (m[2].toLowerCase() === 'mcg' || m[2].toLowerCase() === 'µg') ? 0.001 : 1;
      const vol = m[3] ? parseFloat(m[3].replace(',', '.')) : 1;
      return {
        mg_per_ml: (cant * factor) / vol,
        kind: 'liquid',
        display: `${cant * factor} mg / ${vol} ml`,
      };
    }
    // simple X mg (o g, mcg)
    m = t.match(/(\d+(?:[.,]\d+)?)\s*(mg|mcg|µg|g|UI)/i);
    if (m) {
      const cant = parseFloat(m[1].replace(',', '.'));
      const unit = m[2].toLowerCase();
      if (unit === 'ui') {
        return { ui_per_unit: cant, kind: 'ui', display: `${cant} UI` };
      }
      const factor = unit === 'g' ? 1000 : (unit === 'mcg' || unit === 'µg') ? 0.001 : 1;
      // Detectar si es sólido (comprimido, cápsula) o líquido (gota, jarabe)
      const liquidoForma = /jarabe|suspens|solución|gota|emulsi|ampoll|inyect/i.test(forma || '');
      return {
        mg_per_unit: cant * factor,
        kind: liquidoForma ? 'liquid_simple' : 'solid',
        display: `${cant * factor} mg por ${liquidoForma ? 'ml' : 'unidad'}`,
        unidad_label: liquidoForma ? 'ml' : (forma || '').toLowerCase().includes('cápsula') ? 'cápsula' : 'comprimido',
      };
    }
    return { raw: t, kind: 'unparseable' };
  }

  // === Filtrado de la lista ==================================================
  function getFiltered() {
    if (!state.db) return [];
    const { query, programa, forma } = state.filter;
    const nq = normalize(query);
    return state.db.vademecum.filter(f => {
      if (programa && !f.programa.toLowerCase().includes(programa.toLowerCase())) return false;
      if (forma && f.forma !== forma) return false;
      if (nq) {
        const hay = normalize(
          f.medicamento + ' ' + f.forma + ' ' + f.concentracion + ' ' +
          f.programa + ' ' + (f.patologias_eleccion || '')
        );
        if (!hay.includes(nq)) return false;
      }
      return true;
    });
  }

  // === Renderizado de la lista ==============================================
  function renderList() {
    const listEl = document.getElementById('m4-list');
    const countEl = document.getElementById('m4-count');
    if (!listEl) return;

    const items = getFiltered();
    countEl.textContent = `${items.length} fármaco${items.length === 1 ? '' : 's'}`;

    if (items.length === 0) {
      listEl.innerHTML = `<div class="empty-state"><div class="empty-state-title">Sin resultados</div></div>`;
      return;
    }

    // Ordenar por nombre genérico
    items.sort((a, b) => a.medicamento.localeCompare(b.medicamento, 'es'));

    listEl.innerHTML = items.map(f => {
      const sel = state.selected === f.id ? ' is-selected' : '';
      const prog = f.programa ? `<span class="m6-list-espe">${esc(f.programa)}</span>` : '';
      return `
        <button class="m6-list-item${sel}" data-id="${f.id}">
          <div class="m6-list-h">
            <span class="badge badge-mute">${esc(String(f.forma || '').split(/[,;/]/)[0].trim())}</span>
            <span class="tiny mono muted">${esc(f.concentracion)}</span>
          </div>
          <div class="m6-list-name">${esc(f.medicamento)}</div>
          ${prog}
        </button>`;
    }).join('');

    listEl.querySelectorAll('.m6-list-item').forEach(el => {
      el.addEventListener('click', () => selectFarmaco(el.dataset.id));
    });
  }

  // === Tarjeta de dosis pediátrica de referencia ============================
  function renderDosisReferencia(f) {
    const dosisDB = window.DB_DOSIS_PED;
    if (!dosisDB) return '';
    const d = dosisDB.sku_to_dosis?.[f.id];
    if (!d) return '';
    return `
      <div class="m4-dosis-ref">
        <div class="m4-dosis-h">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11H5a2 2 0 0 0-2 2v7h6V13zM15 11h4a2 2 0 0 1 2 2v7h-6V13zM9 11V6a3 3 0 0 1 6 0v5"/></svg>
          <strong>Dosis pediátrica de referencia</strong>
          <span class="badge badge-mute tiny mono">${esc(d.fuente || '—')}</span>
        </div>
        <div class="m4-dosis-grid">
          <div class="m4-dosis-cell">
            <span class="m4-dosis-l">Dosis (mg/kg/día)</span>
            <span class="m4-dosis-v">${esc(d.dosis_mg_kg_dia)}</span>
          </div>
          <div class="m4-dosis-cell">
            <span class="m4-dosis-l">Frecuencia</span>
            <span class="m4-dosis-v">${esc(d.frecuencia)}</span>
          </div>
          ${d.dosis_max_dia_mg ? `
            <div class="m4-dosis-cell">
              <span class="m4-dosis-l">Dosis máx/día</span>
              <span class="m4-dosis-v">${esc(String(d.dosis_max_dia_mg))} ${typeof d.dosis_max_dia_mg === 'number' ? 'mg' : ''}</span>
            </div>
          ` : ''}
          <div class="m4-dosis-cell">
            <span class="m4-dosis-l">Vía</span>
            <span class="m4-dosis-v">${esc(d.via)}</span>
          </div>
        </div>
        ${d.indicaciones_comunes ? `
          <div class="m4-dosis-ind">
            <span class="m4-dosis-l">Indicaciones comunes:</span>
            <span>${esc(d.indicaciones_comunes)}</span>
          </div>
        ` : ''}
        ${d.nota ? `
          <div class="m4-dosis-nota">
            <strong>📋 Nota:</strong> ${esc(d.nota)}
          </div>
        ` : ''}
        <div class="m4-dosis-warn tiny">
          ⚠ Dosis de referencia. <strong>Verificar siempre</strong> contra protocolo institucional, ajustar por función renal/hepática y considerar interacciones.
        </div>
      </div>
    `;
  }

  // === Calculadora de dosis ==================================================
  function renderCalculator(f) {
    const conc = parseConcentration(f.concentracion, f.forma);
    const parseable = conc && conc.kind !== 'unparseable';
    const isLiquid = conc && (conc.kind === 'liquid' || conc.kind === 'liquid_simple');

    return `
      <div class="m4-calc">
        <div class="m4-calc-h">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 10h8M8 14h5M8 18h5"/></svg>
          <strong>Calculadora de dosis</strong>
          ${parseable
            ? `<span class="badge badge-clinic mono">${esc(conc.display)}</span>`
            : `<span class="badge badge-ochre" title="Concentración no parseable">${esc(f.concentracion)}</span>`}
        </div>
        <div class="m4-calc-grid">
          <label class="field">
            <span class="field-label">Tipo de paciente</span>
            <select class="field-select" id="calc-tipo">
              <option value="adulto">Adulto</option>
              <option value="pediatrico" selected>Pediátrico (mg/kg)</option>
              <option value="gestante">Gestante</option>
            </select>
          </label>
          <label class="field" id="calc-peso-w">
            <span class="field-label">Peso del paciente (kg)</span>
            <input type="number" inputmode="decimal" class="field-input" id="calc-peso" min="0" step="0.1" placeholder="ej. 15" />
          </label>
          <label class="field">
            <span class="field-label" id="calc-dosis-l">Dosis (mg/kg/dosis)</span>
            <input type="number" inputmode="decimal" class="field-input" id="calc-dosis" min="0" step="0.1" placeholder="ej. 10" />
            <span class="tiny muted" id="calc-dosis-hint">Lee del texto: típicamente 5-15 mg/kg</span>
          </label>
          <label class="field">
            <span class="field-label">Frecuencia (veces/día)</span>
            <input type="number" inputmode="numeric" class="field-input" id="calc-freq" min="1" max="12" step="1" value="3" />
          </label>
          <label class="field">
            <span class="field-label">Duración (días)</span>
            <input type="number" inputmode="numeric" class="field-input" id="calc-dias" min="1" step="1" value="7" />
          </label>
        </div>
        <div class="m4-calc-result" id="calc-result">
          <div class="m4-calc-placeholder muted">Ingresa peso y dosis para calcular</div>
        </div>
        ${f.alimentos ? `<div class="m4-calc-alimentos"><strong>⚠ Alimentos:</strong> ${esc(f.alimentos)}</div>` : ''}
      </div>
    `;
  }

  function bindCalculator(f) {
    const conc = parseConcentration(f.concentracion, f.forma);
    const dosisRef = window.DB_DOSIS_PED?.sku_to_dosis?.[f.id];
    const tipo = document.getElementById('calc-tipo');
    const peso = document.getElementById('calc-peso');
    const dosis = document.getElementById('calc-dosis');
    const dosisL = document.getElementById('calc-dosis-l');
    const dosisHint = document.getElementById('calc-dosis-hint');
    const pesoWrap = document.getElementById('calc-peso-w');
    const freq = document.getElementById('calc-freq');
    const dias = document.getElementById('calc-dias');
    const out = document.getElementById('calc-result');

    // Pre-cargar dosis de referencia si existe (extraer el primer número del rango)
    if (dosisRef && dosis && !dosis.value) {
      const m = String(dosisRef.dosis_mg_kg_dia).match(/(\d+(?:\.\d+)?)/);
      if (m) {
        // Si la dosis es total/día, dividirla por las dosis/día estándar
        // (la calculadora pide dosis POR TOMA, no día)
        const dosisDia = parseFloat(m[1]);
        // Estimar frecuencia desde el texto
        const freqMatch = String(dosisRef.frecuencia).match(/(\d+)h/);
        let dosisToma = dosisDia;
        if (freqMatch) {
          const horas = parseInt(freqMatch[1]);
          const tomasDia = 24 / horas;
          dosisToma = dosisDia / tomasDia;
          freq.value = String(tomasDia);
        }
        dosis.value = dosisToma.toFixed(1);
      }
    }

    function updateLabels() {
      const t = tipo.value;
      if (t === 'pediatrico') {
        dosisL.textContent = 'Dosis (mg/kg/dosis)';
        dosisHint.textContent = 'Lee del texto: típicamente 5-15 mg/kg por dosis';
        pesoWrap.style.display = '';
      } else if (t === 'adulto') {
        dosisL.textContent = 'Dosis por toma (mg)';
        dosisHint.textContent = 'Dosis fija por toma según prescripción';
        pesoWrap.style.display = 'none';
      } else {
        dosisL.textContent = 'Dosis por toma (mg)';
        dosisHint.textContent = 'Verificar categoría FDA en RAM/Interacciones';
        pesoWrap.style.display = 'none';
      }
      recalc();
    }

    function recalc() {
      const t = tipo.value;
      const p = parseFloat(peso.value) || 0;
      const d = parseFloat(dosis.value) || 0;
      const fq = parseInt(freq.value) || 0;
      const dd = parseInt(dias.value) || 0;
      if (!d || !fq) {
        out.innerHTML = `<div class="m4-calc-placeholder muted">Ingresa al menos dosis y frecuencia</div>`;
        return;
      }
      let mgPorToma;
      if (t === 'pediatrico') {
        if (!p) {
          out.innerHTML = `<div class="m4-calc-placeholder muted">Ingresa peso del paciente</div>`;
          return;
        }
        mgPorToma = d * p;
      } else {
        mgPorToma = d;
      }
      const mgDia = mgPorToma * fq;
      const mgTotal = mgDia * dd;

      // Convertir mg → ml o unidades según concentración
      let volPorToma = null;
      let unidadLabel = '';
      if (conc?.kind === 'liquid' && conc.mg_per_ml) {
        volPorToma = mgPorToma / conc.mg_per_ml;
        unidadLabel = 'ml';
      } else if (conc?.kind === 'liquid_simple' && conc.mg_per_unit) {
        volPorToma = mgPorToma / conc.mg_per_unit;
        unidadLabel = 'ml';
      } else if (conc?.kind === 'solid' && conc.mg_per_unit) {
        volPorToma = mgPorToma / conc.mg_per_unit;
        unidadLabel = conc.unidad_label || 'comprimido';
      }

      const gestanteAlert = (t === 'gestante') ?
        `<div class="m4-calc-alert">⚠ Embarazo: verificar categoría FDA y manual de obstetricia antes de prescribir.</div>` : '';

      const pedAlert = (t === 'pediatrico' && p > 0 && d > 0 && d * p > 1000) ?
        `<div class="m4-calc-alert">⚠ Dosis por toma > 1 g — verificar máximo pediátrico.</div>` : '';

      out.innerHTML = `
        ${gestanteAlert}${pedAlert}
        <div class="m4-calc-row">
          <span class="m4-calc-lbl">Dosis por toma</span>
          <span class="m4-calc-val">${fmt(mgPorToma)} mg
            ${volPorToma !== null ? `<small class="muted">≈ ${fmt(volPorToma, 2)} ${unidadLabel}</small>` : ''}
          </span>
        </div>
        <div class="m4-calc-row">
          <span class="m4-calc-lbl">Dosis diaria total</span>
          <span class="m4-calc-val">${fmt(mgDia)} mg${p > 0 && t === 'pediatrico' ? ` <small class="muted">(${fmt(mgDia/p, 1)} mg/kg/día)</small>` : ''}</span>
        </div>
        <div class="m4-calc-row">
          <span class="m4-calc-lbl">Total para ${dd} día${dd === 1 ? '' : 's'}</span>
          <span class="m4-calc-val">${fmt(mgTotal)} mg${volPorToma !== null ? ` <small class="muted">≈ ${fmt(volPorToma * fq * dd, 2)} ${unidadLabel}</small>` : ''}</span>
        </div>
      `;
    }

    function fmt(n, dec = 1) {
      if (!isFinite(n)) return '—';
      if (n >= 100) return Math.round(n).toLocaleString('es-BO');
      return n.toFixed(dec);
    }

    [tipo, peso, dosis, freq, dias].forEach(el => {
      el?.addEventListener('input', recalc);
      el?.addEventListener('change', recalc);
    });
    tipo?.addEventListener('change', updateLabels);
    updateLabels();
  }

  // === Renderizado del detalle ==============================================
  function renderDetail() {
    const detail = document.getElementById('m4-detail');
    if (!detail) return;

    if (!state.selected) {
      detail.innerHTML = `
        <div class="m6-detail-empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M10.5 21 6.5 17l4-4M13.5 3 17.5 7l-4 4M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z" stroke-linecap="round"/></svg>
          <div class="empty-state-title">Selecciona un fármaco</div>
          <p class="muted small">${state.db.vademecum.length} medicamentos del LINAME</p>
        </div>`;
      return;
    }

    const f = state.db.vademecum.find(x => x.id === state.selected);
    if (!f) return;

    const section = (title, content) => {
      if (!content) return '';
      return `
        <details class="acc" open>
          <summary>
            <span>${esc(title)}</span>
            <svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          </summary>
          <div class="acc-body">${content}</div>
        </details>`;
    };

    detail.innerHTML = `
      <div class="m6-detail-h">
        <button class="m6-back btn btn-ghost" id="m4-back">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
          <span>Volver</span>
        </button>
        <div class="m6-detail-title">
          <h1>${esc(f.medicamento)}</h1>
          <div class="row gap-2 mt-4" style="flex-wrap:wrap;">
            ${formaChips(f.forma)}
            <span class="badge badge-cie mono">${esc(f.concentracion)}</span>
            ${f.programa ? `<span class="badge badge-ochre">${esc(f.programa)}</span>` : ''}
          </div>
        </div>
      </div>

      ${renderDosisReferencia(f)}

      ${renderCalculator(f)}

      ${section('Mecanismo de acción y farmacocinética', paragraphs(f.mecanismo_fc))}
      ${section('Reacciones adversas (RAM)', paragraphs(f.ram))}
      ${section('Interacciones medicamentosas', paragraphs(f.interacciones))}
      ${section('Interacciones alimentarias', paragraphs(f.alimentos))}
      ${section('Patologías donde es de elección', renderPatologiasEleccion(f.patologias_eleccion))}

      <div class="m6-detail-foot tiny muted mt-6">
        <p>ID: <span class="mono">${f.id}</span> · Fuente: T_LINAME.xlsx (Bolivia)</p>
        ${window.Auth?.isAdmin() ? `
          <div class="row gap-2 mt-2" style="flex-wrap:wrap;">
            <button class="btn btn-primary" id="m4-edit" style="font-size:0.85rem;padding:6px 12px;">✏️ Editar este fármaco</button>
            <button class="btn btn-ghost" id="m4-delete" style="font-size:0.85rem;color:var(--rose);border-color:var(--rose);">
              🗑️ Eliminar
            </button>
          </div>
        ` : ''}
      </div>
    `;

    document.getElementById('m4-back')?.addEventListener('click', () => {
      document.querySelector('.m6-layout')?.classList.remove('is-detail-active');
    });

    document.getElementById('m4-edit')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="vademecum"]');
        if (panel) promptEditFarmaco(f, panel);
      });
    });

    document.getElementById('m4-delete')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="vademecum"]');
        if (panel) deleteFarmaco(f.id, panel);
      });
    });

    bindCalculator(f);
    bindPatologiaLinks();
  }

  // Forma farmacéutica como lista de chips (separa por , / ; o "y")
  function formaChips(forma) {
    if (!forma) return '';
    const partes = String(forma)
      .split(/[,;/]|\s+y\s+/i)
      .map(s => s.trim())
      .filter(Boolean);
    if (partes.length <= 1) {
      return `<span class="badge badge-clinic">${esc(forma)}</span>`;
    }
    return partes.map(p => `<span class="badge badge-clinic">${esc(p)}</span>`).join(' ');
  }

  // Renderiza el texto de patologías de elección detectando nombres de
  // patologías que existan en DB_PATOLOGIAS y convirtiéndolos en enlaces.
  function renderPatologiasEleccion(text) {
    if (!text) return '';
    const db = window.DB_PATOLOGIAS;
    // Si la BD de patologías no está cargada, mostrar texto plano con aviso
    if (!db || !db.patologias) {
      return `<div class="m4-pat-text">${esc(text)}</div>
        <p class="tiny muted mt-2">💡 Entra al módulo Clínica para que los nombres de patologías se vuelvan enlaces.</p>`;
    }

    // Construir índice de nombres de patologías (nombre + nombres_alt), ordenado
    // por longitud descendente para emparejar los más específicos primero.
    const indice = [];
    db.patologias.forEach(p => {
      const nombres = [p.nombre, ...(Array.isArray(p.nombres_alt) ? p.nombres_alt : [])];
      nombres.forEach(n => {
        if (n && n.length >= 5) indice.push({ nombre: n, id: p.id });
      });
    });
    indice.sort((a, b) => b.nombre.length - a.nombre.length);

    // Escapar el texto y luego inyectar enlaces sobre coincidencias
    let html = esc(text);
    const usados = new Set();
    for (const { nombre, id } of indice) {
      if (usados.has(id)) continue;
      // Buscar el nombre como palabra completa (case-insensitive, escapado)
      const escNombre = esc(nombre).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp('\\b(' + escNombre + ')\\b', 'i');
      if (re.test(html) && !html.includes('data-pat-id')) {
        // Solo enlazar la primera aparición de cada patología
        html = html.replace(re, `<a class="m4-pat-link" data-pat-id="${id}">$1</a>`);
        usados.add(id);
      } else if (re.test(html)) {
        // Verificar que no esté dentro de un enlace ya creado
        html = html.replace(re, (m) => {
          // heurística simple: si ya hay muchos enlaces, parar
          return usados.size < 8 ? `<a class="m4-pat-link" data-pat-id="${id}">${m}</a>` : m;
        });
        usados.add(id);
      }
    }
    return `<div class="m4-pat-text">${html}</div>`;
  }

  function bindPatologiaLinks() {
    document.querySelectorAll('.m4-pat-link[data-pat-id]').forEach(a => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        const id = a.dataset.patId;
        window.App?.activateTab('clinica');
        setTimeout(() => {
          document.dispatchEvent(new CustomEvent('rb:focus-patologia', { detail: { id, kind: 'patologia' } }));
        }, 250);
      });
    });
  }

  function selectFarmaco(id) {
    state.selected = id;
    renderList();
    renderDetail();
    document.querySelector('.m6-layout')?.classList.add('is-detail-active');
    document.getElementById('m4-detail')?.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // === Filtros ===============================================================
  function buildFilters() {
    const programas = [...new Set(
      state.db.vademecum.map(f => f.programa).filter(Boolean)
    )].sort();
    const formas = [...new Set(
      state.db.vademecum.map(f => f.forma).filter(Boolean)
    )].sort();

    return `
      <div class="m6-filters">
        <div class="m6-filter-search">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input type="search" id="m4-q" placeholder="Filtrar por fármaco, indicación..." class="field-input" />
        </div>
        <select class="field-select" id="m4-prog">
          <option value="">Todos los programas</option>
          ${programas.map(p => `<option value="${esc(p)}">${esc(p)}</option>`).join('')}
        </select>
        <select class="field-select" id="m4-forma">
          <option value="">Todas las formas</option>
          ${formas.map(f => `<option value="${esc(f)}">${esc(f)}</option>`).join('')}
        </select>
      </div>`;
  }

  function bindFilters() {
    const q = document.getElementById('m4-q');
    const p = document.getElementById('m4-prog');
    const f = document.getElementById('m4-forma');
    let timer;
    q?.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => { state.filter.query = q.value; renderList(); }, 200);
    });
    p?.addEventListener('change', () => { state.filter.programa = p.value; renderList(); });
    f?.addEventListener('change', () => { state.filter.forma = f.value; renderList(); });
  }

  // === Entry point ==========================================================
  window.render_vademecum = function (panel) {
    state.db = window.DB_VADEMECUM;
    if (!state.db) {
      panel.innerHTML = '<div class="empty-state">Cargando vademécum...</div>';
      return;
    }
    // Aplicar override admin si existe
    if (window.State?.applyAdminOverride('DB_VADEMECUM', 'vademecum')) {
      state.db = window.DB_VADEMECUM;
    }
    const adminTools = window.State?.renderAdminToolbar('DB_VADEMECUM', { ns: 'vademecum', withExcel: true }) || '';

    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Vademécum</h1>
          <p class="muted small">${state.db.vademecum.length} fármacos del LINAME — Bolivia</p>
        </div>
        <div class="row gap-2" style="flex-wrap:wrap;">
          ${adminTools}
          <div id="m4-count" class="badge badge-mute mono"></div>
        </div>
      </div>
      ${buildFilters()}
      <div class="m6-layout">
        <aside class="m6-master">
          <div class="m6-list" id="m4-list"></div>
        </aside>
        <section class="m6-detail" id="m4-detail" tabindex="0"></section>
      </div>
    `;

    // Bindear toolbar admin
    const toolbar = panel.querySelector('.rb-admin-tools');
    if (toolbar) {
      window.State.bindAdminToolbar(toolbar, {
        filename: 'db_vademecum.js',
        onChange: () => {
          state.db = window.DB_VADEMECUM;
          window.render_vademecum(panel);
        },
        onAdd: () => promptNewFarmaco(panel),
        excelOpts: {
          itemsKey: 'vademecum',
          sheetName: 'Vademecum',
          filenameXlsx: 'vademecum.xlsx',
          columns: [
            { key: 'id',                  header: 'ID',                        width: 12 },
            { key: 'medicamento',         header: 'Medicamento',               width: 38 },
            { key: 'forma',               header: 'Forma',                     width: 18 },
            { key: 'concentracion',       header: 'Concentracion',             width: 18 },
            { key: 'programa',            header: 'Programa',                  width: 22 },
            { key: 'mecanismo_fc',        header: 'Mecanismo_FC',              width: 50 },
            { key: 'ram',                 header: 'RAM',                       width: 40 },
            { key: 'interacciones',       header: 'Interacciones',             width: 40 },
            { key: 'alimentos',           header: 'Alimentos',                 width: 25 },
            { key: 'patologias_eleccion', header: 'Patologias_eleccion',       width: 40 },
          ],
          examples: [{
            id: '',
            medicamento: 'Ejemplo: Amoxicilina',
            forma: 'Suspension',
            concentracion: '250 mg/5 ml',
            programa: 'Primer Nivel',
            mecanismo_fc: 'Antibiótico β-lactámico aminopenicilínico de espectro extendido...',
            ram: 'Diarrea, rash cutáneo, candidiasis.',
            interacciones: 'Probenecid aumenta niveles. Alopurinol incrementa riesgo de rash.',
            alimentos: 'Puede tomarse con o sin alimentos.',
            patologias_eleccion: 'Otitis media, neumonía, faringoamigdalitis estreptocócica.',
          }],
        },
      });
    }

    bindFilters();
    renderList();
    renderDetail();
  };

  // === Schema para el editor modal =========================================
  const FARMACO_SCHEMA = [
    { key: 'medicamento',         label: 'Nombre genérico',                  type: 'text', required: true },
    { key: 'forma',               label: 'Forma farmacéutica',               type: 'text', required: true, help: 'Separa varias formas con coma y se mostrarán como lista. Ej: Comprimido, Suspensión, Inyectable' },
    { key: 'concentracion',       label: 'Concentración',                    type: 'text', required: true, help: 'Ej: "500 mg" o "100 mg/5 ml" o "600.000 UI"' },
    { key: 'programa',            label: 'Programa',                         type: 'text', help: 'Ej: Primer Nivel, Programa Nacional ITS/VIH' },
    { key: 'mecanismo_fc',        label: 'Mecanismo de acción y farmacocinética', type: 'textarea', rows: 4 },
    { key: 'ram',                 label: 'Reacciones adversas (RAM)',        type: 'textarea', rows: 4 },
    { key: 'interacciones',       label: 'Interacciones medicamentosas',     type: 'textarea', rows: 3 },
    { key: 'alimentos',           label: 'Interacciones alimentarias',       type: 'textarea', rows: 2 },
    { key: 'patologias_eleccion', label: 'Patologías donde es de elección',  type: 'textarea', rows: 3 },
  ];

  // === Admin: crear/editar/eliminar fármacos ===============================
  function promptNewFarmaco(panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: 'Nuevo fármaco',
      schema: FARMACO_SCHEMA,
      data: {},
      onSave: (data) => {
        const id = 'F' + Date.now().toString(36).toUpperCase();
        state.db.vademecum.push({ id, ...data });
        window.State.persistAdminDB('DB_VADEMECUM', 'vademecum');
        window.Auth?.audit('add_farmaco', `${id}: ${data.medicamento}`);
        state.selected = id;
        window.render_vademecum(panel);
        window.State?.toast(`✓ Fármaco "${data.medicamento}" creado`, 'ok');
      },
    });
  }

  function promptEditFarmaco(farmaco, panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: `Editar — ${farmaco.medicamento}`,
      schema: FARMACO_SCHEMA,
      data: farmaco,
      onSave: (data) => {
        Object.assign(farmaco, data);
        window.State.persistAdminDB('DB_VADEMECUM', 'vademecum');
        window.Auth?.audit('edit_farmaco', `${farmaco.id}: ${data.medicamento}`);
        window.render_vademecum(panel);
        window.State?.toast(`✓ Fármaco actualizado`, 'ok');
      },
    });
  }

  function deleteFarmaco(id, panel) {
    const f = state.db.vademecum.find(x => x.id === id);
    if (!f) return;
    if (!window.confirm(`¿Eliminar "${f.medicamento}" del vademécum?\n\nEsta acción modificará la BD local. Puedes restaurar importando el archivo original.`)) return;
    state.db.vademecum = state.db.vademecum.filter(x => x.id !== id);
    if (state.selected === id) state.selected = null;
    window.State.persistAdminDB('DB_VADEMECUM', 'vademecum');
    window.Auth?.audit('delete_farmaco', `${id}: ${f.medicamento}`);
    window.render_vademecum(panel);
  }

  // === Listener desde el buscador omnipotente ==============================
  document.addEventListener('rb:focus-farmaco', (e) => {
    const id = e.detail.id;
    const panel = document.querySelector('.tab-panel[data-panel="vademecum"]');
    if (panel && !panel.dataset.loaded) {
      window.render_vademecum(panel);
      panel.dataset.loaded = '1';
    }
    selectFarmaco(id);
  });
})();
