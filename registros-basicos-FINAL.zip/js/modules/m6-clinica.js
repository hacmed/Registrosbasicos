/* ============================================================================
   m6-clinica.js — Módulo 6: Navegador de patologías
   Maestro-detalle: lista filtrable + vista detallada con acordeones.
   Cruza patología ↔ vademécum (fármacos mencionados en prestaciones).
   ============================================================================ */
(function () {
  'use strict';

  // === Estado del módulo ====================================================
  const state = {
    db: null,
    selected: null,         // id de patología activa
    filter: {
      query: '',
      especialidad: '',
      nivel: '',
    },
  };

  // === Utilidades ===========================================================
  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }
  function normalize(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  // Convierte texto plano con saltos de línea en HTML preservando párrafos
  function paragraphs(text) {
    if (!text) return '';
    return text
      .split(/\n+/)
      .map(line => line.trim())
      .filter(Boolean)
      .map(line => `<p>${esc(line)}</p>`)
      .join('');
  }

  // Detecta nombres de fármacos en un texto y los cruza con el vademécum
  function findFarmacosInText(text, vademecum) {
    if (!text || !vademecum) return [];
    const nt = normalize(text);
    const found = new Map();
    for (const f of vademecum) {
      const nf = normalize(f.medicamento);
      if (nf.length < 5) continue;  // evita falsos positivos cortos
      if (nt.includes(nf)) {
        // De-duplicar por nombre genérico (un fármaco aparece N veces por SKU)
        if (!found.has(nf)) found.set(nf, f);
      }
    }
    return Array.from(found.values());
  }

  // === Filtrado de la lista =================================================
  function getFilteredPatologias() {
    if (!state.db) return [];
    const { query, especialidad, nivel } = state.filter;
    const nq = normalize(query);
    return state.db.patologias.filter(p => {
      if (especialidad && p.especialidad !== especialidad) return false;
      if (nivel && !p.niveles_atencion.includes(nivel)) return false;
      if (nq) {
        const hay = normalize(
          p.nombre + ' ' + (p.nombres_alt || []).join(' ') + ' ' +
          (p.cie10 || []).join(' ') + ' ' + (p.especialidad || '')
        );
        if (!hay.includes(nq)) return false;
      }
      return true;
    });
  }

  // === Renderizado de la lista (maestro) ====================================
  function renderList() {
    const listEl = document.getElementById('m6-list');
    const countEl = document.getElementById('m6-count');
    if (!listEl) return;

    const items = getFilteredPatologias();
    countEl.textContent = `${items.length} patología${items.length === 1 ? '' : 's'}`;

    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-title">Sin resultados</div>
          <p class="tiny">Ajusta los filtros o limpia la búsqueda.</p>
        </div>`;
      return;
    }

    // Ordenar por nombre
    items.sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));

    const html = items.map(p => {
      const cie = p.cie10[0] ? `<span class="badge badge-cie">${esc(p.cie10[0])}</span>` : '';
      const nivBadges = p.niveles_atencion
        .map(n => `<span class="badge badge-mute" title="Nivel ${n}">${n}</span>`).join('');
      const espe = p.especialidad ? `<span class="m6-list-espe">${esc(p.especialidad)}</span>` : '';
      const sel = state.selected === p.id ? ' is-selected' : '';
      return `
        <button class="m6-list-item${sel}" data-id="${p.id}">
          <div class="m6-list-h">
            ${cie}${nivBadges}
          </div>
          <div class="m6-list-name">${esc(p.nombre)}</div>
          ${espe}
        </button>`;
    }).join('');

    listEl.innerHTML = html;
    listEl.querySelectorAll('.m6-list-item').forEach(el => {
      el.addEventListener('click', () => {
        selectPatologia(el.dataset.id);
      });
    });
  }

  // === Renderizado del detalle ==============================================
  function renderDetail() {
    const detail = document.getElementById('m6-detail');
    if (!detail) return;

    if (!state.selected) {
      detail.innerHTML = `
        <div class="m6-detail-empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color:var(--ink-mute);margin-bottom:12px;">
            <rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>
          </svg>
          <div class="empty-state-title">Selecciona una patología</div>
          <p class="muted small">${state.db.patologias.length} patologías disponibles · ${state.db.patologias.filter(p => p.prestaciones.length).length} con prestaciones Ley 475</p>
        </div>`;
      return;
    }

    const p = state.db.patologias.find(x => x.id === state.selected);
    if (!p) return;

    // Cruce con vademécum
    const vademecumDB = window.DB_VADEMECUM?.vademecum || [];
    const textoTotal = [p.tratamiento_niveles, p.tratamiento_1_general,
      ...p.prestaciones.map(pr => pr.tratamiento_prestacion)].join(' ');
    const farmacosRelacionados = findFarmacosInText(textoTotal, vademecumDB);

    // Sección helper
    const section = (title, content, defaultOpen = false) => {
      if (!content) return '';
      return `
        <details class="acc" ${defaultOpen ? 'open' : ''}>
          <summary>
            <span>${esc(title)}</span>
            <svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          </summary>
          <div class="acc-body">${content}</div>
        </details>`;
    };

    // CIE-10 badges
    const cieList = p.cie10.length
      ? p.cie10.map(c => `<span class="badge badge-cie mono">${esc(c)}</span>`).join(' ')
      : '<span class="muted small">Sin CIE-10 registrado</span>';

    // Niveles
    const niveles = p.niveles_atencion.length
      ? p.niveles_atencion.map(n => `<span class="badge badge-clinic">Nivel ${n}</span>`).join(' ')
      : '';

    // Nombres alternativos
    const altsHtml = p.nombres_alt && p.nombres_alt.length
      ? `<p class="small muted mt-2"><em>También: ${esc(p.nombres_alt.join(', '))}</em></p>`
      : '';

    // Sección de prestaciones Ley 475 (lista numerada)
    const prestacionesHtml = p.prestaciones && p.prestaciones.length
      ? `
        <ol class="m6-prest">
          ${p.prestaciones.map((pr, i) => `
            <li>
              <div class="m6-prest-num">${i + 1}</div>
              <div class="m6-prest-body">
                <p>${esc(pr.tratamiento_prestacion)}</p>
                ${pr.observaciones ? `<p class="tiny muted mt-2"><strong>Observación:</strong> ${esc(pr.observaciones)}</p>` : ''}
              </div>
            </li>
          `).join('')}
        </ol>`
      : '';

    // Sección de fármacos cruzados
    const farmacosHtml = farmacosRelacionados.length
      ? `
        <div class="m6-farmacos">
          <div class="m6-farmacos-h">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M10.5 21 6.5 17l4-4M13.5 3 17.5 7l-4 4M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z"/>
            </svg>
            <strong>Fármacos mencionados (${farmacosRelacionados.length})</strong>
            <span class="tiny muted">— click para ver en vademécum</span>
          </div>
          <div class="m6-farmacos-list">
            ${farmacosRelacionados.map(f =>
              `<button class="m6-farmaco-chip" data-farmaco="${esc(f.id)}">${esc(f.medicamento)}</button>`
            ).join('')}
          </div>
        </div>`
      : '';

    detail.innerHTML = `
      <div class="m6-detail-h">
        <button class="m6-back btn btn-ghost" id="m6-back">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
          <span>Volver</span>
        </button>
        <div class="m6-detail-title">
          <h1>${esc(p.nombre)}</h1>
          ${altsHtml}
          <div class="row gap-2 mt-4" style="flex-wrap:wrap;">
            ${cieList} ${niveles}
            ${p.especialidad ? `<span class="badge badge-ochre">${esc(p.especialidad)}</span>` : ''}
          </div>
        </div>
      </div>

      ${farmacosHtml}

      ${section('Resumen', paragraphs(p.resumen), true)}
      ${section('Etiopatogenia / Fisiopatología', paragraphs(p.etiopatogenia_fisiopatologia || p.fisiopatologia))}
      ${section('Signos', paragraphs(p.signos))}
      ${section('Síntomas', paragraphs(p.sintomas))}
      ${section('Signos y síntomas', paragraphs(p.signos_sintomas), !!p.signos_sintomas && !p.signos)}
      ${section('Diagnóstico', paragraphs(p.diagnostico))}
      ${section('Exámenes complementarios', paragraphs(p.examenes))}
      ${section('Laboratorio', paragraphs(p.laboratorio))}
      ${section('Gabinete', paragraphs(p.gabinete))}
      ${section('Tratamiento por niveles', paragraphs(p.tratamiento_niveles))}
      ${section('Tratamiento general', paragraphs(p.tratamiento_1_general))}
      ${prestacionesHtml ? section(`Prestaciones Ley 475 (${p.prestaciones.length})`, prestacionesHtml, true) : ''}
      ${section('Complicaciones', paragraphs(p.complicaciones))}

      <div class="m6-detail-foot tiny muted mt-6">
        <p>ID: <span class="mono">${p.id}</span> · Fuentes: ${p.fuentes.join(', ')}</p>
        ${window.Auth?.isAdmin() ? `
          <div class="row gap-2 mt-2" style="flex-wrap:wrap;">
            <button class="btn btn-primary" id="m6-edit" style="font-size:0.85rem;padding:6px 12px;">✏️ Editar esta patología</button>
            <button class="btn btn-ghost" id="m6-delete" style="font-size:0.85rem;color:var(--rose);border-color:var(--rose);">
              🗑️ Eliminar
            </button>
          </div>
        ` : ''}
      </div>
    `;

    // Bind del botón Volver (solo visible en mobile)
    document.getElementById('m6-back')?.addEventListener('click', () => {
      detail.classList.remove('is-mobile-active');
      document.querySelector('.m6-layout')?.classList.remove('is-detail-active');
    });

    document.getElementById('m6-edit')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="clinica"]');
        if (panel) promptEditPatologia(p, panel);
      });
    });

    document.getElementById('m6-delete')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="clinica"]');
        if (panel) deletePatologia(p.id, panel);
      });
    });

    // Bind de chips de fármacos: navegar al Módulo 4
    detail.querySelectorAll('.m6-farmaco-chip').forEach(el => {
      el.addEventListener('click', () => {
        const id = el.dataset.farmaco;
        window.App.activateTab('vademecum');
        setTimeout(() => {
          document.dispatchEvent(new CustomEvent('rb:focus-farmaco', {
            detail: { id, kind: 'farmaco' }
          }));
        }, 50);
      });
    });
  }

  function selectPatologia(id) {
    state.selected = id;
    renderList();  // re-render para mostrar selección
    renderDetail();
    // En mobile, mostrar detalle ocultando lista
    document.querySelector('.m6-layout')?.classList.add('is-detail-active');
    // Scroll del detalle al inicio
    document.getElementById('m6-detail')?.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // === Construcción del filtro ===============================================
  function buildFilters() {
    const especialidades = [...new Set(
      state.db.patologias.map(p => p.especialidad).filter(Boolean)
    )].sort();

    return `
      <div class="m6-filters">
        <div class="m6-filter-search">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input type="search" id="m6-q" placeholder="Filtrar por nombre, CIE-10, especialidad..." class="field-input" />
        </div>
        <select class="field-select" id="m6-espe">
          <option value="">Todas las especialidades</option>
          ${especialidades.map(e => `<option value="${esc(e)}">${esc(e)}</option>`).join('')}
        </select>
        <div class="m6-niveles">
          <button class="m6-niv-btn" data-niv="">Todos</button>
          <button class="m6-niv-btn" data-niv="I">Nivel I</button>
          <button class="m6-niv-btn" data-niv="II">Nivel II</button>
          <button class="m6-niv-btn" data-niv="III">Nivel III</button>
        </div>
      </div>
    `;
  }

  function bindFilters() {
    const q = document.getElementById('m6-q');
    const e = document.getElementById('m6-espe');
    let timer;
    q?.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        state.filter.query = q.value;
        renderList();
      }, 200);
    });
    e?.addEventListener('change', () => {
      state.filter.especialidad = e.value;
      renderList();
    });
    document.querySelectorAll('.m6-niv-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.m6-niv-btn').forEach(b => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        state.filter.nivel = btn.dataset.niv;
        renderList();
      });
    });
    // Default: "Todos" activo
    document.querySelector('.m6-niv-btn[data-niv=""]')?.classList.add('is-active');
  }

  // === Entry point ==========================================================
  window.render_clinica = function (panel) {
    state.db = window.DB_PATOLOGIAS;
    if (!state.db) {
      panel.innerHTML = '<div class="empty-state">Cargando base clínica...</div>';
      return;
    }
    if (window.State?.applyAdminOverride('DB_PATOLOGIAS', 'patologias')) {
      state.db = window.DB_PATOLOGIAS;
    }
    const adminTools = window.State?.renderAdminToolbar('DB_PATOLOGIAS', { ns: 'patologias', withExcel: true }) || '';

    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Clínica</h1>
          <p class="muted small">${state.db.patologias.length} patologías indexadas</p>
        </div>
        <div class="row gap-2" style="flex-wrap:wrap;">
          ${adminTools}
          <div id="m6-count" class="badge badge-mute mono"></div>
        </div>
      </div>
      ${buildFilters()}
      <div class="m6-layout">
        <aside class="m6-master">
          <div class="m6-list" id="m6-list"></div>
        </aside>
        <section class="m6-detail" id="m6-detail" tabindex="0"></section>
      </div>
    `;

    const toolbar = panel.querySelector('.rb-admin-tools');
    if (toolbar) {
      window.State.bindAdminToolbar(toolbar, {
        filename: 'db_patologias.js',
        onChange: () => {
          state.db = window.DB_PATOLOGIAS;
          window.render_clinica(panel);
        },
        onAdd: () => promptNewPatologia(panel),
        excelOpts: {
          itemsKey: 'patologias',
          sheetName: 'Patologias',
          filenameXlsx: 'patologias.xlsx',
          // Las prestaciones se serializan como texto multilinea en una columna,
          // separadas por "##" entre prestación y observación, y "||" entre líneas.
          // El import las parsea de vuelta.
          columns: [
            { key: 'id',                            header: 'ID',                       width: 12 },
            { key: 'nombre',                        header: 'Nombre',                   width: 34, type: 'text' },
            { key: 'nombres_alt',                   header: 'Nombres_alt',              width: 26, type: 'array' },
            { key: 'cie10',                         header: 'CIE10',                    width: 16, type: 'array' },
            { key: 'especialidad',                  header: 'Especialidad',             width: 22 },
            { key: 'niveles_atencion',              header: 'Niveles_atencion',         width: 14, type: 'array' },
            { key: 'resumen',                       header: 'Resumen',                  width: 40 },
            { key: 'etiopatogenia_fisiopatologia',  header: 'Etiopatogenia',            width: 50 },
            { key: 'signos_sintomas',               header: 'Signos_sintomas',          width: 40 },
            { key: 'signos',                        header: 'Signos',                   width: 30 },
            { key: 'sintomas',                      header: 'Sintomas',                 width: 30 },
            { key: 'diagnostico',                   header: 'Diagnostico',              width: 40 },
            { key: 'examenes',                      header: 'Examenes',                 width: 30 },
            { key: 'laboratorio',                   header: 'Laboratorio',              width: 30 },
            { key: 'gabinete',                      header: 'Gabinete',                 width: 30 },
            { key: 'tratamiento_niveles',           header: 'Tratamiento_niveles',      width: 50 },
            { key: 'tratamiento_1_general',         header: 'Tratamiento_general',      width: 50 },
            { key: 'complicaciones',                header: 'Complicaciones',           width: 30 },
            { key: 'prestaciones_text',             header: 'Prestaciones',             width: 60 },
            { key: 'fuentes',                       header: 'Fuentes',                  width: 14, type: 'array' },
          ],
          // Hook para pre-procesar prestaciones al exportar
          // (la columna prestaciones_text es derivada)
          examples: [{
            id: '',
            nombre: 'Ejemplo: Anemia ferropénica',
            nombres_alt: 'anemia por deficiencia de hierro',
            cie10: 'D50 | D50.0 | D50.9',
            especialidad: 'Hematología',
            niveles_atencion: 'I | II | III',
            resumen: 'Anemia por déficit de hierro corporal total...',
            etiopatogenia_fisiopatologia: 'Aporte insuficiente, mala absorción, pérdidas crónicas...',
            signos_sintomas: 'Palidez, fatiga, taquicardia...',
            diagnostico: 'Hemograma con Hb baja, VCM bajo, ferritina baja...',
            laboratorio: 'Hemograma completo, ferritina, hierro sérico, TIBC',
            tratamiento_1_general: 'Sulfato ferroso 3-6 mg/kg/día de Fe elemental...',
            prestaciones_text: 'Sulfato ferroso 60mg, 1 tableta cada 12h ## Tomar con vitamina C, evitar lácteos || Educación nutricional ## Dieta rica en hierro y vitamina C',
            fuentes: 'admin',
          }],
        },
      });

      // Sobreescribir handler de export Excel para serializar prestaciones
      // Lo hacemos interceptando ANTES de que se llame al handler default.
      const xlsxBtn = toolbar.querySelector('.rb-admin-export-xlsx');
      if (xlsxBtn) {
        // Reemplazar el listener: serializar prestaciones a string antes de exportar
        const newBtn = xlsxBtn.cloneNode(true);
        xlsxBtn.replaceWith(newBtn);
        newBtn.addEventListener('click', async () => {
          window.Auth?.gateAdmin(async () => {
            window.State.toast('Generando Excel...', 'info', 1500);
            const items = state.db.patologias.map(p => ({
              ...p,
              prestaciones_text: (p.prestaciones || []).map(pr =>
                `${pr.tratamiento_prestacion || ''} ## ${pr.observaciones || ''}`
              ).join(' || '),
            }));
            const ok = await window.ExcelIO.export(items, {
              filename: 'patologias.xlsx',
              sheetName: 'Patologias',
              columns: toolbar._excelColumns || [
                { key: 'id', header: 'ID' },
                { key: 'nombre', header: 'Nombre' },
                { key: 'cie10', header: 'CIE10' },
                { key: 'especialidad', header: 'Especialidad' },
                { key: 'resumen', header: 'Resumen' },
                { key: 'prestaciones_text', header: 'Prestaciones', width: 60 },
              ],
            });
            if (ok) {
              window.State.toast('✓ patologias.xlsx descargado', 'ok');
              window.Auth?.audit('export_xlsx', 'DB_PATOLOGIAS → patologias.xlsx');
            }
          });
        });
      }

      // Hook el handler de import también: parsear prestaciones de vuelta
      const xlsxImpBtn = toolbar.querySelector('.rb-admin-import-xlsx');
      if (xlsxImpBtn) {
        const newImp = xlsxImpBtn.cloneNode(true);
        xlsxImpBtn.replaceWith(newImp);
        newImp.addEventListener('click', () => {
          window.Auth?.gateAdmin(() => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.xlsx,.xls';
            input.style.display = 'none';
            input.addEventListener('change', async (e) => {
              const file = e.target.files[0];
              if (!file) return;
              window.State.toast('Leyendo Excel...', 'info', 1500);
              try {
                const records = await window.ExcelIO.import(file, {
                  columns: [
                    { key: 'id', header: 'ID' },
                    { key: 'nombre', header: 'Nombre' },
                    { key: 'nombres_alt', header: 'Nombres_alt', type: 'array' },
                    { key: 'cie10', header: 'CIE10', type: 'array' },
                    { key: 'especialidad', header: 'Especialidad' },
                    { key: 'niveles_atencion', header: 'Niveles_atencion', type: 'array' },
                    { key: 'resumen', header: 'Resumen' },
                    { key: 'etiopatogenia_fisiopatologia', header: 'Etiopatogenia' },
                    { key: 'signos_sintomas', header: 'Signos_sintomas' },
                    { key: 'signos', header: 'Signos' },
                    { key: 'sintomas', header: 'Sintomas' },
                    { key: 'diagnostico', header: 'Diagnostico' },
                    { key: 'examenes', header: 'Examenes' },
                    { key: 'laboratorio', header: 'Laboratorio' },
                    { key: 'gabinete', header: 'Gabinete' },
                    { key: 'tratamiento_niveles', header: 'Tratamiento_niveles' },
                    { key: 'tratamiento_1_general', header: 'Tratamiento_general' },
                    { key: 'complicaciones', header: 'Complicaciones' },
                    { key: 'prestaciones_text', header: 'Prestaciones' },
                    { key: 'fuentes', header: 'Fuentes', type: 'array' },
                  ],
                });
                // Parsear prestaciones_text → array de objetos
                records.forEach(r => {
                  if (r.prestaciones_text) {
                    r.prestaciones = String(r.prestaciones_text).split(/\s*\|\|\s*/).filter(Boolean).map(line => {
                      const parts = line.split(/\s*##\s*/);
                      return {
                        tratamiento_prestacion: parts[0] || '',
                        observaciones: parts[1] || '',
                      };
                    });
                  } else {
                    r.prestaciones = [];
                  }
                  delete r.prestaciones_text;
                  if (!r.id) r.id = 'P' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 4);
                });

                const mode = window.confirm(
                  `Se leyeron ${records.length} patologías.\n\n` +
                  `Aceptar = REEMPLAZAR los datos actuales\n` +
                  `Cancelar = AÑADIR los nuevos a los existentes`
                ) ? 'replace' : 'append';

                if (mode === 'replace') {
                  window.State.set(`backup_DB_PATOLOGIAS_${Date.now()}`, state.db.patologias);
                  state.db.patologias = records;
                } else {
                  state.db.patologias = state.db.patologias.concat(records);
                }
                window.State.persistAdminDB('DB_PATOLOGIAS', 'patologias');
                window.State.toast(`✓ ${records.length} patologías ${mode === 'replace' ? 'cargadas' : 'añadidas'}`, 'ok', 3500);
                window.Auth?.audit('import_xlsx', `DB_PATOLOGIAS ← ${file.name} (${records.length} regs, ${mode})`);
                window.render_clinica(panel);
              } catch (err) {
                window.State.toast('Error: ' + err.message, 'error', 5000);
                console.error(err);
              }
            });
            document.body.appendChild(input);
            input.click();
            setTimeout(() => input.remove(), 1000);
          });
        });
      }
    }

    bindFilters();
    renderList();
    renderDetail();
  };

  // === Schema para el editor modal =========================================
  const PATOLOGIA_SCHEMA = [
    { key: 'nombre',                       label: 'Nombre',                          type: 'text', required: true },
    { key: 'nombres_alt',                  label: 'Nombres alternativos / sinónimos', type: 'tags' },
    { key: 'cie10',                        label: 'Códigos CIE-10',                  type: 'tags', help: 'Separados por comas. Ej: A06, A06.0' },
    { key: 'especialidad',                 label: 'Especialidad',                    type: 'text' },
    { key: 'niveles_atencion',             label: 'Niveles de atención',             type: 'tags', help: 'Ej: I, II, III' },
    { key: 'resumen',                      label: 'Resumen clínico',                 type: 'textarea', rows: 3 },
    { key: 'etiopatogenia_fisiopatologia', label: 'Etiopatogenia / Fisiopatología',  type: 'textarea', rows: 4 },
    { key: 'signos_sintomas',              label: 'Signos y síntomas',               type: 'textarea', rows: 4 },
    { key: 'signos',                       label: 'Signos (detalle)',                type: 'textarea', rows: 3 },
    { key: 'sintomas',                     label: 'Síntomas (detalle)',              type: 'textarea', rows: 3 },
    { key: 'diagnostico',                  label: 'Diagnóstico',                     type: 'textarea', rows: 3 },
    { key: 'examenes',                     label: 'Exámenes complementarios',        type: 'textarea', rows: 3 },
    { key: 'laboratorio',                  label: 'Laboratorio',                     type: 'textarea', rows: 3 },
    { key: 'gabinete',                     label: 'Gabinete',                        type: 'textarea', rows: 3 },
    { key: 'tratamiento_niveles',          label: 'Tratamiento por niveles',         type: 'textarea', rows: 4 },
    { key: 'tratamiento_1_general',        label: 'Tratamiento general',             type: 'textarea', rows: 4 },
    { key: 'complicaciones',               label: 'Complicaciones',                  type: 'textarea', rows: 3 },
    { key: 'prestaciones',                 label: 'Prestaciones Ley 475',            type: 'list',
      itemSchema: [
        { key: 'tratamiento_prestacion', label: 'Tratamiento / Prestación', type: 'textarea', rows: 3, required: true },
        { key: 'observaciones',          label: 'Observaciones',            type: 'textarea', rows: 2 },
      ],
    },
  ];

  // === Admin: crear/editar/eliminar patología ==============================
  function promptNewPatologia(panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: 'Nueva patología',
      schema: PATOLOGIA_SCHEMA,
      data: {},
      onSave: (data) => {
        const id = 'P' + Date.now().toString(36).toUpperCase();
        data.fuentes = ['admin'];
        if (!data.nombres_alt) data.nombres_alt = [];
        if (!data.cie10) data.cie10 = [];
        if (!data.niveles_atencion) data.niveles_atencion = [];
        if (!data.prestaciones) data.prestaciones = [];
        state.db.patologias.push({ id, ...data });
        window.State.persistAdminDB('DB_PATOLOGIAS', 'patologias');
        window.Auth?.audit('add_patologia', `${id}: ${data.nombre}`);
        state.selected = id;
        window.render_clinica(panel);
        window.State?.toast(`✓ Patología "${data.nombre}" creada`, 'ok');
      },
    });
  }

  function promptEditPatologia(pat, panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: `Editar — ${pat.nombre}`,
      schema: PATOLOGIA_SCHEMA,
      data: pat,
      onSave: (data) => {
        Object.assign(pat, data);
        window.State.persistAdminDB('DB_PATOLOGIAS', 'patologias');
        window.Auth?.audit('edit_patologia', `${pat.id}: ${data.nombre}`);
        window.render_clinica(panel);
        window.State?.toast(`✓ Patología actualizada`, 'ok');
      },
    });
  }

  function deletePatologia(id, panel) {
    const p = state.db.patologias.find(x => x.id === id);
    if (!p) return;
    if (!window.confirm(`¿Eliminar "${p.nombre}" de la base?\n\nEsta acción modificará la BD local.`)) return;
    state.db.patologias = state.db.patologias.filter(x => x.id !== id);
    if (state.selected === id) state.selected = null;
    window.State.persistAdminDB('DB_PATOLOGIAS', 'patologias');
    window.Auth?.audit('delete_patologia', `${id}: ${p.nombre}`);
    window.render_clinica(panel);
  }

  // === Listener: navegar a una patología desde el buscador omnipotente =====
  document.addEventListener('rb:focus-patologia', (e) => {
    const id = e.detail.id;
    // Si M6 aún no se renderizó, lo renderizamos ahora
    const panel = document.querySelector('.tab-panel[data-panel="clinica"]');
    if (panel && !panel.dataset.loaded) {
      window.render_clinica(panel);
      panel.dataset.loaded = '1';
    }
    selectPatologia(id);
  });
})();
