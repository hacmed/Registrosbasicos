/* ============================================================================
   m7-pai-vigil.js — Módulo 7: PAI (vacunación) + Vigilancia Epidemiológica
   Dos secciones lado a lado:
     A) Esquemas de vacunación del PAI Bolivia (19 vacunas, 22 campos cada una)
     B) Protocolos de vigilancia (13 patologías de notificación obligatoria)
   ============================================================================ */
(function () {
  'use strict';

  const state = {
    dbPai: null,
    dbVig: null,
    activeSection: 'pai',     // 'pai' | 'vigilancia'
    selectedPai: null,
    selectedVig: null,
    filter: { query: '' },
  };

  // === Utilidades ===========================================================
  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }
  function normalize(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }
  function paragraphs(text) {
    if (!text) return '';
    return text.split(/\n+/).map(l => l.trim()).filter(Boolean)
      .map(l => `<p>${esc(l)}</p>`).join('');
  }

  // === Filtros ==============================================================
  function getFilteredPai() {
    if (!state.dbPai) return [];
    const nq = normalize(state.filter.query);
    return state.dbPai.pai.filter(v => {
      if (!nq) return true;
      const hay = normalize(v.vacuna + ' ' + v.tipo + ' ' + v.edad_esquema + ' ' + v.descripcion);
      return hay.includes(nq);
    });
  }

  function getFilteredVig() {
    if (!state.dbVig) return [];
    const nq = normalize(state.filter.query);
    return state.dbVig.vigilancia.filter(v => {
      if (!nq) return true;
      const hay = normalize(v.patologia + ' ' + v.definicion_caso + ' ' + v.criterios.join(' '));
      return hay.includes(nq);
    });
  }

  // === Renderizado de la lista ==============================================
  function renderPaiList() {
    const listEl = document.getElementById('m7-pai-list');
    if (!listEl) return;
    const items = getFilteredPai();
    if (!items.length) {
      listEl.innerHTML = `<div class="empty-state"><p class="muted small">Sin vacunas</p></div>`;
      return;
    }
    listEl.innerHTML = items.map(v => {
      const sel = state.selectedPai === v.id ? ' is-selected' : '';
      return `
        <button class="m6-list-item${sel}" data-id="${v.id}">
          <div class="m6-list-h">
            <span class="badge badge-clinic">${esc(v.numero_dosis || '—')} dosis</span>
            <span class="badge badge-mute tiny">${esc(v.tipo || '')}</span>
          </div>
          <div class="m6-list-name">${esc(v.vacuna)}</div>
          <div class="m6-list-espe">${esc(v.edad_esquema || '')}</div>
        </button>`;
    }).join('');
    listEl.querySelectorAll('.m6-list-item').forEach(el => {
      el.addEventListener('click', () => {
        state.selectedPai = el.dataset.id;
        renderPaiList(); renderPaiDetail();
        document.querySelector('.m6-layout')?.classList.add('is-detail-active');
      });
    });
  }

  function renderVigList() {
    const listEl = document.getElementById('m7-vig-list');
    if (!listEl) return;
    const items = getFilteredVig();
    if (!items.length) {
      listEl.innerHTML = `<div class="empty-state"><p class="muted small">Sin protocolos</p></div>`;
      return;
    }
    listEl.innerHTML = items.map(v => {
      const sel = state.selectedVig === v.id ? ' is-selected' : '';
      const noti = (v.notificacion || '').toLowerCase().includes('inmediata');
      const notiBadge = noti
        ? '<span class="badge badge-rose">Inmediata</span>'
        : '<span class="badge badge-ochre">Semanal</span>';
      return `
        <button class="m6-list-item${sel}" data-id="${v.id}">
          <div class="m6-list-h">${notiBadge}</div>
          <div class="m6-list-name">${esc(v.patologia)}</div>
          <div class="m6-list-espe">${esc(v.notificacion || '')}</div>
        </button>`;
    }).join('');
    listEl.querySelectorAll('.m6-list-item').forEach(el => {
      el.addEventListener('click', () => {
        state.selectedVig = el.dataset.id;
        renderVigList(); renderVigDetail();
        document.querySelector('.m6-layout')?.classList.add('is-detail-active');
      });
    });
  }

  // === Renderizado del detalle ==============================================
  function renderPaiDetail() {
    const detail = document.getElementById('m7-pai-detail');
    if (!detail) return;
    if (!state.selectedPai) {
      detail.innerHTML = `
        <div class="m6-detail-empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M11 12V8M11 8H7m4 0c0-2.21 1.79-4 4-4M4 17l3 3M8 13l8-8" stroke-linecap="round"/></svg>
          <div class="empty-state-title">Selecciona una vacuna</div>
          <p class="muted small">${state.dbPai.pai.length} vacunas del PAI Bolivia</p>
        </div>`;
      return;
    }
    const v = state.dbPai.pai.find(x => x.id === state.selectedPai);
    if (!v) return;

    const section = (title, content, defaultOpen = false) => {
      if (!content) return '';
      return `
        <details class="acc" ${defaultOpen ? 'open' : ''}>
          <summary>
            <span>${esc(title)}</span>
            <svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          </summary>
          <div class="acc-body">${content}</div>
        </details>`;
    };

    // Resumen visual del esquema en grid
    const esquemaGrid = `
      <div class="m7-esquema-grid">
        ${v.edad_esquema ? `<div class="m7-cell"><span class="m7-cell-l">Edad / esquema</span><span class="m7-cell-v">${esc(v.edad_esquema)}</span></div>` : ''}
        ${v.dosis ? `<div class="m7-cell"><span class="m7-cell-l">Dosis</span><span class="m7-cell-v">${esc(v.dosis)}</span></div>` : ''}
        ${v.numero_dosis ? `<div class="m7-cell"><span class="m7-cell-l">N° dosis</span><span class="m7-cell-v">${esc(v.numero_dosis)}</span></div>` : ''}
        ${v.via_lugar ? `<div class="m7-cell"><span class="m7-cell-l">Vía / lugar</span><span class="m7-cell-v">${esc(v.via_lugar)}</span></div>` : ''}
        ${v.duracion_abierto ? `<div class="m7-cell"><span class="m7-cell-l">Duración abierto</span><span class="m7-cell-v">${esc(v.duracion_abierto)}</span></div>` : ''}
        ${v.efectividad ? `<div class="m7-cell"><span class="m7-cell-l">Efectividad</span><span class="m7-cell-v">${esc(v.efectividad)}</span></div>` : ''}
      </div>
    `;

    detail.innerHTML = `
      <div class="m6-detail-h">
        <button class="m6-back btn btn-ghost" id="m7-pai-back">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
          <span>Volver</span>
        </button>
        <div class="m6-detail-title">
          <h1>${esc(v.vacuna)}</h1>
          <p class="muted small mt-2">${esc(v.tipo || '')}</p>
          ${v.descripcion ? `<p class="small mt-2">${esc(v.descripcion)}</p>` : ''}
        </div>
      </div>

      ${esquemaGrid}

      ${section('Presentación y composición',
        (v.presentacion ? `<p><strong>Presentación:</strong> ${esc(v.presentacion)}</p>` : '') +
        (v.composicion ? `<p class="mt-2"><strong>Composición:</strong> ${esc(v.composicion)}</p>` : ''))}
      ${section('Procedimiento de aplicación',
        (v.previos ? `<p><strong>Previos:</strong> ${esc(v.previos)}</p>` : '') +
        (v.procedimiento ? `<p class="mt-2"><strong>Procedimiento:</strong> ${esc(v.procedimiento)}</p>` : '') +
        (v.insumos ? `<p class="mt-2"><strong>Insumos:</strong> ${esc(v.insumos)}</p>` : ''))}
      ${section('Contraindicaciones', paragraphs(v.contraindicaciones), true)}
      ${section('Eventos adversos esperados', paragraphs(v.eventos_esperados))}
      ${section('Casos excepcionales', paragraphs(v.casos_excepcionales))}
      ${section('Uso simultáneo con otras vacunas', paragraphs(v.uso_simultaneo))}
      ${section('Consideraciones generales', paragraphs(v.consideraciones))}
      ${section('Registro', paragraphs(v.registro))}
      ${section('Comunicación interpersonal', paragraphs(v.comunicacion))}

      <div class="m6-detail-foot tiny muted mt-6">
        <p>ID: <span class="mono">${v.id}</span> · Fuente: T_PAI.xlsx (Bolivia)</p>
        ${window.Auth?.isAdmin() ? `
          <div class="row gap-2 mt-2" style="flex-wrap:wrap;">
            <button class="btn btn-primary" id="m7-pai-edit" style="font-size:0.85rem;padding:6px 12px;">✏️ Editar esta vacuna</button>
            <button class="btn btn-ghost" id="m7-pai-delete" style="font-size:0.85rem;color:var(--rose);border-color:var(--rose);">
              🗑️ Eliminar
            </button>
          </div>
        ` : ''}
      </div>
    `;

    document.getElementById('m7-pai-back')?.addEventListener('click', () => {
      document.querySelector('.m6-layout')?.classList.remove('is-detail-active');
    });
    document.getElementById('m7-pai-edit')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="pai-vigil"]');
        if (panel) promptEditVacuna(v, panel);
      });
    });
    document.getElementById('m7-pai-delete')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="pai-vigil"]');
        if (panel) deleteVacuna(v.id, panel);
      });
    });
  }

  function renderVigDetail() {
    const detail = document.getElementById('m7-vig-detail');
    if (!detail) return;
    if (!state.selectedVig) {
      detail.innerHTML = `
        <div class="m6-detail-empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 9v4M12 17h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <div class="empty-state-title">Selecciona un protocolo</div>
          <p class="muted small">${state.dbVig.vigilancia.length} patologías de notificación obligatoria</p>
        </div>`;
      return;
    }
    const v = state.dbVig.vigilancia.find(x => x.id === state.selectedVig);
    if (!v) return;

    const inmediata = (v.notificacion || '').toLowerCase().includes('inmediata');
    const notiBadge = inmediata
      ? `<div class="m7-noti-alert"><strong>⚠ Notificación inmediata</strong> · ${esc(v.notificacion)}</div>`
      : `<div class="m7-noti-ok"><strong>Notificación:</strong> ${esc(v.notificacion)}</div>`;

    detail.innerHTML = `
      <div class="m6-detail-h">
        <button class="m6-back btn btn-ghost" id="m7-vig-back">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
          <span>Volver</span>
        </button>
        <div class="m6-detail-title">
          <h1>${esc(v.patologia)}</h1>
        </div>
      </div>

      ${notiBadge}

      <details class="acc" open>
        <summary>
          <span>Definición de caso sospechoso</span>
          <svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="acc-body">${paragraphs(v.definicion_caso)}</div>
      </details>

      <details class="acc" open>
        <summary>
          <span>Criterios de confirmación (${v.criterios.length})</span>
          <svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="acc-body">
          <ol class="m6-prest">
            ${v.criterios.map((c, i) => `
              <li>
                <div class="m6-prest-num">${i + 1}</div>
                <div class="m6-prest-body"><p>${esc(c)}</p></div>
              </li>
            `).join('')}
          </ol>
        </div>
      </details>

      <div class="m6-detail-foot tiny muted mt-6">
        <p>ID: <span class="mono">${v.id}</span> · Fuente: T_VIGILANCIA.xlsx (Bolivia)</p>
        ${window.Auth?.isAdmin() ? `
          <div class="row gap-2 mt-2" style="flex-wrap:wrap;">
            <button class="btn btn-primary" id="m7-vig-edit" style="font-size:0.85rem;padding:6px 12px;">✏️ Editar este protocolo</button>
            <button class="btn btn-ghost" id="m7-vig-delete" style="font-size:0.85rem;color:var(--rose);border-color:var(--rose);">
              🗑️ Eliminar
            </button>
          </div>
        ` : ''}
      </div>
    `;

    document.getElementById('m7-vig-back')?.addEventListener('click', () => {
      document.querySelector('.m6-layout')?.classList.remove('is-detail-active');
    });
    document.getElementById('m7-vig-edit')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="pai-vigil"]');
        if (panel) promptEditVigilancia(v, panel);
      });
    });
    document.getElementById('m7-vig-delete')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        const panel = document.querySelector('.tab-panel[data-panel="pai-vigil"]');
        if (panel) deleteVigilancia(v.id, panel);
      });
    });
  }

  // === Cambio de sección PAI ↔ Vigilancia ===================================
  function switchSection(s) {
    state.activeSection = s;
    document.querySelectorAll('.m7-section').forEach(el => {
      el.classList.toggle('is-active', el.dataset.section === s);
    });
    document.querySelectorAll('.m7-tab').forEach(el => {
      el.classList.toggle('is-active', el.dataset.section === s);
    });
    document.querySelector('.m6-layout')?.classList.remove('is-detail-active');
  }

  // === Entry point ==========================================================
  window.render_pai_vigil = function (panel) {
    state.dbPai = window.DB_PAI;
    state.dbVig = window.DB_VIGILANCIA;
    if (!state.dbPai || !state.dbVig) {
      panel.innerHTML = '<div class="empty-state">Cargando datos...</div>';
      return;
    }
    if (window.State?.applyAdminOverride('DB_PAI', 'pai')) state.dbPai = window.DB_PAI;
    if (window.State?.applyAdminOverride('DB_VIGILANCIA', 'vigilancia')) state.dbVig = window.DB_VIGILANCIA;

    const isAdmin = window.Auth?.isAdmin();
    const paiTools = window.State?.renderAdminToolbar('DB_PAI', { ns: 'pai' }) || '';
    const vigTools = window.State?.renderAdminToolbar('DB_VIGILANCIA', { ns: 'vigilancia' }) || '';

    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>PAI · Vigilancia</h1>
          <p class="muted small">
            ${state.dbPai.pai.length} esquemas de vacunación ·
            ${state.dbVig.vigilancia.length} protocolos epidemiológicos
          </p>
        </div>
      </div>

      <div class="m7-tabs">
        <button class="m7-tab is-active" data-section="pai">
          💉 PAI (Vacunación)
          <span class="badge badge-mute tiny">${state.dbPai.pai.length}</span>
        </button>
        <button class="m7-tab" data-section="vigilancia">
          ⚠ Vigilancia Epidemiológica
          <span class="badge badge-mute tiny">${state.dbVig.vigilancia.length}</span>
        </button>
      </div>

      <div class="m6-filters">
        <div class="m6-filter-search">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input type="search" id="m7-q" placeholder="Filtrar..." class="field-input" />
        </div>
      </div>

      <!-- Sección PAI -->
      <div class="m7-section is-active" data-section="pai">
        ${isAdmin ? `<div class="m7-admin-bar" data-kind="pai">${paiTools}</div>` : ''}
        <div class="m6-layout">
          <aside class="m6-master">
            <div class="m6-list" id="m7-pai-list"></div>
          </aside>
          <section class="m6-detail" id="m7-pai-detail"></section>
        </div>
      </div>

      <!-- Sección Vigilancia -->
      <div class="m7-section" data-section="vigilancia">
        ${isAdmin ? `<div class="m7-admin-bar" data-kind="vigilancia">${vigTools}</div>` : ''}
        <div class="m6-layout">
          <aside class="m6-master">
            <div class="m6-list" id="m7-vig-list"></div>
          </aside>
          <section class="m6-detail" id="m7-vig-detail"></section>
        </div>
      </div>
    `;

    // Bind tabs internos
    panel.querySelectorAll('.m7-tab').forEach(t => {
      t.addEventListener('click', () => switchSection(t.dataset.section));
    });

    // Bind búsqueda
    const q = document.getElementById('m7-q');
    let timer;
    q?.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        state.filter.query = q.value;
        renderPaiList();
        renderVigList();
      }, 200);
    });

    // Bindear toolbars admin
    const paiBar = panel.querySelector('.m7-admin-bar[data-kind="pai"] .rb-admin-tools');
    if (paiBar) {
      window.State.bindAdminToolbar(paiBar, {
        filename: 'db_pai.js',
        onChange: () => { state.dbPai = window.DB_PAI; window.render_pai_vigil(panel); },
        onAdd: () => promptNewVacuna(panel),
      });
    }
    const vigBar = panel.querySelector('.m7-admin-bar[data-kind="vigilancia"] .rb-admin-tools');
    if (vigBar) {
      window.State.bindAdminToolbar(vigBar, {
        filename: 'db_vigilancia.js',
        onChange: () => { state.dbVig = window.DB_VIGILANCIA; window.render_pai_vigil(panel); },
        onAdd: () => promptNewVigilancia(panel),
      });
    }

    renderPaiList();
    renderPaiDetail();
    renderVigList();
    renderVigDetail();
  };

  // === Admin: crear/eliminar vacuna / protocolo de vigilancia ==============
  // === Schemas para el editor modal ========================================
  const VACUNA_SCHEMA = [
    { key: 'vacuna',              label: 'Nombre de la vacuna',                type: 'text', required: true },
    { key: 'tipo',                label: 'Tipo de vacuna',                     type: 'text', help: 'Ej: Viva atenuada, Inactivada, Toxoide, Recombinante' },
    { key: 'edad_esquema',        label: 'Edad / Esquema',                     type: 'text', help: 'Ej: RN, 2 meses, 6-23m, embarazadas' },
    { key: 'numero_dosis',        label: 'Número de dosis',                    type: 'text' },
    { key: 'dosis',               label: 'Dosis',                              type: 'text', help: 'Ej: 0.5 ml, 0.1 ml ID' },
    { key: 'via_lugar',           label: 'Vía y lugar de aplicación',          type: 'text', help: 'Ej: IM, deltoides izquierdo' },
    { key: 'presentacion',        label: 'Presentación',                       type: 'text' },
    { key: 'composicion',         label: 'Composición',                        type: 'textarea', rows: 3 },
    { key: 'duracion_abierto',    label: 'Duración una vez abierto',           type: 'text' },
    { key: 'efectividad',         label: 'Efectividad',                        type: 'text' },
    { key: 'previos',             label: 'Procedimientos previos',             type: 'textarea', rows: 3 },
    { key: 'procedimiento',       label: 'Procedimiento de aplicación',        type: 'textarea', rows: 4 },
    { key: 'insumos',             label: 'Insumos requeridos',                 type: 'textarea', rows: 3 },
    { key: 'contraindicaciones',  label: 'Contraindicaciones',                 type: 'textarea', rows: 3 },
    { key: 'eventos_esperados',   label: 'ESAVI / eventos esperados',          type: 'textarea', rows: 3 },
    { key: 'casos_excepcionales', label: 'Casos excepcionales',                type: 'textarea', rows: 3 },
    { key: 'uso_simultaneo',      label: 'Uso simultáneo con otras vacunas',   type: 'textarea', rows: 2 },
    { key: 'consideraciones',     label: 'Consideraciones especiales',         type: 'textarea', rows: 3 },
    { key: 'registro',            label: 'Registro y carnet',                  type: 'textarea', rows: 2 },
    { key: 'comunicacion',        label: 'Comunicación al cuidador',           type: 'textarea', rows: 2 },
    { key: 'descripcion',         label: 'Descripción general',                type: 'textarea', rows: 3 },
  ];

  const VIGILANCIA_SCHEMA = [
    { key: 'patologia',       label: 'Patología bajo vigilancia',       type: 'text', required: true },
    { key: 'notificacion',    label: 'Tipo de notificación',            type: 'select',
      options: ['Inmediata', 'Semanal', 'Mensual'], allowEmpty: false },
    { key: 'definicion_caso', label: 'Definición de caso sospechoso',   type: 'textarea', rows: 4, required: true },
    { key: 'criterios',       label: 'Criterios de confirmación',       type: 'tags',
      help: 'Separa cada criterio con coma. Ej: Aislamiento microbiológico, IgM positivo, Detección PCR' },
  ];

  function promptNewVacuna(panel) {
    if (!window.ModalEditor) {
      window.State?.toast('ModalEditor no disponible — recarga la página', 'error');
      return;
    }
    window.ModalEditor.open({
      title: 'Nueva vacuna del PAI',
      schema: VACUNA_SCHEMA,
      data: {},
      onSave: (data) => {
        const id = 'V' + Date.now().toString(36).toUpperCase();
        state.dbPai.pai.push({ id, ...data });
        window.State.persistAdminDB('DB_PAI', 'pai');
        window.Auth?.audit('add_vacuna', `${id}: ${data.vacuna}`);
        state.selectedPai = id;
        window.render_pai_vigil(panel);
        window.State?.toast(`✓ Vacuna "${data.vacuna}" creada`, 'ok');
      },
    });
  }

  function promptEditVacuna(vac, panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: `Editar — ${vac.vacuna}`,
      schema: VACUNA_SCHEMA,
      data: vac,
      onSave: (data) => {
        Object.assign(vac, data);
        window.State.persistAdminDB('DB_PAI', 'pai');
        window.Auth?.audit('edit_vacuna', `${vac.id}: ${data.vacuna}`);
        window.render_pai_vigil(panel);
        window.State?.toast(`✓ Vacuna actualizada`, 'ok');
      },
    });
  }

  function deleteVacuna(id, panel) {
    const v = state.dbPai.pai.find(x => x.id === id);
    if (!v) return;
    if (!window.confirm(`¿Eliminar "${v.vacuna}"?`)) return;
    state.dbPai.pai = state.dbPai.pai.filter(x => x.id !== id);
    if (state.selectedPai === id) state.selectedPai = null;
    window.State.persistAdminDB('DB_PAI', 'pai');
    window.Auth?.audit('delete_vacuna', `${id}: ${v.vacuna}`);
    window.render_pai_vigil(panel);
  }

  function promptNewVigilancia(panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: 'Nuevo protocolo de vigilancia',
      schema: VIGILANCIA_SCHEMA,
      data: { notificacion: 'Semanal' },
      onSave: (data) => {
        const id = 'X' + Date.now().toString(36).toUpperCase();
        state.dbVig.vigilancia.push({ id, ...data });
        window.State.persistAdminDB('DB_VIGILANCIA', 'vigilancia');
        window.Auth?.audit('add_vigilancia', `${id}: ${data.patologia}`);
        state.selectedVig = id;
        window.render_pai_vigil(panel);
        window.State?.toast(`✓ Protocolo "${data.patologia}" creado`, 'ok');
      },
    });
  }

  function promptEditVigilancia(vig, panel) {
    if (!window.ModalEditor) return;
    window.ModalEditor.open({
      title: `Editar — ${vig.patologia}`,
      schema: VIGILANCIA_SCHEMA,
      data: vig,
      onSave: (data) => {
        Object.assign(vig, data);
        window.State.persistAdminDB('DB_VIGILANCIA', 'vigilancia');
        window.Auth?.audit('edit_vigilancia', `${vig.id}: ${data.patologia}`);
        window.render_pai_vigil(panel);
        window.State?.toast(`✓ Protocolo actualizado`, 'ok');
      },
    });
  }

  function deleteVigilancia(id, panel) {
    const v = state.dbVig.vigilancia.find(x => x.id === id);
    if (!v) return;
    if (!window.confirm(`¿Eliminar protocolo "${v.patologia}"?`)) return;
    state.dbVig.vigilancia = state.dbVig.vigilancia.filter(x => x.id !== id);
    if (state.selectedVig === id) state.selectedVig = null;
    window.State.persistAdminDB('DB_VIGILANCIA', 'vigilancia');
    window.Auth?.audit('delete_vigilancia', `${id}: ${v.patologia}`);
    window.render_pai_vigil(panel);
  }

  // === Listeners del buscador omnipotente ====================================
  document.addEventListener('rb:focus-vacuna', (e) => {
    const id = e.detail.id;
    const panel = document.querySelector('.tab-panel[data-panel="pai-vigil"]');
    if (panel && !panel.dataset.loaded) {
      window.render_pai_vigil(panel);
      panel.dataset.loaded = '1';
    }
    switchSection('pai');
    state.selectedPai = id;
    renderPaiList(); renderPaiDetail();
    document.querySelector('.m6-layout')?.classList.add('is-detail-active');
  });

  document.addEventListener('rb:focus-vigilancia', (e) => {
    const id = e.detail.id;
    const panel = document.querySelector('.tab-panel[data-panel="pai-vigil"]');
    if (panel && !panel.dataset.loaded) {
      window.render_pai_vigil(panel);
      panel.dataset.loaded = '1';
    }
    switchSection('vigilancia');
    state.selectedVig = id;
    renderVigList(); renderVigDetail();
    document.querySelector('.m6-layout')?.classList.add('is-detail-active');
  });
})();
