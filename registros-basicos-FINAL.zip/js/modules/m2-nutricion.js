/* ============================================================================
   m2-nutricion.js — Módulo 2: Valoración Nutricional Integral
   - Cálculo de Z-scores con tablas LMS oficiales OMS (db_lms.js)
   - Indicadores: Talla/edad, Peso/edad, IMC/edad, Perímetro cefálico/edad,
                  Peso/talla (longitud o talla según edad)
   - GER Pediátrico (Schofield) y Adulto (Mifflin-St Jeor)
   - Gasto energético total (GER × PAL)
   - Visualización con curvas SVG interactivas (mediana ± 2 SD)
   ============================================================================ */
(function () {
  'use strict';

  const state = {
    db: null,
    input: {
      sex: '',
      dob: '',
      weight: null,
      height: null,
      hc: null,           // perímetro cefálico cm
      pal: 1.2,           // factor actividad física
      isPregnant: false,
      pregKgGain: 0,      // kg ganados durante el embarazo
    },
  };

  // === Utilidades ===========================================================
  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  // === Cálculos de edad ======================================================
  function calcAge(dobStr) {
    if (!dobStr) return null;
    const dob = new Date(dobStr);
    if (isNaN(dob.getTime())) return null;
    const now = new Date();
    if (dob > now) return null;
    const ms = now - dob;
    const totalMonths = ms / (1000 * 60 * 60 * 24 * 30.4375);
    const totalYears = totalMonths / 12;
    // Años/meses/días desglosados
    let years = now.getFullYear() - dob.getFullYear();
    let months = now.getMonth() - dob.getMonth();
    let days = now.getDate() - dob.getDate();
    if (days < 0) {
      months -= 1;
      const prev = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      days += prev;
    }
    if (months < 0) { years -= 1; months += 12; }
    return { years, months, days, totalMonths, totalYears, dob };
  }

  // === Interpolación lineal en tabla LMS =====================================
  function lmsAt(table, x) {
    if (!table || !table.length) return null;
    if (x <= table[0].x) return { ...table[0] };
    if (x >= table[table.length - 1].x) return { ...table[table.length - 1] };
    for (let i = 0; i < table.length - 1; i++) {
      const a = table[i], b = table[i + 1];
      if (x >= a.x && x <= b.x) {
        const t = (x - a.x) / (b.x - a.x);
        return {
          x,
          L: a.L + (b.L - a.L) * t,
          M: a.M + (b.M - a.M) * t,
          S: a.S + (b.S - a.S) * t,
        };
      }
    }
    return null;
  }

  // === Z-score (ecuación oficial OMS LMS) ====================================
  function zScore(value, L, M, S) {
    if (!value || !M || !S) return null;
    if (L === 0) return Math.log(value / M) / S;
    return (Math.pow(value / M, L) - 1) / (L * S);
  }

  // Inversa: valor en SD dado el Z (para dibujar las curvas de referencia)
  function valueFromZ(z, L, M, S) {
    if (L === 0) return M * Math.exp(S * z);
    return M * Math.pow(1 + L * S * z, 1 / L);
  }

  // === Clasificación de Z-score según OMS ===================================
  function zClass(z, indicator) {
    if (z === null || isNaN(z)) return { tier: 'neutral', label: 'Sin datos' };
    const ax = Math.abs(z);
    // Para HCFA, WfA: usar ±2 SD como umbral de alerta
    // Para BMI/edad, WFL/WFH: ±2 normal, +2 sobrepeso, +3 obesidad
    if (indicator === 'bmifa' || indicator === 'wfl' || indicator === 'wfh') {
      if (z < -3) return { tier: 'alert', label: 'Emaciación severa' };
      if (z < -2) return { tier: 'warn',  label: 'Emaciación' };
      if (z > 3)  return { tier: 'alert', label: 'Obesidad' };
      if (z > 2)  return { tier: 'warn',  label: 'Sobrepeso' };
      if (z > 1)  return { tier: 'warn',  label: 'Posible riesgo' };
      return { tier: 'ok', label: 'Normal' };
    }
    if (indicator === 'lhfa') {
      if (z < -3) return { tier: 'alert', label: 'Talla baja severa' };
      if (z < -2) return { tier: 'warn',  label: 'Talla baja' };
      if (z > 3)  return { tier: 'warn',  label: 'Talla alta' };
      return { tier: 'ok', label: 'Normal' };
    }
    if (indicator === 'wfa') {
      if (z < -3) return { tier: 'alert', label: 'Bajo peso severo' };
      if (z < -2) return { tier: 'warn',  label: 'Bajo peso' };
      if (z > 2)  return { tier: 'warn',  label: 'Peso elevado p/edad' };
      return { tier: 'ok', label: 'Normal' };
    }
    if (indicator === 'hcfa') {
      if (z < -2) return { tier: 'alert', label: 'Microcefalia' };
      if (z > 2)  return { tier: 'alert', label: 'Macrocefalia' };
      return { tier: 'ok', label: 'Normal' };
    }
    if (ax > 3) return { tier: 'alert', label: 'Crítico (±3 SD)' };
    if (ax > 2) return { tier: 'warn',  label: 'Alerta (±2 SD)' };
    return { tier: 'ok', label: 'Normal' };
  }

  // === Franja de SD en notación clínica =====================================
  // Devuelve la franja en que cae el z-score, ej: "-2 a -1 SD" o "0 a +1 SD"
  function bandSD(z) {
    if (z === null || isNaN(z)) return '—';
    if (z < -3)  return '< -3 SD';
    if (z < -2)  return '-3 a -2 SD';
    if (z < -1)  return '-2 a -1 SD';
    if (z < 0)   return '-1 a 0 SD';
    if (z < 1)   return '0 a +1 SD';
    if (z < 2)   return '+1 a +2 SD';
    if (z < 3)   return '+2 a +3 SD';
    return '> +3 SD';
  }

  // === IMC ===================================================================
  function bmi(weight, heightCm) {
    if (!weight || !heightCm) return null;
    const m = heightCm / 100;
    return weight / (m * m);
  }

  function bmiClass(b) {
    if (!b) return { tier: 'neutral', label: 'Sin datos' };
    if (b < 16)   return { tier: 'alert', label: 'Delgadez severa' };
    if (b < 17)   return { tier: 'warn',  label: 'Delgadez moderada' };
    if (b < 18.5) return { tier: 'warn',  label: 'Bajo peso' };
    if (b < 25)   return { tier: 'ok',    label: 'Normal' };
    if (b < 30)   return { tier: 'warn',  label: 'Sobrepeso' };
    if (b < 35)   return { tier: 'alert', label: 'Obesidad I' };
    if (b < 40)   return { tier: 'alert', label: 'Obesidad II' };
    return { tier: 'alert', label: 'Obesidad III' };
  }

  // === GER Schofield (pediátrico / juvenil hasta 18 años, kcal/día) ========
  // Ecuaciones FAO/WHO/UNU 1985, vigentes en guías SAFCI Bolivia
  function gerSchofield(sex, weight, ageY) {
    if (!weight || ageY === null) return null;
    let a = 0, b = 0;
    if (sex === 'M') {
      if (ageY < 3)       { a = 59.512; b = -30.4; }
      else if (ageY < 10) { a = 22.706; b = 504.3; }
      else if (ageY < 18) { a = 17.686; b = 658.2; }
      else                { a = 15.057; b = 692.2; }
    } else {
      if (ageY < 3)       { a = 58.317; b = -31.1; }
      else if (ageY < 10) { a = 20.315; b = 485.9; }
      else if (ageY < 18) { a = 13.384; b = 692.6; }
      else                { a = 14.818; b = 486.6; }
    }
    return a * weight + b;
  }

  // === GER Mifflin-St Jeor (adulto, kcal/día) ===============================
  function gerMifflin(sex, weight, heightCm, ageY) {
    if (!weight || !heightCm || ageY === null) return null;
    const base = 10 * weight + 6.25 * heightCm - 5 * ageY;
    return sex === 'M' ? base + 5 : base - 161;
  }

  // === Indicadores aplicables según edad ====================================
  function applicableIndicators(age) {
    if (!age) return [];
    const m = age.totalMonths;
    const list = [];
    if (m <= 228) list.push({ key: 'lhfa', label: 'Talla/edad', unit: 'cm' });
    if (m <= 120) list.push({ key: 'wfa',  label: 'Peso/edad',  unit: 'kg' });
    if (m <= 228) list.push({ key: 'bmifa',label: 'IMC/edad',   unit: 'kg/m²' });
    if (m <= 60)  list.push({ key: 'hcfa', label: 'Perímetro cefálico/edad', unit: 'cm' });
    if (m <= 24)  list.push({ key: 'wfl',  label: 'Peso/longitud', unit: 'kg', xUnit: 'cm' });
    else if (m <= 60) list.push({ key: 'wfh', label: 'Peso/talla', unit: 'kg', xUnit: 'cm' });
    return list;
  }

  // === Render del formulario =================================================
  function renderForm() {
    return `
      <div class="card m2-form">
        <div class="card-h">
          <h2>Datos del paciente</h2>
        </div>
        <div class="m2-form-grid">
          <label class="field">
            <span class="field-label">Sexo</span>
            <select class="field-select" id="m2-sex">
              <option value="">—</option>
              <option value="M">Masculino</option>
              <option value="F">Femenino</option>
            </select>
          </label>
          <label class="field">
            <span class="field-label">Fecha de nacimiento</span>
            <input type="date" class="field-input" id="m2-dob" />
          </label>
          <label class="field">
            <span class="field-label">Peso (kg)</span>
            <input type="number" inputmode="decimal" class="field-input" id="m2-w"
                   min="0" max="300" step="0.1" placeholder="ej. 12.5" />
          </label>
          <label class="field">
            <span class="field-label">Talla / longitud (cm)</span>
            <input type="number" inputmode="decimal" class="field-input" id="m2-h"
                   min="0" max="250" step="0.1" placeholder="ej. 85" />
          </label>
          <label class="field" id="m2-hc-w">
            <span class="field-label">Perímetro cefálico (cm)</span>
            <input type="number" inputmode="decimal" class="field-input" id="m2-hc"
                   min="0" max="80" step="0.1" placeholder="opcional (<5 años)" />
          </label>
          <label class="field" id="m2-pal-w">
            <span class="field-label">Factor de actividad (PAL)</span>
            <select class="field-select" id="m2-pal">
              <optgroup label="Estado clínico (encamado / reposo)">
                <option value="1.0">1.00 — Reposo absoluto / coma</option>
                <option value="1.1">1.10 — Encamado, consciente</option>
                <option value="1.15">1.15 — Postoperatorio inmediato</option>
              </optgroup>
              <optgroup label="Actividad habitual">
                <option value="1.2">1.20 — Sedentario / oficina</option>
                <option value="1.375">1.375 — Ligero (ejercicio 1-3 días/sem)</option>
                <option value="1.55" selected>1.55 — Moderado (ejercicio 3-5 días/sem)</option>
                <option value="1.725">1.725 — Intenso (ejercicio 6-7 días/sem)</option>
                <option value="1.9">1.90 — Muy intenso (trabajo físico + deporte)</option>
              </optgroup>
              <optgroup label="Atletas / casos especiales">
                <option value="2.0">2.00 — Atleta de resistencia</option>
                <option value="2.2">2.20 — Atleta de élite en competición</option>
                <option value="1.3">1.30 — Embarazo (1er trimestre)</option>
                <option value="1.5">1.50 — Embarazo (2do-3er trimestre)</option>
                <option value="1.7">1.70 — Lactancia exclusiva</option>
                <option value="1.4">1.40 — Recuperación / convalecencia</option>
                <option value="1.6">1.60 — Quemado / hipermetabólico</option>
              </optgroup>
            </select>
          </label>
        </div>
        <div class="m2-form-actions">
          <button class="btn btn-ghost" id="m2-clear">Limpiar</button>
        </div>
      </div>
    `;
  }

  // === Resumen del paciente ==================================================
  function renderSummary(age, b, bClass) {
    if (!age) {
      return '<div class="empty-state"><p class="muted small">Ingresa fecha de nacimiento</p></div>';
    }
    const ageLabel = age.totalYears >= 2
      ? `${age.years} año${age.years === 1 ? '' : 's'} ${age.months} mes${age.months === 1 ? '' : 'es'}`
      : `${age.years * 12 + age.months} meses ${age.days} días`;
    const grp = age.totalYears < 5 ? 'Preescolar'
            : age.totalYears < 10 ? 'Escolar'
            : age.totalYears < 18 ? 'Adolescente'
            : 'Adulto';
    return `
      <div class="m2-summary-grid">
        <div class="m2-sum-cell">
          <span class="m2-sum-l">Edad</span>
          <span class="m2-sum-v">${esc(ageLabel)}</span>
          <span class="m2-sum-sub">${grp}</span>
        </div>
        ${b ? `
          <div class="m2-sum-cell">
            <span class="m2-sum-l">IMC</span>
            <span class="m2-sum-v">${b.toFixed(1)}</span>
            <span class="m2-sum-sub badge badge-${bClass.tier === 'ok' ? 'clinic' : bClass.tier === 'warn' ? 'ochre' : bClass.tier === 'alert' ? 'rose' : 'mute'}">${esc(bClass.label)}</span>
          </div>` : ''}
      </div>
    `;
  }

  // === Tabla de Z-scores =====================================================
  function renderZTable(age) {
    if (!age || !state.input.sex) return '';
    const ind = applicableIndicators(age);
    if (!ind.length) return '';

    const rows = ind.map(it => {
      const tab = state.db[it.key]?.[state.input.sex];
      if (!tab) return null;
      // x: para edad → totalMonths; para WFL/WFH → talla
      let xVal, yVal;
      if (it.key === 'wfl' || it.key === 'wfh') {
        xVal = state.input.height;
        yVal = state.input.weight;
      } else if (it.key === 'hcfa') {
        xVal = age.totalMonths;
        yVal = state.input.hc;
      } else if (it.key === 'lhfa') {
        xVal = age.totalMonths;
        yVal = state.input.height;
      } else if (it.key === 'wfa') {
        xVal = age.totalMonths;
        yVal = state.input.weight;
      } else if (it.key === 'bmifa') {
        xVal = age.totalMonths;
        yVal = bmi(state.input.weight, state.input.height);
      }
      if (!yVal) return { it, status: 'missing' };
      const lms = lmsAt(tab, xVal);
      if (!lms) return { it, status: 'out-of-range' };
      const z = zScore(yVal, lms.L, lms.M, lms.S);
      const cls = zClass(z, it.key);
      return { it, z, lms, cls, yVal, xVal };
    });

    const html = rows.map(r => {
      if (!r) return '';
      if (r.status === 'missing') {
        return `<tr class="m2-z-row">
          <td>${esc(r.it.label)}</td>
          <td colspan="4" class="muted tiny">— sin dato —</td>
        </tr>`;
      }
      const tierClass = r.cls.tier === 'ok' ? 'clinic'
                     : r.cls.tier === 'warn' ? 'ochre'
                     : r.cls.tier === 'alert' ? 'rose' : 'mute';
      const band = bandSD(r.z);
      return `<tr class="m2-z-row" data-indicator="${r.it.key}">
        <td>
          <strong>${esc(r.it.label)}</strong>
          <div class="tiny muted">M=${r.lms.M.toFixed(2)} ${r.it.unit}</div>
        </td>
        <td class="mono">${r.yVal.toFixed(1)} ${r.it.unit}</td>
        <td class="mono"><strong>${r.z.toFixed(2)}</strong> SD</td>
        <td class="mono tiny">${esc(band)}</td>
        <td><span class="badge badge-${tierClass}">${esc(r.cls.label)}</span></td>
      </tr>`;
    }).join('');

    return `
      <div class="card mt-4">
        <div class="card-h">
          <h2>Z-scores antropométricos</h2>
          <span class="badge badge-mute tiny mono">OMS LMS</span>
        </div>
        <div class="m2-z-table-wrap">
          <table class="m2-z-table">
            <thead>
              <tr><th>Indicador</th><th>Valor</th><th>Z-score</th><th>Franja SD</th><th>Clasificación</th></tr>
            </thead>
            <tbody>${html}</tbody>
          </table>
        </div>
        <p class="tiny muted mt-2">
          Click en una fila para ver la curva de referencia con el punto del paciente.
        </p>
      </div>
    `;
  }

  // === Pestañas con curvas LMS de TODOS los indicadores aplicables =========
  function renderCurvesWithTabs(age, activeKey) {
    const indicators = applicableIndicators(age);
    if (!indicators.length) return '';
    // Si no se pasó activa o no es válida, usar la primera
    if (!activeKey || !indicators.find(i => i.key === activeKey)) {
      activeKey = indicators[0].key;
    }
    return `
      <div class="card mt-4">
        <div class="card-h">
          <h2>Curvas de referencia OMS</h2>
          <span class="badge badge-mute tiny mono">${state.input.sex === 'M' ? 'varones' : 'mujeres'}</span>
        </div>
        <div class="m2-curve-tabs" role="tablist">
          ${indicators.map(it => `
            <button class="m2-curve-tab ${it.key === activeKey ? 'is-active' : ''}"
                    data-curve="${it.key}" role="tab"
                    aria-selected="${it.key === activeKey ? 'true' : 'false'}">
              ${esc(it.label)}
            </button>
          `).join('')}
        </div>
        <div class="m2-curve-content" id="m2-curve-svg-wrap">
          ${renderCurveSVG(activeKey, age)}
        </div>
      </div>
    `;
  }

  function renderCurveSVG(indicatorKey, age) {
    const it = applicableIndicators(age).find(i => i.key === indicatorKey);
    if (!it) return '';
    const tab = state.db[indicatorKey]?.[state.input.sex];
    if (!tab) return '';

    let xVal, yVal;
    if (indicatorKey === 'wfl' || indicatorKey === 'wfh') {
      xVal = state.input.height;
      yVal = state.input.weight;
    } else if (indicatorKey === 'hcfa') {
      xVal = age.totalMonths;
      yVal = state.input.hc;
    } else if (indicatorKey === 'lhfa') {
      xVal = age.totalMonths;
      yVal = state.input.height;
    } else if (indicatorKey === 'wfa') {
      xVal = age.totalMonths;
      yVal = state.input.weight;
    } else if (indicatorKey === 'bmifa') {
      xVal = age.totalMonths;
      yVal = bmi(state.input.weight, state.input.height);
    }

    // 5 líneas SD
    const SD_LINES = [
      { z: -3, color: '#B0413E', dash: '3,3', label: '-3 SD' },
      { z: -2, color: '#C9893E', dash: '4,2', label: '-2 SD' },
      { z:  0, color: '#1F5F4A', dash: '',    label: 'Mediana' },
      { z:  2, color: '#C9893E', dash: '4,2', label: '+2 SD' },
      { z:  3, color: '#B0413E', dash: '3,3', label: '+3 SD' },
    ];

    // Bounds
    const xs = tab.map(r => r.x);
    const xMin = Math.min(...xs), xMax = Math.max(...xs);
    let yMin = Infinity, yMax = -Infinity;
    const curves = SD_LINES.map(line => {
      const points = tab.map(r => {
        const v = valueFromZ(line.z, r.L, r.M, r.S);
        if (v < yMin) yMin = v;
        if (v > yMax) yMax = v;
        return { x: r.x, y: v };
      });
      return { ...line, points };
    });
    yMin = Math.floor(yMin * 0.95);
    yMax = Math.ceil(yMax * 1.05);

    const W = 600, H = 360;
    const pad = { l: 50, r: 20, t: 20, b: 40 };
    const innerW = W - pad.l - pad.r;
    const innerH = H - pad.t - pad.b;
    const sx = x => pad.l + ((x - xMin) / (xMax - xMin)) * innerW;
    const sy = y => pad.t + (1 - (y - yMin) / (yMax - yMin)) * innerH;

    const pathFor = (pts) =>
      pts.map((p, i) => (i === 0 ? 'M' : 'L') + sx(p.x).toFixed(1) + ' ' + sy(p.y).toFixed(1)).join(' ');

    const xTicks = [];
    for (let i = 0; i <= 5; i++) {
      const v = xMin + (xMax - xMin) * i / 5;
      xTicks.push({ x: sx(v), v });
    }
    const yTicks = [];
    for (let i = 0; i <= 5; i++) {
      const v = yMin + (yMax - yMin) * i / 5;
      yTicks.push({ y: sy(v), v });
    }

    let patientDot = '';
    let patientLabel = '';
    if (xVal != null && yVal != null && xVal >= xMin && xVal <= xMax && yVal >= yMin && yVal <= yMax) {
      const px = sx(xVal), py = sy(yVal);
      patientDot = `
        <circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="8" fill="rgba(31,95,74,0.15)" />
        <circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="5" fill="#1F5F4A" stroke="white" stroke-width="2" />
      `;
      // Etiqueta con el valor del paciente
      const lblY = py < pad.t + 25 ? py + 22 : py - 12;
      patientLabel = `
        <rect x="${(px + 8).toFixed(1)}" y="${(lblY - 10).toFixed(1)}" width="56" height="18" rx="4" fill="white" stroke="#1F5F4A" stroke-width="1" opacity="0.95"/>
        <text x="${(px + 36).toFixed(1)}" y="${(lblY + 3).toFixed(1)}" font-size="10" text-anchor="middle" fill="#1F5F4A" font-weight="600">
          ${yVal.toFixed(1)} ${it.unit}
        </text>
      `;
    }

    const xLabel = (indicatorKey === 'wfl' || indicatorKey === 'wfh')
      ? `${it.xUnit || 'cm'}` : 'meses';

    return `
      <h3 class="m2-curve-h">${esc(it.label)}</h3>
      <svg viewBox="0 0 ${W} ${H}" class="m2-curve-svg" role="img" aria-label="Curva de referencia LMS ${esc(it.label)}">
        <rect x="${pad.l}" y="${pad.t}" width="${innerW}" height="${innerH}" fill="#FAF8F4" stroke="#D9D2C4" />
        ${yTicks.map(t => `<line x1="${pad.l}" y1="${t.y.toFixed(1)}" x2="${W - pad.r}" y2="${t.y.toFixed(1)}" stroke="#E8E2D4" stroke-width="0.5" />`).join('')}
        ${xTicks.map(t => `<line x1="${t.x.toFixed(1)}" y1="${pad.t}" x2="${t.x.toFixed(1)}" y2="${H - pad.b}" stroke="#E8E2D4" stroke-width="0.5" />`).join('')}
        ${curves.map(c => `<path d="${pathFor(c.points)}" fill="none" stroke="${c.color}" stroke-width="${c.z === 0 ? 2 : 1.3}" stroke-dasharray="${c.dash}" />`).join('')}
        ${patientDot}
        ${patientLabel}
        ${xTicks.map(t => `<text x="${t.x.toFixed(1)}" y="${H - pad.b + 15}" font-size="10" text-anchor="middle" fill="#5A6A63">${t.v.toFixed(0)}</text>`).join('')}
        ${yTicks.map(t => `<text x="${pad.l - 6}" y="${(t.y + 3).toFixed(1)}" font-size="10" text-anchor="end" fill="#5A6A63">${t.v.toFixed(1)}</text>`).join('')}
        <text x="${W/2}" y="${H - 5}" font-size="11" text-anchor="middle" fill="#0F1B17" font-weight="600">${esc(xLabel)}</text>
        <text x="15" y="${H/2}" font-size="11" text-anchor="middle" fill="#0F1B17" font-weight="600" transform="rotate(-90 15 ${H/2})">${esc(it.unit)}</text>
      </svg>
      <div class="m2-curve-legend">
        ${SD_LINES.map(l => `
          <span class="m2-leg-item">
            <span class="m2-leg-line" style="background:${l.color};${l.dash ? `background-image: linear-gradient(to right, ${l.color} 60%, transparent 60%); background-size: 6px 100%;` : ''}"></span>
            ${l.label}
          </span>
        `).join('')}
      </div>
    `;
  }

  // === Tarjeta de gasto energético ==========================================
  function renderEnergetics(age) {
    if (!age || !state.input.sex || !state.input.weight) {
      return '';
    }
    const isAdult = age.totalYears >= 18;
    let ger;
    let method;
    if (isAdult) {
      if (!state.input.height) return '';
      ger = gerMifflin(state.input.sex, state.input.weight, state.input.height, age.totalYears);
      method = 'Mifflin-St Jeor';
    } else {
      ger = gerSchofield(state.input.sex, state.input.weight, age.totalYears);
      method = `Schofield (${age.totalYears.toFixed(1)} años)`;
    }
    if (!ger) return '';
    const get = ger * state.input.pal;
    return `
      <div class="card mt-4 m2-energy">
        <div class="card-h">
          <h2>Gasto energético</h2>
          <span class="badge badge-mute tiny mono">${esc(method)}</span>
        </div>
        <div class="m2-energy-grid">
          <div class="m2-energy-cell">
            <span class="m2-energy-l">GER (basal)</span>
            <span class="m2-energy-v">${Math.round(ger).toLocaleString('es-BO')}<small>kcal/día</small></span>
          </div>
          <div class="m2-energy-cell m2-energy-main">
            <span class="m2-energy-l">GET (total)</span>
            <span class="m2-energy-v">${Math.round(get).toLocaleString('es-BO')}<small>kcal/día</small></span>
            <span class="tiny muted">GER × PAL ${state.input.pal}</span>
          </div>
          <div class="m2-energy-cell">
            <span class="m2-energy-l">Distribución sugerida</span>
            <div class="m2-energy-macros">
              <span><strong>${Math.round(get * 0.55 / 4)}g</strong> CHO (55%)</span>
              <span><strong>${Math.round(get * 0.30 / 9)}g</strong> Grasa (30%)</span>
              <span><strong>${Math.round(get * 0.15 / 4)}g</strong> Prot (15%)</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // === Renderizado completo de resultados ===================================
  function renderResults() {
    const out = document.getElementById('m2-results');
    if (!out) return;

    const age = calcAge(state.input.dob);
    const b = bmi(state.input.weight, state.input.height);
    const bClass = bmiClass(b);

    let html = renderSummary(age, b, bClass);

    if (age && state.input.sex) {
      html += renderZTable(age);
      html += renderEnergetics(age);
      // Curvas con pestañas: muestra el indicador activo, los demás se cambian con click
      html += renderCurvesWithTabs(age, state.activeCurve);
    } else {
      html += `<div class="empty-state mt-4"><p class="muted small">Completa sexo y fecha de nacimiento para ver z-scores y energía.</p></div>`;
    }
    out.innerHTML = html;

    // Bind: click en pestaña de curva
    out.querySelectorAll('.m2-curve-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        state.activeCurve = btn.dataset.curve;
        // Re-render solo del bloque de curvas (más eficiente)
        renderResults();
      });
    });

    // Bind: click en fila de Z-score → cambiar a su pestaña
    out.querySelectorAll('.m2-z-row[data-indicator]').forEach(row => {
      row.addEventListener('click', () => {
        out.querySelectorAll('.m2-z-row').forEach(r => r.classList.remove('is-selected'));
        row.classList.add('is-selected');
        state.activeCurve = row.dataset.indicator;
        renderResults();
      });
    });
  }

  // === Bind del formulario ===================================================
  function bindForm() {
    const inputs = {
      sex: document.getElementById('m2-sex'),
      dob: document.getElementById('m2-dob'),
      w:   document.getElementById('m2-w'),
      h:   document.getElementById('m2-h'),
      hc:  document.getElementById('m2-hc'),
      pal: document.getElementById('m2-pal'),
    };
    const update = () => {
      state.input.sex = inputs.sex.value;
      state.input.dob = inputs.dob.value;
      state.input.weight = parseFloat(inputs.w.value) || null;
      state.input.height = parseFloat(inputs.h.value) || null;
      state.input.hc = parseFloat(inputs.hc.value) || null;
      state.input.pal = parseFloat(inputs.pal.value) || 1.2;
      renderResults();
    };
    Object.values(inputs).forEach(el => {
      if (el) {
        el.addEventListener('input', update);
        el.addEventListener('change', update);
      }
    });
    // Botón limpiar
    document.getElementById('m2-clear')?.addEventListener('click', () => {
      ['sex', 'dob', 'w', 'h', 'hc'].forEach(k => { if (inputs[k]) inputs[k].value = ''; });
      update();
    });
  }

  // === Entry point ==========================================================
  window.render_nutricion = function (panel) {
    state.db = window.DB_LMS;
    if (!state.db) {
      panel.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-title">Cargando tablas OMS...</div>
        </div>`;
      // Cargar perezosamente
      window.State.loadScript('data/db_lms.js').then(() => {
        state.db = window.DB_LMS;
        window.render_nutricion(panel);
      }).catch(() => {
        panel.innerHTML = '<div class="empty-state">Error cargando tablas LMS</div>';
      });
      return;
    }

    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Valoración Nutricional</h1>
          <p class="muted small">Z-scores OMS · ${state.db.lhfa.M.length + state.db.lhfa.F.length} puntos LMS · GER Schofield / Mifflin-St Jeor</p>
        </div>
      </div>
      <div class="m2-layout">
        <div class="m2-input-col">
          ${renderForm()}
        </div>
        <div class="m2-output-col" id="m2-results"></div>
      </div>
    `;
    bindForm();
    renderResults();
  };
})();
