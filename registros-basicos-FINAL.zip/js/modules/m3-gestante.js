/* ============================================================================
   m3-gestante.js — Módulo 3: Nutrición en la Gestante y Edad Gestacional
   - Cálculo de EG bidireccional FUM ↔ SG ↔ FPP
   - Reglas: Naegele, Parikh, Wahl
   - Extrapolación desde ecografía
   - Tabla de ganancia de peso según IMC pregestacional (IOM 2009)
   - Clasificación de altura uterina vs percentilos CLAP/OPS
   ============================================================================ */
(function () {
  'use strict';

  const state = {
    fum: null,
    fpp: null,
    cicloDias: 28,
    fechaControl: null,    // fecha del control prenatal (default = hoy)
    ecoFecha: null,
    ecoSG: null,
    fppEco: null,          // FPP declarada directamente por ecografía
    pesoPre: null,        // peso pregestacional (kg)
    pesoActual: null,
    talla: null,           // cm
    altUterina: null,      // cm
    embarazoMultiple: false,
  };

  // === Utilidades ===========================================================
  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }
  function fmtDate(d) {
    if (!d) return '—';
    return d.toLocaleDateString('es-BO', { day: '2-digit', month: 'long', year: 'numeric', timeZone: 'UTC' });
  }
  function fmtShort(d) {
    if (!d) return '—';
    return d.toLocaleDateString('es-BO', { day: '2-digit', month: '2-digit', year: '2-digit', timeZone: 'UTC' });
  }
  function bmi(weight, heightCm) {
    if (!weight || !heightCm) return null;
    const m = heightCm / 100;
    return weight / (m * m);
  }

  // === Render del formulario ================================================
  function renderForm() {
    return `
      <div class="card m3-form">
        <div class="card-h"><h2>Datos clínicos</h2></div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Fecha y ciclo menstrual</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">FUM (último período)</span>
              <input type="date" class="field-input" id="m3-fum" />
            </label>
            <label class="field">
              <span class="field-label">Ciclo (días)</span>
              <input type="number" class="field-input" id="m3-ciclo" min="20" max="45" value="28" />
            </label>
            <label class="field">
              <span class="field-label">Fecha del control</span>
              <input type="date" class="field-input" id="m3-fecha-control" />
              <span class="tiny muted">Por defecto hoy. Modifícala si reconstruyes un control pasado.</span>
            </label>
          </div>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Datación ecográfica (opcional)</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Fecha de ecografía</span>
              <input type="date" class="field-input" id="m3-eco-fecha" />
            </label>
            <label class="field">
              <span class="field-label">SG por ecografía (semanas)</span>
              <input type="number" class="field-input" id="m3-eco-sg" min="4" max="42" step="0.1" placeholder="ej. 12.4" />
            </label>
            <label class="field">
              <span class="field-label">FPP por ecografía (directa)</span>
              <input type="date" class="field-input" id="m3-fpp-eco" />
              <span class="tiny muted">Si el informe ecográfico ya trae la FPP, ingrésala aquí.</span>
            </label>
          </div>
          <p class="tiny muted mt-2">Puedes usar cualquiera de las dos vías ecográficas (o ambas). Se compararán contra la FUM declarada.</p>
        </div>

        <div class="m3-section">
          <h3 class="m3-sec-h">Antropometría</h3>
          <div class="m2-form-grid">
            <label class="field">
              <span class="field-label">Peso pregestacional (kg)</span>
              <input type="number" class="field-input" id="m3-w-pre" min="0" step="0.1" placeholder="ej. 60" />
            </label>
            <label class="field">
              <span class="field-label">Peso actual (kg)</span>
              <input type="number" class="field-input" id="m3-w" min="0" step="0.1" placeholder="ej. 65" />
            </label>
            <label class="field">
              <span class="field-label">Talla (cm)</span>
              <input type="number" class="field-input" id="m3-h" min="0" step="0.1" placeholder="ej. 160" />
            </label>
            <label class="field">
              <span class="field-label">Altura uterina (cm)</span>
              <input type="number" class="field-input" id="m3-au" min="0" max="50" step="0.5" placeholder="opcional" />
            </label>
          </div>
        </div>

        <div class="m3-section">
          <label class="m3-checkbox">
            <input type="checkbox" id="m3-multiple" />
            <span>Embarazo múltiple (gemelos o más)</span>
          </label>
        </div>

        <div class="m2-form-actions">
          <button class="btn btn-ghost" id="m3-clear">Limpiar</button>
        </div>
      </div>
    `;
  }

  // === Bloque EG / FPP =======================================================
  function renderEGBlock() {
    const O = window.Obstetric;
    if (!state.fum) {
      return `<div class="empty-state"><p class="muted small">Ingresa la FUM para calcular edad gestacional.</p></div>`;
    }
    // Fecha de referencia: la del control si fue ingresada; si no, hoy
    const refDate = state.fechaControl || O.todayUTC();
    const esHoy   = !state.fechaControl
                 || O.dateToISO(state.fechaControl) === O.dateToISO(O.todayUTC());

    // Cálculos existentes — NO se modifican
    const eg   = O.calcEG(state.fum, refDate);
    const fppN = O.fppNaegele(state.fum);
    const fppP = O.fppParikh(state.fum, state.cicloDias);
    const fppW = O.fppWahl(state.fum);

    // Ecografía vía SG (camino existente)
    let egEco = null;
    let fppEcoEstim = null;       // FPP derivada de fecha-eco + SG
    let fumEcoEstim = null;
    if (state.ecoFecha && state.ecoSG) {
      fumEcoEstim = O.fumFromEcoSG(state.ecoSG, state.ecoFecha);
      egEco = O.calcEG(fumEcoEstim, refDate);
      fppEcoEstim = O.fppNaegele(fumEcoEstim);
    }
    // Ecografía vía FPP directa (camino nuevo)
    let fumDesdeFppEco = null;
    if (state.fppEco) {
      fumDesdeFppEco = O.addDays(state.fppEco, -O.GESTATION_DAYS);
    }

    // Diferencia en días contra Naegele (referencia base)
    const diffDays = (a, b) => (!a || !b) ? null : O.diffDays(a, b);
    const fmtDiff = (n) => {
      if (n === null || n === undefined) return '';
      if (n === 0) return '(= Naegele)';
      const sign = n > 0 ? '+' : '';
      return `(${sign}${n} d vs Naegele)`;
    };
    const tierForDiff = (n) => {
      if (n === null || n === undefined) return '';
      const abs = Math.abs(n);
      if (abs > 7) return 'badge-rose';   // >1 semana → considerar redatación
      if (abs > 3) return 'badge-ochre';  // 3-7 días → tolerable
      return 'badge-clinic';
    };

    return `
      <div class="card mt-4 m3-eg-card">
        <div class="card-h">
          <h2>Edad gestacional y FPP</h2>
        </div>
        <div class="m3-eg-current">
          <span class="m3-eg-big">${eg.weeks}<span class="m3-eg-unit">sem</span> ${eg.days}<span class="m3-eg-unit">d</span></span>
          <span class="muted small">
            desde FUM ${fmtShort(state.fum)} · ${esHoy ? 'hoy' : 'al ' + fmtShort(refDate)}
          </span>
        </div>

        <div class="m3-fpp-grid">
          <div class="m3-fpp-cell">
            <span class="m3-fpp-l">Naegele (FUM + 280d)</span>
            <span class="m3-fpp-v">${fmtDate(fppN)}</span>
          </div>
          <div class="m3-fpp-cell ${state.cicloDias !== 28 ? 'is-highlight' : ''}">
            <span class="m3-fpp-l">Parikh (ciclo ${state.cicloDias}d)</span>
            <span class="m3-fpp-v">${fmtDate(fppP)}</span>
          </div>
          <div class="m3-fpp-cell">
            <span class="m3-fpp-l">Wahl (10d + 9m)</span>
            <span class="m3-fpp-v">${fmtDate(fppW)}</span>
          </div>
        </div>

        ${egEco ? `
          <div class="m3-eco-compare">
            <strong>EG ecográfica (vía SG):</strong> ${egEco.weeks} sem ${egEco.days} d
            (∆ ${(egEco.fraction - eg.fraction).toFixed(1)} sem respecto a FUM)
            · FPP ecográfica: ${fmtShort(fppEcoEstim)}
            ${Math.abs(egEco.fraction - eg.fraction) > 1
              ? '<span class="badge badge-ochre">Discrepancia &gt; 7 días — considerar redatación</span>'
              : ''}
          </div>
        ` : ''}

        <!-- Tabla comparativa de FPPs (nueva) -->
        <div class="m3-fpp-tabla">
          <div class="m3-fpp-tabla-h">
            <strong>Comparación de fechas probables de parto</strong>
            <span class="tiny muted">tomando Naegele como referencia</span>
          </div>
          <table class="m3-fpp-comp">
            <thead>
              <tr>
                <th>Método</th>
                <th>FPP</th>
                <th>Diferencia</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Naegele <span class="tiny muted">(base)</span></td>
                <td class="mono">${fmtShort(fppN)}</td>
                <td><span class="badge badge-clinic">referencia</span></td>
              </tr>
              <tr ${state.cicloDias !== 28 ? 'class="is-highlight"' : ''}>
                <td>Parikh <span class="tiny muted">(ciclo ${state.cicloDias} d)</span></td>
                <td class="mono">${fmtShort(fppP)}</td>
                <td>
                  ${(() => {
                    const d = diffDays(fppP, fppN);
                    return `<span class="badge ${tierForDiff(d)}">${fmtDiff(d)}</span>`;
                  })()}
                </td>
              </tr>
              <tr>
                <td>Wahl</td>
                <td class="mono">${fmtShort(fppW)}</td>
                <td>
                  ${(() => {
                    const d = diffDays(fppW, fppN);
                    return `<span class="badge ${tierForDiff(d)}">${fmtDiff(d)}</span>`;
                  })()}
                </td>
              </tr>
              ${fppEcoEstim ? `
                <tr>
                  <td>Eco — vía SG <span class="tiny muted">(${state.ecoSG} sem @ ${fmtShort(state.ecoFecha)})</span></td>
                  <td class="mono">${fmtShort(fppEcoEstim)}</td>
                  <td>
                    ${(() => {
                      const d = diffDays(fppEcoEstim, fppN);
                      return `<span class="badge ${tierForDiff(d)}">${fmtDiff(d)}</span>`;
                    })()}
                  </td>
                </tr>
              ` : ''}
              ${state.fppEco ? `
                <tr>
                  <td>Eco — FPP directa <span class="tiny muted">(del informe)</span></td>
                  <td class="mono">${fmtShort(state.fppEco)}</td>
                  <td>
                    ${(() => {
                      const d = diffDays(state.fppEco, fppN);
                      return `<span class="badge ${tierForDiff(d)}">${fmtDiff(d)}</span>`;
                    })()}
                  </td>
                </tr>
              ` : ''}
            </tbody>
          </table>
          ${fumDesdeFppEco ? `
            <div class="m3-fpp-tabla-nota">
              <strong>FUM derivada de la FPP ecográfica:</strong>
              <span class="mono">${fmtShort(fumDesdeFppEco)}</span>
              ${(() => {
                const d = O.diffDays(fumDesdeFppEco, state.fum);
                if (d === 0) return '<span class="badge badge-clinic">= FUM declarada</span>';
                const sign = d > 0 ? '+' : '';
                const abs = Math.abs(d);
                const tier = abs > 7 ? 'badge-rose' : abs > 3 ? 'badge-ochre' : 'badge-clinic';
                return `<span class="badge ${tier}">${sign}${d} d vs FUM declarada</span>
                        ${abs > 7 ? '<span class="tiny muted">— considerar redatación con eco temprana</span>' : ''}`;
              })()}
            </div>
          ` : ''}
        </div>

        <div class="m3-trimestre">
          ${trimestreLabel(eg.weeks)}
        </div>
      </div>
    `;
  }

  function trimestreLabel(weeks) {
    if (weeks < 14) return '<span class="badge badge-clinic">1er trimestre</span>';
    if (weeks < 28) return '<span class="badge badge-clinic">2do trimestre</span>';
    if (weeks < 37) return '<span class="badge badge-ochre">3er trimestre</span>';
    if (weeks < 42) return '<span class="badge badge-clinic">A término</span>';
    return '<span class="badge badge-rose">Postérmino</span>';
  }

  // === Ganancia de peso ======================================================
  function renderGananciaBlock() {
    const O = window.Obstetric;
    if (!state.pesoPre || !state.talla) {
      return `
        <div class="card mt-4">
          <div class="card-h"><h2>Ganancia de peso</h2></div>
          <p class="muted small">Ingresa peso pregestacional y talla para calcular IMC y rango esperado.</p>
        </div>
      `;
    }
    const imcPre = bmi(state.pesoPre, state.talla);
    const tallaBaja = state.talla < 157;
    const rec = O.gananciaSegunIMC(imcPre, state.embarazoMultiple, tallaBaja);
    if (!rec) return '';

    const gananciaActual = state.pesoActual ? state.pesoActual - state.pesoPre : null;
    let estado = '';
    if (gananciaActual != null) {
      const refDate = state.fechaControl || O.todayUTC();
      const eg = state.fum ? O.calcEG(state.fum, refDate) : null;
      const w = eg ? eg.weeks : null;
      // Estimación de rango esperado a esa semana
      // 1er trim (hasta sem 13): ganancia mínima
      // 2do-3er trim: gana ~rate/sem desde sem 13
      let espMin = 0, espMax = 0;
      if (w !== null && w >= 13) {
        const semsEnt13 = w - 13;
        const rangoT1 = rec.cat.label.includes('Bajo peso') ? [0, 2.5]
                     : rec.cat.label.includes('Sobrepeso') ? [0, 1.5]
                     : rec.cat.label.includes('Obesidad') ? [0, 1.0]
                     : [0.5, 2.0];
        const ratePerWeek = (rec.rango.max - rangoT1[1]) / 27;  // semanas 13 a 40 = 27
        const rateMin = (rec.rango.min - rangoT1[0]) / 27;
        espMin = rangoT1[0] + semsEnt13 * rateMin;
        espMax = rangoT1[1] + semsEnt13 * ratePerWeek;
      } else if (w !== null && w < 13) {
        espMin = 0;
        espMax = rec.cat.label.includes('Bajo peso') ? 2.5
              : rec.cat.label.includes('Sobrepeso') ? 1.5
              : rec.cat.label.includes('Obesidad') ? 1.0
              : 2.0;
      }
      if (espMax > 0) {
        const ok = gananciaActual >= espMin && gananciaActual <= espMax;
        const bajo = gananciaActual < espMin;
        const tier = ok ? 'clinic' : bajo ? 'ochre' : 'rose';
        const lbl = ok ? 'Dentro del rango esperado' : bajo ? 'Ganancia insuficiente' : 'Ganancia excesiva';
        estado = `
          <div class="m3-gan-eval badge badge-${tier}">
            ${lbl} (${gananciaActual >= 0 ? '+' : ''}${gananciaActual.toFixed(1)} kg)
            · esperado a sem ${w}: ${espMin.toFixed(1)} a ${espMax.toFixed(1)} kg
          </div>
        `;
      }
    }

    return `
      <div class="card mt-4 m3-gan-card">
        <div class="card-h">
          <h2>Ganancia de peso recomendada</h2>
          <span class="badge badge-mute tiny mono">IOM 2009</span>
        </div>

        <div class="m3-gan-summary">
          <div class="m3-gan-cell">
            <span class="m3-gan-l">IMC pregestacional</span>
            <span class="m3-gan-v">${imcPre.toFixed(1)}</span>
            <span class="badge badge-${rec.cat.tier === 'ok' ? 'clinic' : rec.cat.tier === 'warn' ? 'ochre' : 'rose'}">${esc(rec.cat.label)}</span>
          </div>
          <div class="m3-gan-cell">
            <span class="m3-gan-l">Ganancia total esperada</span>
            <span class="m3-gan-v">${rec.rango.min.toFixed(1)} – ${rec.rango.max.toFixed(1)} kg</span>
            ${state.embarazoMultiple ? '<span class="tiny muted">Ajustado para gemelos</span>' : ''}
            ${tallaBaja ? '<span class="tiny muted">Ajuste talla baja (&lt;1.57m)</span>' : ''}
          </div>
          ${gananciaActual != null ? `
            <div class="m3-gan-cell">
              <span class="m3-gan-l">Ganancia hasta hoy</span>
              <span class="m3-gan-v">${gananciaActual >= 0 ? '+' : ''}${gananciaActual.toFixed(1)} kg</span>
            </div>
          ` : ''}
        </div>

        ${estado}
      </div>
    `;
  }

  // === Gráficas de las 3 tablas IOM 2009 ====================================
  // Muestra las barras de rango esperado para las 4 categorías IMC en 3 escenarios:
  //   embarazo único, embarazo múltiple, talla baja (<1.57m, embarazo único)
  function renderIOMTablesBlock() {
    const O = window.Obstetric;
    // Datos directos (reflejan las imágenes oficiales IOM 2009)
    const datos = {
      unico: {
        titulo: 'Embarazo único',
        bg: 'var(--clinic-bg)',
        rangos: [
          { lbl: 'Delgadez',  imc: '< 18.5',     min: 12.5, max: 18.0, color: 'var(--ochre)' },
          { lbl: 'Normal',    imc: '18.5–24.9',  min: 11.5, max: 16.0, color: 'var(--clinic)' },
          { lbl: 'Sobrepeso', imc: '25.0–29.9',  min:  7.0, max: 11.5, color: 'var(--ochre)' },
          { lbl: 'Obesidad',  imc: '≥ 30.0',     min:  5.0, max:  9.0, color: 'var(--rose)' },
        ],
      },
      multiple: {
        titulo: 'Embarazo múltiple (mellizos)',
        bg: 'var(--brand-bg)',
        rangos: [
          { lbl: 'Delgadez',  imc: '< 18.5',     min: null, max: null, color: 'var(--ink-mute)', nota: 'Según especialista' },
          { lbl: 'Normal',    imc: '18.5–24.9',  min: 17.0, max: 25.0, color: 'var(--clinic)' },
          { lbl: 'Sobrepeso', imc: '25.0–29.9',  min: 14.0, max: 23.0, color: 'var(--ochre)' },
          { lbl: 'Obesidad',  imc: '≥ 30.0',     min: 11.0, max: 19.0, color: 'var(--rose)' },
        ],
        nota: 'Trillizos: ganancia total 22.5 kg',
      },
      tallaBaja: {
        titulo: 'Talla < 1.57 m (embarazo único)',
        bg: 'var(--ochre-bg)',
        rangos: [
          { lbl: 'Delgadez',  imc: '< 18.5',     min: null, max: 12.5, color: 'var(--ochre)', singleVal: true },
          { lbl: 'Normal',    imc: '18.5–24.9',  min: null, max: 11.5, color: 'var(--clinic)', singleVal: true },
          { lbl: 'Sobrepeso', imc: '25.0–29.9',  min: null, max:  7.0, color: 'var(--ochre)', singleVal: true },
          { lbl: 'Obesidad',  imc: '≥ 30.0',     min: null, max:  5.0, color: 'var(--rose)', singleVal: true },
        ],
      },
    };

    // IMC pregestacional actual (para resaltar la fila)
    const imcPre = (state.pesoPre && state.talla) ? bmi(state.pesoPre, state.talla) : null;
    const categoriaActual = imcPre
      ? (imcPre < 18.5 ? 'Delgadez' : imcPre < 25 ? 'Normal' : imcPre < 30 ? 'Sobrepeso' : 'Obesidad')
      : null;
    const escenarioActual = state.embarazoMultiple ? 'multiple'
                          : (state.talla && state.talla < 157) ? 'tallaBaja' : 'unico';

    // Escala max (kg) común para las 3 barras → 30 kg cubre todos los casos
    const SCALE_MAX = 30;

    function barSvg(rango, isHighlight) {
      const W = 320, H = 32;
      const padL = 4, padR = 30;
      const innerW = W - padL - padR;
      const x = (kg) => padL + (kg / SCALE_MAX) * innerW;
      const tickKg = [0, 5, 10, 15, 20, 25, 30];
      if (rango.min == null && rango.max == null) {
        return `<svg viewBox="0 0 ${W} ${H}" class="m3-iom-bar">
          <line x1="${padL}" y1="${H/2}" x2="${W-padR}" y2="${H/2}" stroke="#D9D2C4" stroke-dasharray="3,3"/>
          <text x="${W/2}" y="${H/2+4}" text-anchor="middle" font-size="11" fill="#5A6A63">${esc(rango.nota || 'No definido')}</text>
        </svg>`;
      }
      const xMin = rango.singleVal ? padL : x(rango.min);
      const xMax = x(rango.max);
      return `<svg viewBox="0 0 ${W} ${H}" class="m3-iom-bar">
        <!-- Ejes / ticks -->
        <line x1="${padL}" y1="${H-8}" x2="${W-padR}" y2="${H-8}" stroke="#D9D2C4"/>
        ${tickKg.map(k => `
          <line x1="${x(k).toFixed(1)}" y1="${H-10}" x2="${x(k).toFixed(1)}" y2="${H-6}" stroke="#D9D2C4"/>
          <text x="${x(k).toFixed(1)}" y="${H-1}" font-size="8" text-anchor="middle" fill="#5A6A63">${k}</text>
        `).join('')}
        <!-- Barra de rango -->
        ${rango.singleVal
          ? `<line x1="${x(rango.max).toFixed(1)}" y1="${H/2-2}" x2="${x(rango.max).toFixed(1)}" y2="${H/2+8}" stroke="${rango.color}" stroke-width="3"/>
             <circle cx="${x(rango.max).toFixed(1)}" cy="${H/2+3}" r="4" fill="${rango.color}"/>
             <text x="${(x(rango.max)+8).toFixed(1)}" y="${H/2+6}" font-size="10" fill="${rango.color}" font-weight="600">${rango.max} kg</text>`
          : `<rect x="${xMin.toFixed(1)}" y="${H/2-4}" width="${(xMax-xMin).toFixed(1)}" height="14" fill="${rango.color}" opacity="${isHighlight ? '1' : '0.65'}" rx="2"/>
             <text x="${(xMin+2).toFixed(1)}" y="${H/2+6}" font-size="9" fill="white" font-weight="600">${rango.min}</text>
             <text x="${(xMax-2).toFixed(1)}" y="${H/2+6}" font-size="9" text-anchor="end" fill="white" font-weight="600">${rango.max}</text>`}
      </svg>`;
    }

    const renderTable = (key, data) => {
      const isActive = (escenarioActual === key);
      return `
        <div class="m3-iom-card ${isActive ? 'is-active' : ''}" style="background:${data.bg};">
          <div class="m3-iom-h">
            <strong>${esc(data.titulo)}</strong>
            ${isActive ? '<span class="badge badge-clinic tiny">Aplica a esta gestante</span>' : ''}
          </div>
          <table class="m3-iom-table">
            <thead>
              <tr>
                <th>Categoría</th><th>IMC PG</th>
                <th>Ganancia esperada (kg)</th>
              </tr>
            </thead>
            <tbody>
              ${data.rangos.map(r => {
                const highlight = isActive && categoriaActual === r.lbl;
                return `
                  <tr class="${highlight ? 'is-highlight' : ''}">
                    <td><span class="m3-iom-cat-dot" style="background:${r.color}"></span> ${esc(r.lbl)}${highlight ? ' ★' : ''}</td>
                    <td class="mono tiny">${esc(r.imc)}</td>
                    <td>${barSvg(r, highlight)}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
          ${data.nota ? `<p class="tiny muted mt-2">${esc(data.nota)}</p>` : ''}
        </div>
      `;
    };

    return `
      <div class="card mt-4">
        <div class="card-h">
          <h2>Tablas IOM 2009 — ganancia esperada</h2>
          <span class="badge badge-mute tiny mono">Institute of Medicine</span>
        </div>
        <p class="small muted mb-3">Rangos recomendados de ganancia de peso total según IMC pregestacional, por escenario:</p>
        <div class="m3-iom-grid">
          ${renderTable('unico', datos.unico)}
          ${renderTable('multiple', datos.multiple)}
          ${renderTable('tallaBaja', datos.tallaBaja)}
        </div>
      </div>
    `;
  }

  // === Altura uterina vs percentilos (con gráfica de líneas) =================
  function renderAUBlock() {
    const O = window.Obstetric;
    // Tabla CLAP completa (semanas 13-40)
    const ref = O.AU_REFERENCE;
    const weeks = Object.keys(ref).map(Number).sort((a, b) => a - b);
    const auMeasured = state.altUterina;
    const refDate = state.fechaControl || O.todayUTC();
    const egCurrent = state.fum ? O.calcEG(state.fum, refDate) : null;
    const semanaActual = egCurrent ? egCurrent.fraction : null;

    // Bounds del gráfico
    const W = 640, H = 320;
    const pad = { l: 40, r: 20, t: 20, b: 40 };
    const innerW = W - pad.l - pad.r;
    const innerH = H - pad.t - pad.b;
    const wMin = 13, wMax = 40;
    const auMin = 0, auMax = 40;
    const sx = w => pad.l + ((w - wMin) / (wMax - wMin)) * innerW;
    const sy = au => pad.t + (1 - (au - auMin) / (auMax - auMin)) * innerH;

    // Líneas p10, p50, p90
    const p10 = weeks.map(w => ({ x: w, y: ref[w].p10 }));
    const p50 = weeks.map(w => ({ x: w, y: ref[w].p50 }));
    const p90 = weeks.map(w => ({ x: w, y: ref[w].p90 }));
    const pathFor = pts => pts.map((p, i) => (i === 0 ? 'M' : 'L') + sx(p.x).toFixed(1) + ' ' + sy(p.y).toFixed(1)).join(' ');
    // Zona p10-p90 sombreada
    const zonePath = pathFor(p10) + ' L' + sx(p90[p90.length-1].x).toFixed(1) + ' ' + sy(p90[p90.length-1].y).toFixed(1)
                    + ' ' + p90.slice().reverse().map((p, i) => 'L' + sx(p.x).toFixed(1) + ' ' + sy(p.y).toFixed(1)).join(' ') + ' Z';

    // Punto del paciente
    let patientDot = '';
    let evalText = '';
    if (auMeasured != null && semanaActual != null && semanaActual >= 13 && semanaActual <= 40) {
      const px = sx(semanaActual);
      const py = sy(auMeasured);
      const cls = O.clasifAlturaUterina(semanaActual, auMeasured);
      const dotColor = cls?.tier === 'ok' ? '#1F5F4A' : cls?.tier === 'warn' ? '#C9893E' : '#B0413E';
      patientDot = `
        <circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="9" fill="${dotColor}" opacity="0.18"/>
        <circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="5" fill="${dotColor}" stroke="white" stroke-width="2"/>
      `;
      if (cls) {
        const tier = cls.tier === 'ok' ? 'clinic' : cls.tier === 'warn' ? 'ochre' : 'rose';
        evalText = `
          <div class="m3-au-eval">
            <span class="badge badge-${tier}">${esc(cls.label)}</span>
            <span class="tiny muted">a las ${egCurrent.weeks}sem ${egCurrent.days}d · medida ${auMeasured} cm · referencia p10–p90: ${cls.ref.p10}–${cls.ref.p90} cm (mediana ${cls.ref.p50})</span>
          </div>
        `;
      }
    }

    // Ticks
    const xTicks = [];
    for (let w = 13; w <= 40; w += (40 - 13 > 14 ? 3 : 2)) {
      xTicks.push({ x: sx(w), v: w });
    }
    const yTicks = [];
    for (let au = 0; au <= 40; au += 5) {
      yTicks.push({ y: sy(au), v: au });
    }

    return `
      <div class="card mt-4">
        <div class="card-h">
          <h2>Altura uterina — Curva CLAP/OPS</h2>
          <span class="badge badge-mute tiny mono">Fescina-Belizán</span>
        </div>
        ${evalText}
        <svg viewBox="0 0 ${W} ${H}" class="m3-au-svg" role="img" aria-label="Curva de altura uterina por edad gestacional">
          <rect x="${pad.l}" y="${pad.t}" width="${innerW}" height="${innerH}" fill="#FAF8F4" stroke="#D9D2C4"/>
          <!-- Grid -->
          ${yTicks.map(t => `<line x1="${pad.l}" y1="${t.y.toFixed(1)}" x2="${W-pad.r}" y2="${t.y.toFixed(1)}" stroke="#E8E2D4" stroke-width="0.5"/>`).join('')}
          ${xTicks.map(t => `<line x1="${t.x.toFixed(1)}" y1="${pad.t}" x2="${t.x.toFixed(1)}" y2="${H-pad.b}" stroke="#E8E2D4" stroke-width="0.5"/>`).join('')}
          <!-- Zona p10-p90 sombreada -->
          <path d="${zonePath}" fill="#1F5F4A" opacity="0.08"/>
          <!-- Curvas -->
          <path d="${pathFor(p10)}" fill="none" stroke="#C9893E" stroke-width="1.5" stroke-dasharray="4,3"/>
          <path d="${pathFor(p50)}" fill="none" stroke="#1F5F4A" stroke-width="2.2"/>
          <path d="${pathFor(p90)}" fill="none" stroke="#C9893E" stroke-width="1.5" stroke-dasharray="4,3"/>
          <!-- Punto paciente -->
          ${patientDot}
          <!-- Etiquetas curvas -->
          <text x="${sx(40).toFixed(1)}" y="${(sy(ref[40].p90) - 4).toFixed(1)}" font-size="10" fill="#C9893E" font-weight="600">p90</text>
          <text x="${sx(40).toFixed(1)}" y="${(sy(ref[40].p50) - 4).toFixed(1)}" font-size="10" fill="#1F5F4A" font-weight="600">p50</text>
          <text x="${sx(40).toFixed(1)}" y="${(sy(ref[40].p10) + 12).toFixed(1)}" font-size="10" fill="#C9893E" font-weight="600">p10</text>
          <!-- Ejes -->
          ${xTicks.map(t => `<text x="${t.x.toFixed(1)}" y="${H-pad.b+15}" font-size="10" text-anchor="middle" fill="#5A6A63">${t.v}</text>`).join('')}
          ${yTicks.map(t => `<text x="${pad.l-6}" y="${(t.y+3).toFixed(1)}" font-size="10" text-anchor="end" fill="#5A6A63">${t.v}</text>`).join('')}
          <text x="${W/2}" y="${H-5}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17">semanas de gestación</text>
          <text x="14" y="${H/2}" font-size="11" text-anchor="middle" font-weight="600" fill="#0F1B17" transform="rotate(-90 14 ${H/2})">altura uterina (cm)</text>
        </svg>
        <p class="tiny muted mt-2">Curva oficial CLAP/OPS (Fescina &amp; cols., 2011). Los percentilos 10 y 90 marcan los límites de la normalidad.</p>
        ${!auMeasured || !egCurrent || egCurrent.weeks < 13
          ? `<p class="tiny muted">Ingresa FUM y altura uterina (a partir de la semana 13) para ubicar el punto del paciente sobre la curva.</p>`
          : ''}
      </div>
    `;
  }

  // === Render completo de resultados =========================================
  function renderResults() {
    const out = document.getElementById('m3-results');
    if (!out) return;
    out.innerHTML = `
      ${renderEGBlock()}
      ${renderGananciaBlock()}
      ${renderIOMTablesBlock()}
      ${renderAUBlock()}
    `;
  }

  // === Bind del formulario ==================================================
  function bindForm() {
    const $ = id => document.getElementById(id);
    const O = window.Obstetric;
    const inputs = {
      fum:        $('m3-fum'),
      ciclo:      $('m3-ciclo'),
      fechaCtrl:  $('m3-fecha-control'),
      ecoF:       $('m3-eco-fecha'),
      ecoSG:      $('m3-eco-sg'),
      fppEco:     $('m3-fpp-eco'),
      wPre:       $('m3-w-pre'),
      w:          $('m3-w'),
      h:          $('m3-h'),
      au:         $('m3-au'),
      mult:       $('m3-multiple'),
    };

    // Inicializar fechaControl con hoy
    if (inputs.fechaCtrl && !inputs.fechaCtrl.value) {
      inputs.fechaCtrl.value = O.dateToISO(O.todayUTC());
      state.fechaControl = O.todayUTC();
    }

    const update = () => {
      state.fum = O.isoToDate(inputs.fum.value);
      state.cicloDias = parseInt(inputs.ciclo.value) || 28;
      state.fechaControl = O.isoToDate(inputs.fechaCtrl.value) || O.todayUTC();
      state.ecoFecha = O.isoToDate(inputs.ecoF.value);
      state.ecoSG = parseFloat(inputs.ecoSG.value) || null;
      state.fppEco = O.isoToDate(inputs.fppEco.value);
      state.pesoPre = parseFloat(inputs.wPre.value) || null;
      state.pesoActual = parseFloat(inputs.w.value) || null;
      state.talla = parseFloat(inputs.h.value) || null;
      state.altUterina = parseFloat(inputs.au.value) || null;
      state.embarazoMultiple = inputs.mult.checked;
      renderResults();
    };
    Object.values(inputs).forEach(el => {
      if (el) {
        el.addEventListener('input', update);
        el.addEventListener('change', update);
      }
    });
    $('m3-clear')?.addEventListener('click', () => {
      Object.values(inputs).forEach(el => {
        if (el) { if (el.type === 'checkbox') el.checked = false; else el.value = ''; }
      });
      inputs.ciclo.value = '28';
      // Restablecer fecha de control a hoy tras limpiar
      inputs.fechaCtrl.value = O.dateToISO(O.todayUTC());
      update();
    });
  }

  // === Entry point ==========================================================
  window.render_gestante = function (panel) {
    if (!window.Obstetric) {
      panel.innerHTML = '<div class="empty-state">Módulo obstétrico no disponible</div>';
      return;
    }
    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Edad Gestacional y Nutrición</h1>
          <p class="muted small">Naegele · Parikh · Wahl · Ecografía · Ganancia IOM 2009 · Altura uterina CLAP/OPS</p>
        </div>
      </div>
      <div class="m2-layout">
        <div class="m2-input-col">
          ${renderForm()}
        </div>
        <div class="m2-output-col" id="m3-results"></div>
      </div>
    `;
    bindForm();
    renderResults();
  };
})();
