/* ============================================================================
   m1-m5-m9.js — Módulos 1 (Dashboard), 5 (Agenda) y 9 (Enlaces)
   Estructura simple, con CRUD admin para Agenda y Enlaces (audit log).
   ============================================================================ */
(function () {
  'use strict';

  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  function uid(prefix) {
    return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  }

  function todayISO() {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-${String(n.getDate()).padStart(2,'0')}`;
  }

  function nowTime() {
    return new Date().toLocaleTimeString('es-BO', { hour: '2-digit', minute: '2-digit' });
  }

  function dateHuman(iso) {
    if (!iso) return '—';
    return new Date(iso + 'T00:00:00').toLocaleDateString('es-BO', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  // Previsualiza un enlace en un mini-modal: imagen, YouTube, o tarjeta de dominio.
  function showLinkPreviewModal(url) {
    document.getElementById('rb-linkprev')?.remove();
    const isImg = /\.(png|jpe?g|gif|webp|svg)(\?|$)/i.test(url);
    const yt = String(url).match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([\w-]{11})/);
    let domain = '';
    try { domain = new URL(url).hostname.replace(/^www\./, ''); } catch (e) { domain = url; }

    let media;
    if (yt) {
      media = `<iframe width="100%" height="220" src="https://www.youtube.com/embed/${esc(yt[1])}" frameborder="0" allowfullscreen></iframe>`;
    } else if (isImg) {
      media = `<img src="${esc(url)}" class="rb-link-preview-img" alt="" />`;
    } else {
      const fav = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=64`;
      media = `
        <a href="${esc(url)}" target="_blank" rel="noopener" class="rb-link-preview">
          <img src="${esc(fav)}" class="rb-link-preview-fav" alt="" />
          <div class="rb-link-preview-info">
            <div class="rb-link-preview-domain">${esc(domain)}</div>
            <div class="rb-link-preview-url">${esc(url)}</div>
          </div>
        </a>`;
    }

    const ov = document.createElement('div');
    ov.id = 'rb-linkprev';
    ov.className = 'rb-ann-overlay';
    ov.style.zIndex = '100000';
    ov.innerHTML = `
      <div class="rb-ann-modal" style="max-width:420px;">
        <button class="rb-ann-close" aria-label="Cerrar">×</button>
        <div class="rb-ann-body">
          <h2 class="rb-ann-title" style="font-size:1rem;">Vista previa del enlace</h2>
          ${media}
          <div class="rb-ann-actions" style="margin-top:12px;">
            <a href="${esc(url)}" target="_blank" rel="noopener" class="btn btn-primary">Abrir enlace</a>
            <button class="btn btn-ghost rb-lp-close">Cerrar</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(ov);
    const close = () => ov.remove();
    ov.querySelector('.rb-ann-close')?.addEventListener('click', close);
    ov.querySelector('.rb-lp-close')?.addEventListener('click', close);
    ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  }

  // Masonry por JS: distribuye las cards en N columnas, colocando cada card
  // en la columna actualmente más corta. Garantiza relleno sin huecos.
  function layoutMasonry(panel) {
    const grid = panel.querySelector('.m1-grid');
    if (!grid) return;
    let originals = grid.__cards;
    if (!originals) {
      originals = Array.from(grid.children).filter(c => !c.classList.contains('m1-mcol'));
      grid.__cards = originals;
    }
    const width = grid.clientWidth || 960;
    const colW = 320 + 16;
    let nCols = Math.max(1, Math.floor(width / colW));
    if (nCols > originals.length) nCols = originals.length || 1;

    grid.innerHTML = '';
    grid.style.display = 'flex';
    grid.style.alignItems = 'flex-start';
    grid.style.gap = '16px';
    const cols = [];
    for (let i = 0; i < nCols; i++) {
      const col = document.createElement('div');
      col.className = 'm1-mcol';
      col.style.cssText = 'flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;';
      grid.appendChild(col);
      cols.push(col);
    }
    const heights = new Array(nCols).fill(0);
    originals.forEach(card => {
      let min = 0;
      for (let i = 1; i < nCols; i++) if (heights[i] < heights[min]) min = i;
      cols[min].appendChild(card);
      heights[min] += (card.offsetHeight || 200) + 16;
    });
  }
  let masonryResizeTimer = null;
  if (typeof window !== 'undefined' && window.addEventListener) {
    window.addEventListener('resize', () => {
      clearTimeout(masonryResizeTimer);
      masonryResizeTimer = setTimeout(() => {
        const p = document.querySelector('.tab-panel[data-panel="dashboard"]');
        if (p && p.classList.contains('is-active')) layoutMasonry(p);
      }, 200);
    });
  }

  // ============================================================
  // MÓDULO 1 — DASHBOARD (configurable por admin)
  // ============================================================
  window.render_dashboard = async function (panel) {
    // FIX: cargar las BD de las que depende el dashboard ANTES de renderizar.
    // Antes no se cargaban y por eso noticias/widgets aparecían vacíos.
    await ensureAgendaLoaded();
    loadAgendaFromStorage();
    try { await ensureEnlacesLoaded(); loadEnlacesFromStorage(); } catch (e) {}

    const agenda = window.DB_AGENDA || { noticias: [], eventos: [], todos: [], patologiaDelDia: null, dashboardWidgets: {} };
    const enlaces = window.DB_ENLACES?.enlaces || [];
    const isAdmin = window.Auth?.isAdmin();

    // Configuración de widgets visibles (admin la controla)
    // Si no hay config guardada, usar defaults y persistirla
    if (!agenda.dashboardWidgets) {
      agenda.dashboardWidgets = { noticias: true, patologiaDelDia: true, eventos: false, todos: false, enlaces: false };
    }
    const widgets = agenda.dashboardWidgets;

    // Próximos 3 eventos
    const hoy = todayISO();
    const proxEventos = (agenda.eventos || [])
      .filter(e => e.fecha >= hoy && e.estado !== 'cancelado')
      .sort((a,b) => a.fecha.localeCompare(b.fecha))
      .slice(0, 3);
    const todos = (agenda.todos || []).filter(t => t.estado !== 'hecho').slice(0, 3);
    const enlacesFreq = enlaces.slice(0, 6);

    const sections = [];

    // Widget: accesos rápidos a módulos (con breve descripción), cantidad configurable
    if (widgets.accesos !== false) {
      const MOD_DESC = [
        { id: 'nutricion',  icon: '📊', label: 'Nutrición',   desc: 'Z-scores y curvas OMS' },
        { id: 'gestante',   icon: '🤰', label: 'Gestante',    desc: 'Edad gestacional y FPP' },
        { id: 'vademecum',  icon: '💊', label: 'Vademécum',   desc: 'LINAME y dosis' },
        { id: 'clinica',    icon: '🩺', label: 'Clínica',     desc: 'Patologías Ley 475' },
        { id: 'pai-vigil',  icon: '💉', label: 'PAI / Vigilancia', desc: 'Vacunas y epidemiología' },
        { id: 'suppv-bja',  icon: '💰', label: 'SUPPV / BJA',  desc: 'Subsidios prenatales' },
        { id: 'enlaces',    icon: '🔗', label: 'Enlaces',     desc: 'Recursos y guías' },
        { id: 'seguimiento',icon: '📈', label: 'Seguimiento', desc: 'Control prenatal' },
      ];
      // Selección de accesos: array de ids elegidos por el admin. Default: todos.
      const seleccion = Array.isArray(agenda.dashboardAccesos)
        ? agenda.dashboardAccesos
        : MOD_DESC.map(m => m.id);
      const visibles = MOD_DESC.filter(m =>
        seleccion.includes(m.id) && (!window.Roles || window.Roles.isTabAllowed(m.id))
      );
      if (visibles.length) {
        sections.push(`
          <div class="card m1-card-wide m1-accesos-card">
            <div class="card-h"><h2>⚡ Accesos rápidos</h2></div>
            <div class="m1-accesos-grid">
              ${visibles.map(m => `
                <button class="m1-acceso" data-goto="${m.id}">
                  <span class="m1-acceso-icon">${m.icon}</span>
                  <span class="m1-acceso-body">
                    <span class="m1-acceso-label">${esc(m.label)}</span>
                    <span class="m1-acceso-desc">${esc(m.desc)}</span>
                  </span>
                </button>
              `).join('')}
            </div>
          </div>
        `);
      }
    }

    if (widgets.noticias) {
      sections.push(`
        <div class="card">
          <div class="card-h">
            <h2>📰 Noticias de salud</h2>
            <div class="row gap-2" style="margin-left:auto;">
              <button class="btn btn-ghost m1-news-refresh" style="font-size:0.8rem;padding:4px 10px;" title="Actualizar noticias">🔄</button>
              ${isAdmin ? '<button class="btn btn-ghost m1-news-config" style="font-size:0.8rem;padding:4px 10px;" title="Configurar fuentes RSS">⚙️</button>' : ''}
              ${isAdmin ? '<button class="btn btn-ghost m1-edit" data-section="noticias" style="font-size:0.8rem;padding:4px 10px;">+ Manual</button>' : ''}
            </div>
          </div>
          <div id="m1-news-container">
            <div class="m1-news-loading"><div class="skel" style="height:60px;"></div></div>
          </div>
          ${isAdmin && (agenda.noticias || []).length ? `
            <details class="m1-news-manual-admin">
              <summary class="tiny muted">Noticias manuales guardadas (${agenda.noticias.length}) — respaldo si fallan las fuentes</summary>
              ${(agenda.noticias || []).map(n => `
                <div class="m1-noticia">
                  <div class="tiny muted">${dateHuman(n.fecha)}</div>
                  <h3 class="m1-noticia-h">${esc(n.titulo)}</h3>
                  <p class="small">${esc(n.cuerpo)}</p>
                  <button class="m5-del" data-kind="noticia" data-id="${n.id}" style="position:absolute;top:8px;right:8px;">×</button>
                </div>
              `).join('')}
            </details>
          ` : ''}
        </div>
      `);
    }

    if (widgets.patologiaDelDia && agenda.patologiaDelDia) {
      sections.push(`
        <div class="card m1-pat-dia">
          <div class="card-h"><h2>⚕️ Patología del día</h2></div>
          <span class="badge badge-cie mono">${esc(agenda.patologiaDelDia.cie10)}</span>
          <h3 class="mt-2">${esc(agenda.patologiaDelDia.nombre)}</h3>
          <p class="small mt-2">${esc(agenda.patologiaDelDia.nota)}</p>
          <button class="btn btn-ghost mt-4" id="m1-ir-pat" style="font-size:0.85rem;">Ir a la patología →</button>
        </div>
      `);
    }

    if (widgets.eventos) {
      sections.push(`
        <div class="card">
          <div class="card-h"><h2>📅 Próximos eventos</h2></div>
          ${proxEventos.length ? `
            <ul class="m1-eventos">
              ${proxEventos.map(e => `
                <li>
                  <div class="m1-evento-fecha">${dateHuman(e.fecha)} ${e.hora ? '<span class="mono small">'+esc(e.hora)+'</span>' : ''}</div>
                  <div class="m1-evento-titulo">${esc(e.titulo)}</div>
                </li>
              `).join('')}
            </ul>
          ` : '<p class="muted small">Sin eventos próximos.</p>'}
          <button class="btn btn-ghost mt-2" id="m1-ir-agenda" style="font-size:0.85rem;">Ver agenda →</button>
        </div>
      `);
    }

    if (widgets.todos) {
      sections.push(`
        <div class="card">
          <div class="card-h"><h2>✓ Tareas pendientes</h2></div>
          ${todos.length ? `
            <ul class="m1-todos">
              ${todos.map(t => `
                <li>
                  <span class="m1-todo-state">○</span>
                  <span>${esc(t.titulo)}</span>
                </li>
              `).join('')}
            </ul>
          ` : '<p class="muted small">Sin tareas pendientes.</p>'}
        </div>
      `);
    }

    if (widgets.enlaces) {
      sections.push(`
        <div class="card">
          <div class="card-h"><h2>🔗 Recursos frecuentes</h2></div>
          <div class="m1-enlaces">
            ${enlacesFreq.map(e => `
              <a class="m1-enlace" href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">
                <div class="m1-enlace-cat">${esc(e.categoria)}</div>
                <div class="m1-enlace-t">${esc(e.titulo)}</div>
              </a>
            `).join('')}
          </div>
        </div>
      `);
    }

    // Panel de configuración para admin
    const configPanel = isAdmin ? `
      <div class="card m1-card-wide m1-config">
        <div class="card-h">
          <h2>⚙️ Configuración de Inicio</h2>
          <span class="badge badge-mute tiny">Solo admin</span>
        </div>
        <p class="small muted">Marca qué secciones serán visibles para todos los usuarios:</p>
        <div class="m1-config-grid">
          ${[
            ['accesos',         '⚡ Accesos rápidos'],
            ['noticias',        '📰 Noticias'],
            ['patologiaDelDia', '⚕️ Patología del día'],
            ['eventos',         '📅 Próximos eventos'],
            ['todos',           '✓ Tareas pendientes'],
            ['enlaces',         '🔗 Recursos frecuentes'],
          ].map(([k, lbl]) => {
            const on = (k === 'accesos') ? (widgets[k] !== false) : !!widgets[k];
            return `
            <label class="m3-checkbox">
              <input type="checkbox" class="m1-widget-toggle" data-key="${k}" ${on ? 'checked' : ''}/>
              <span>${esc(lbl)}</span>
            </label>`;
          }).join('')}
        </div>
        <div class="mt-3" style="border-top:1px solid var(--rule-soft);padding-top:var(--space-3);">
          <span class="field-label">¿Qué accesos rápidos mostrar?</span>
          <div class="m1-config-grid mt-2">
            ${[
              ['nutricion','Nutrición'],['gestante','Gestante'],['vademecum','Vademécum'],
              ['clinica','Clínica'],['pai-vigil','PAI / Vigilancia'],['suppv-bja','SUPPV / BJA'],
              ['enlaces','Enlaces'],['seguimiento','Seguimiento'],
            ].map(([id,lbl]) => {
              const sel = Array.isArray(agenda.dashboardAccesos) ? agenda.dashboardAccesos : ['nutricion','gestante','vademecum','clinica','pai-vigil','suppv-bja','enlaces','seguimiento'];
              return `<label class="m3-checkbox">
                <input type="checkbox" class="m1-acceso-toggle" data-id="${id}" ${sel.includes(id)?'checked':''}/>
                <span>${esc(lbl)}</span>
              </label>`;
            }).join('')}
          </div>
        </div>
        <div class="row gap-2 mt-3" style="flex-wrap:wrap;border-top:1px solid var(--rule-soft);padding-top:var(--space-3);">
          <button class="btn btn-ghost" id="m1-config-announce" style="font-size:0.85rem;padding:6px 12px;">📢 Configurar anuncio flotante</button>
          <button class="btn btn-ghost" id="m1-config-roles" style="font-size:0.85rem;padding:6px 12px;">👥 Gestor de accesos por rol</button>
          <button class="btn btn-ghost" id="m1-config-order" style="font-size:0.85rem;padding:6px 12px;">↕️ Orden de pestañas</button>
        </div>
        <div class="row gap-2 mt-2" style="flex-wrap:wrap;">
          <button class="btn btn-ghost" id="m1-backup-export" style="font-size:0.85rem;padding:6px 12px;">💾 Respaldar todo</button>
          <button class="btn btn-ghost" id="m1-backup-import" style="font-size:0.85rem;padding:6px 12px;">📂 Restaurar respaldo</button>
        </div>
      </div>
    ` : '';

    // Separar el widget de accesos (va arriba, ancho completo) del resto (masonry)
    const accesosHTML = sections.find(s => s.includes('m1-accesos-grid')) || '';
    const masonryHTML = sections.filter(s => !s.includes('m1-accesos-grid')).join('');

    // El login vive en el header (al lado del buscador), gestionado por
    // auth.js updateUI(). Inicio no muestra recuadro de login.
    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Inicio</h1>
          <p class="muted small">Panel principal · ${dateHuman(hoy)}</p>
        </div>
      </div>

      ${accesosHTML}

      <div class="m1-grid">
        ${masonryHTML}
      </div>

      ${configPanel}
    `;


    // Masonry real con JS: reparte las cards en la columna más corta para no
    // dejar huecos. CSS columns solo no garantiza equilibrio con pocas cards.
    const raf = (typeof requestAnimationFrame === 'function') ? requestAnimationFrame : (cb) => setTimeout(cb, 16);
    raf(() => layoutMasonry(panel));

    // Bindings
    document.getElementById('m1-ir-agenda')?.addEventListener('click', () => window.App.activateTab('agenda'));
    document.getElementById('m1-ir-pat')?.addEventListener('click', () => {
      const cie = agenda.patologiaDelDia?.cie10;
      if (!cie) return;
      window.App.activateTab('clinica');
      setTimeout(() => {
        const db = window.DB_PATOLOGIAS;
        if (db) {
          const p = db.patologias.find(x => x.cie10.includes(cie));
          if (p) document.dispatchEvent(new CustomEvent('rb:focus-patologia', { detail: { id: p.id, kind: 'patologia' } }));
        }
      }, 200);
    });

    // Toggle de widgets
    panel.querySelectorAll('.m1-widget-toggle').forEach(cb => {
      cb.addEventListener('change', () => {
        if (!agenda.dashboardWidgets) agenda.dashboardWidgets = {};
        agenda.dashboardWidgets[cb.dataset.key] = cb.checked;
        window.State.set('agenda_data', agenda);
        window.Auth?.audit('dashboard_widget_toggle', `${cb.dataset.key}=${cb.checked}`);
        window.render_dashboard(panel);
      });
    });

    // Checklist de accesos rápidos a mostrar
    panel.querySelectorAll('.m1-acceso-toggle').forEach(cb => {
      cb.addEventListener('change', () => {
        const sel = Array.from(panel.querySelectorAll('.m1-acceso-toggle:checked')).map(x => x.dataset.id);
        agenda.dashboardAccesos = sel;
        window.State.set('agenda_data', agenda);
        window.render_dashboard(panel);
      });
    });

    // Navegación desde accesos rápidos
    panel.querySelectorAll('.m1-acceso[data-goto]').forEach(btn => {
      btn.addEventListener('click', () => window.App?.activateTab(btn.dataset.goto));
    });

    // Configurar anuncio flotante
    document.getElementById('m1-config-announce')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!window.ModalEditor) return;
        const cur = agenda.announcement || { activo: false, frecuencia: 'daily' };
        window.ModalEditor.open({
          title: '📢 Anuncio flotante',
          size: 'lg',
          schema: [
            { key: '_help', label: '', type: 'info',
              text: 'Este anuncio aparece al cargar la app. Puedes poner una imagen (pega un enlace .jpg/.png o de YouTube), un mensaje y un botón con enlace. Usa el botón Vista previa para verlo antes de guardar.' },
            { key: 'activo', label: '¿Anuncio activo?', type: 'select',
              options: [ { value: 'si', label: 'Sí, mostrar' }, { value: 'no', label: 'No, desactivado' } ],
              default: cur.activo ? 'si' : 'no', allowEmpty: false },
            { key: 'titulo', label: 'Título', type: 'text' },
            { key: 'mensaje', label: 'Mensaje', type: 'textarea', rows: 4 },
            { key: 'imagen', label: 'Imagen o video (URL)', type: 'text', help: 'Enlace directo a imagen (.jpg/.png) o video de YouTube' },
            { key: 'link', label: 'Enlace del botón (URL)', type: 'text' },
            { key: 'textoBoton', label: 'Texto del botón', type: 'text', default: cur.textoBoton || 'Más información' },
            { key: 'frecuencia', label: 'Frecuencia', type: 'select',
              options: [
                { value: 'always',  label: 'Cada vez que carga' },
                { value: 'daily',   label: 'Una vez al día' },
                { value: 'version', label: 'Solo cuando cambie el contenido' },
              ], default: cur.frecuencia || 'daily', allowEmpty: false },
          ],
          data: {
            activo: cur.activo ? 'si' : 'no',
            titulo: cur.titulo || '', mensaje: cur.mensaje || '',
            imagen: cur.imagen || '', link: cur.link || '',
            textoBoton: cur.textoBoton || 'Más información',
            frecuencia: cur.frecuencia || 'daily',
          },
          extraButtons: [
            { label: '👁️ Vista previa', onClick: (data) => {
              if (window.previewAnnouncement) window.previewAnnouncement({
                activo: true, titulo: data.titulo, mensaje: data.mensaje,
                imagen: data.imagen, link: data.link, textoBoton: data.textoBoton,
                frecuencia: 'always',
              });
            }},
          ],
          onSave: (data) => {
            agenda.announcement = {
              activo: data.activo === 'si',
              titulo: data.titulo || '', mensaje: data.mensaje || '',
              imagen: data.imagen || '', link: data.link || '',
              textoBoton: data.textoBoton || 'Más información',
              frecuencia: data.frecuencia || 'daily',
            };
            window.State.set('agenda_data', agenda);
            window.Auth?.audit('config_announcement', `activo=${agenda.announcement.activo}`);
            window.State?.toast('✓ Anuncio guardado', 'ok');
          },
        });
      });
    });

    // Gestor de accesos por rol
    document.getElementById('m1-config-roles')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (window.openRoleManager) window.openRoleManager();
        else window.State?.toast('Gestor de roles no disponible', 'error');
      });
    });

    // Respaldo unificado
    document.getElementById('m1-backup-export')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => window.Backup?.exportAll());
    });
    document.getElementById('m1-backup-import')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => window.Backup?.importAll());
    });

    // Orden de pestañas
    document.getElementById('m1-config-order')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (window.openTabOrderManager) window.openTabOrderManager();
        else window.State?.toast('Gestor de orden no disponible', 'error');
      });
    });

    // Eliminar noticia (admin)
    panel.querySelectorAll('[data-kind="noticia"]').forEach(b => {
      b.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => {
          agenda.noticias = (agenda.noticias || []).filter(n => n.id !== b.dataset.id);
          window.State.set('agenda_data', agenda);
          window.Auth.audit('delete_noticia', b.dataset.id);
          window.render_dashboard(panel);
        });
      });
    });

    // Añadir noticia manual (respaldo)
    panel.querySelector('.m1-edit[data-section="noticias"]')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!window.ModalEditor) {
          const titulo = window.prompt('Título de la noticia:');
          if (!titulo) return;
          const cuerpo = window.prompt('Cuerpo:') || '';
          if (!agenda.noticias) agenda.noticias = [];
          agenda.noticias.unshift({ id: uid('N'), fecha: todayISO(), titulo, cuerpo });
          window.State.set('agenda_data', agenda);
          window.render_dashboard(panel);
          return;
        }
        window.ModalEditor.open({
          title: 'Nueva noticia manual',
          schema: [
            { key: 'titulo', label: 'Título', type: 'text', required: true },
            { key: 'cuerpo', label: 'Cuerpo / resumen', type: 'textarea', rows: 4 },
            { key: 'link',   label: 'Enlace (opcional)', type: 'text', help: 'Pega un URL. Si es imagen o YouTube, se previsualiza.' },
            { key: 'fecha',  label: 'Fecha', type: 'date', default: todayISO() },
          ],
          extraButtons: [
            { label: '👁️ Previsualizar enlace', onClick: (data) => {
              if (!data.link) { window.State?.toast('Pega un enlace primero', 'warn'); return; }
              showLinkPreviewModal(data.link);
            }},
          ],
          onSave: (data) => {
            if (!agenda.noticias) agenda.noticias = [];
            agenda.noticias.unshift({ id: uid('N'), fecha: data.fecha || todayISO(), titulo: data.titulo, cuerpo: data.cuerpo || '', link: data.link || '' });
            window.State.set('agenda_data', agenda);
            window.Auth?.audit('add_noticia', data.titulo);
            window.State?.toast('✓ Noticia manual agregada', 'ok');
            window.render_dashboard(panel);
          },
        });
      });
    });

    // === Noticias RSS (con respaldo manual) ===============================
    const newsContainer = document.getElementById('m1-news-container');
    if (newsContainer && window.NewsFeed) {
      window.NewsFeed.render(newsContainer, {
        feeds: agenda.newsFeeds && agenda.newsFeeds.length ? agenda.newsFeeds : undefined,
        manualNoticias: agenda.noticias || [],
      });
    } else if (newsContainer) {
      // NewsFeed no cargó: mostrar manuales directamente
      newsContainer.innerHTML = (agenda.noticias || []).length
        ? (agenda.noticias || []).map(n => `
            <div class="m1-noticia">
              <div class="tiny muted">${dateHuman(n.fecha)}</div>
              <h3 class="m1-noticia-h">${esc(n.titulo)}</h3>
              <p class="small">${esc(n.cuerpo)}</p>
            </div>`).join('')
        : '<p class="muted small">Sin noticias.</p>';
    }

    // Botón refrescar noticias
    panel.querySelector('.m1-news-refresh')?.addEventListener('click', () => {
      const c = document.getElementById('m1-news-container');
      if (c && window.NewsFeed) {
        // Limpiar caché para forzar recarga
        try { localStorage.removeItem('rb_news_cache_v1'); } catch(e) {}
        c.innerHTML = '<div class="m1-news-loading"><div class="skel" style="height:60px;"></div></div>';
        window.NewsFeed.render(c, {
          feeds: agenda.newsFeeds && agenda.newsFeeds.length ? agenda.newsFeeds : undefined,
          manualNoticias: agenda.noticias || [],
        });
      }
    });

    // Botón configurar fuentes RSS (admin)
    panel.querySelector('.m1-news-config')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!window.ModalEditor) return;
        const current = (agenda.newsFeeds && agenda.newsFeeds.length)
          ? agenda.newsFeeds
          : (window.NewsFeed?.DEFAULT_FEEDS || []);
        window.ModalEditor.open({
          title: 'Fuentes de noticias RSS',
          size: 'lg',
          schema: [
            { key: 'feeds', label: 'Fuentes de noticias', type: 'list',
              help: 'Recomendado: usa feeds JSON de rss.app (más confiables, sin proxy). Puedes generar uno gratis en rss.app con cualquier sitio (BBC, OPS, etc.) y pegar la URL .json aquí.',
              itemSchema: [
                { key: 'nombre', label: 'Nombre', type: 'text', required: true },
                { key: 'url',    label: 'URL del feed', type: 'text', required: true, help: 'JSON de rss.app (…/v1.1/….json) o RSS XML' },
                { key: 'type',   label: 'Tipo', type: 'select',
                  options: [
                    { value: 'json', label: 'JSON (rss.app — recomendado)' },
                    { value: 'rss',  label: 'RSS/XML (vía proxy)' },
                  ], default: 'json', allowEmpty: false },
              ],
            },
          ],
          data: { feeds: current },
          onSave: (data) => {
            agenda.newsFeeds = (data.feeds || []).filter(f => f.url);
            window.State.set('agenda_data', agenda);
            window.Auth?.audit('config_news_feeds', `${agenda.newsFeeds.length} fuentes`);
            window.State?.toast('✓ Fuentes actualizadas', 'ok');
            try { localStorage.removeItem('rb_news_cache_v1'); } catch(e) {}
            window.render_dashboard(panel);
          },
        });
      });
    });
  };

  // ============================================================
  // MÓDULO 5 — AGENDA (CRUD admin)
  // ============================================================
  function ensureAgendaLoaded() {
    if (window.DB_AGENDA) return Promise.resolve();
    return window.State.loadScript('data/db_agenda.js');
  }

  function saveAgenda() {
    // Persiste en localStorage (la "BD admin" se serializa allí)
    window.State.set('agenda_data', window.DB_AGENDA);
  }

  function loadAgendaFromStorage() {
    const stored = window.State.get('agenda_data');
    if (stored) {
      // Mantener metadatos del archivo original, pero usar datos guardados
      Object.assign(window.DB_AGENDA, stored);
    }
  }

  window.render_agenda = async function (panel) {
    await ensureAgendaLoaded();
    loadAgendaFromStorage();
    const db = window.DB_AGENDA;
    const isAdmin = window.Auth?.isAdmin();

    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Agenda</h1>
          <p class="muted small">Eventos, tareas y check-in/check-out</p>
        </div>
        ${isAdmin ? `
          <div class="row gap-2">
            <button class="btn btn-primary" id="m5-print-cal" style="font-size:0.85rem;padding:6px 12px;">🖨️ Imprimir calendario</button>
            <button class="btn btn-ghost" id="m5-export" style="font-size:0.85rem;padding:6px 12px;">⬇️ Exportar JSON</button>
            <button class="btn btn-ghost" id="m5-import" style="font-size:0.85rem;padding:6px 12px;">⬆️ Importar JSON</button>
          </div>
        ` : `
          <button class="btn btn-ghost" id="m5-login" style="font-size:0.85rem;padding:6px 12px;">🔒 Acceder admin</button>
        `}
      </div>

      <!-- Calendario mensual -->
      <div id="m5-calendar-wrap" class="m5-calendar-wrap"></div>

      <div class="m5-grid">
        <!-- Check-in / Check-out -->
        <div class="card m5-checkin-card">
          <div class="card-h"><h2>🕐 Asistencia</h2></div>
          ${isAdmin ? `
            <div class="row gap-2 mt-2">
              <button class="btn btn-primary" id="m5-checkin">Check-in</button>
              <button class="btn btn-ghost" id="m5-checkout">Check-out</button>
            </div>
            <p class="tiny muted mt-2">Cada acción queda registrada con hora del sistema en audit log.</p>
            <div class="m5-checkin-list">
              ${(db.checkins || []).slice(-5).reverse().map(c => `
                <div class="m5-checkin-item">
                  <span class="mono">${c.hora_in || '—'} ${c.hora_out ? '→ '+c.hora_out : ''}</span>
                  <span class="tiny muted">${esc(c.nota || '')}</span>
                </div>
              `).join('') || '<p class="muted tiny">Sin registros aún.</p>'}
            </div>
          ` : `<p class="muted small">Acceso admin requerido para registrar asistencia.</p>`}
        </div>

        <!-- Eventos -->
        <div class="card">
          <div class="card-h">
            <h2>📅 Eventos próximos</h2>
            ${isAdmin ? '<button class="btn btn-ghost m5-add-evt" style="margin-left:auto;font-size:0.8rem;padding:4px 10px;">+ Nuevo</button>' : ''}
          </div>
          <div id="m5-eventos-list">${renderEventosList(db.eventos || [], isAdmin)}</div>
        </div>

        <!-- To-do list -->
        <div class="card m1-card-wide">
          <div class="card-h">
            <h2>✓ To-do list</h2>
            ${isAdmin ? '<button class="btn btn-ghost m5-add-todo" style="margin-left:auto;font-size:0.8rem;padding:4px 10px;">+ Nueva tarea</button>' : ''}
          </div>
          <div id="m5-todos-list">${renderTodosList(db.todos || [], isAdmin)}</div>
        </div>

        ${isAdmin ? `
          <!-- Audit log -->
          <div class="card m1-card-wide">
            <div class="card-h">
              <h2>📜 Audit log</h2>
              <span class="badge badge-mute tiny mono">últimas 500</span>
              <div class="row gap-2" style="margin-left:auto;">
                <button class="btn btn-ghost m5-export-audit" style="font-size:0.8rem;padding:4px 10px;">⬇️ Exportar CSV</button>
                <button class="btn btn-ghost m5-clear-audit" style="font-size:0.8rem;padding:4px 10px;">Limpiar</button>
              </div>
            </div>
            <div id="m5-audit-list">${renderAuditList()}</div>
          </div>
        ` : ''}
      </div>
    `;

    // Renderizar calendario mensual
    renderCalendar(panel, db, isAdmin);

    // Bind imprimir: genera ventana nueva con SOLO el calendario del mes mostrado
    document.getElementById('m5-print-cal')?.addEventListener('click', () => {
      printCalendar(db);
    });

    // Binds
    document.getElementById('m5-login')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => window.render_agenda(panel));
    });
    document.getElementById('m5-export')?.addEventListener('click', () => {
      window.State.exportJSON('DB_AGENDA', 'db_agenda.js');
    });
    document.getElementById('m5-import')?.addEventListener('click', () => {
      window.State.importJSON('DB_AGENDA', () => { saveAgenda(); window.render_agenda(panel); });
    });
    document.getElementById('m5-checkin')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!db.checkins) db.checkins = [];
        db.checkins.push({ id: uid('CK'), hora_in: nowTime(), nota: 'Check-in manual' });
        window.Auth.audit('checkin');
        saveAgenda(); window.render_agenda(panel);
      });
    });
    document.getElementById('m5-checkout')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!db.checkins) db.checkins = [];
        const last = db.checkins[db.checkins.length - 1];
        if (last && !last.hora_out) {
          last.hora_out = nowTime();
        } else {
          db.checkins.push({ id: uid('CK'), hora_out: nowTime(), nota: 'Check-out sin check-in previo' });
        }
        window.Auth.audit('checkout');
        saveAgenda(); window.render_agenda(panel);
      });
    });
    document.querySelector('.m5-add-evt')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => promptEvento(db, panel));
    });
    document.querySelector('.m5-add-todo')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => promptTodo(db, panel));
    });
    document.querySelector('.m5-clear-audit')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (window.confirm('¿Limpiar todo el audit log? Esta acción no se puede deshacer.')) {
          localStorage.removeItem('rb_audit_v1');
          window.Auth.audit('audit_log_cleared');
          window.State.toast('Audit log limpiado', 'ok');
          window.render_agenda(panel);
        }
      });
    });
    document.querySelector('.m5-export-audit')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => exportAuditCSV());
    });
    bindAgendaActions(db, panel);
  };

  // === Impresión del calendario en ventana nueva (carta, solo mes+año) =====
  function printCalendar(db) {
    const y = calState.year, m = calState.month;
    const monthNames = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
                        'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const dayNames = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
    const firstDay = new Date(y, m, 1);
    const lastDay = new Date(y, m + 1, 0);
    const startWeekday = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    const totalCells = Math.ceil((startWeekday + daysInMonth) / 7) * 7;
    const COLORS = ['#1F5F4A', '#C9893E', '#B0413E', '#5B7CB8', '#7A5A8E'];
    const actsByDay = db.calendarActividades || {};

    let cells = '';
    for (let i = 0; i < totalCells; i++) {
      const dayNum = i - startWeekday + 1;
      if (dayNum < 1 || dayNum > daysInMonth) {
        cells += '<td class="empty"></td>';
        if ((i + 1) % 7 === 0) cells += '</tr><tr>';
        continue;
      }
      const iso = `${y}-${String(m+1).padStart(2,'0')}-${String(dayNum).padStart(2,'0')}`;
      const acts = actsByDay[iso] || [];
      cells += `<td>
        <div class="dnum">${dayNum}</div>
        ${acts.slice(0,5).map((a,idx) => `
          <div class="act" style="background:${a.color || COLORS[idx%5]}">
            ${a.hora ? '<b>'+esc(a.hora)+'</b> ' : ''}${esc(a.titulo)}
          </div>
        `).join('')}
      </td>`;
      if ((i + 1) % 7 === 0 && i + 1 < totalCells) cells += '</tr><tr>';
    }

    const html = `<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><title>Calendario ${monthNames[m]} ${y}</title>
<style>
  @page { size: letter; margin: 0.5in; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, system-ui, 'Segoe UI', sans-serif; color: #1a1a1a; padding: 12px; }
  h1 { text-align: center; font-size: 20pt; margin-bottom: 14px; font-weight: 700; letter-spacing: 0.02em; }
  table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  th { background: #f0ece2; border: 1px solid #c8c0b0; padding: 6px 4px; font-size: 9pt;
       text-transform: uppercase; letter-spacing: 0.05em; }
  td { border: 1px solid #c8c0b0; height: 90px; vertical-align: top; padding: 3px; overflow: hidden; }
  td.empty { background: #fafafa; }
  .dnum { font-size: 10pt; font-weight: 700; margin-bottom: 2px; font-variant-numeric: tabular-nums; }
  .act { color: #fff; font-size: 7pt; padding: 1px 3px; border-radius: 2px; margin-bottom: 1px;
         overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
         -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .act b { font-variant-numeric: tabular-nums; }
  @media print { button { display: none; } }
</style></head>
<body>
  <h1>${monthNames[m]} ${y}</h1>
  <table>
    <thead><tr>${dayNames.map(d => `<th>${d}</th>`).join('')}</tr></thead>
    <tbody><tr>${cells}</tr></tbody>
  </table>
  <button onclick="window.print()" style="margin:16px auto;display:block;padding:8px 20px;font-size:11pt;cursor:pointer;">🖨️ Imprimir</button>
  <script>setTimeout(function(){ window.print(); }, 400);<\/script>
</body></html>`;

    const win = window.open('', '_blank');
    if (!win) {
      window.State?.toast('Permite ventanas emergentes para imprimir', 'warn', 4000);
      return;
    }
    win.document.open();
    win.document.write(html);
    win.document.close();
    window.Auth?.audit('print_calendar', `${monthNames[m]} ${y}`);
  }

  // === Calendario mensual ===================================================
  // Estado del mes mostrado
  const calState = { year: null, month: null };  // month: 0-11

  function renderCalendar(panel, db, isAdmin) {
    const wrap = document.getElementById('m5-calendar-wrap');
    if (!wrap) return;

    // Inicializar al mes actual si no se ha hecho
    const now = new Date();
    if (calState.year === null) {
      calState.year = now.getFullYear();
      calState.month = now.getMonth();
    }
    const y = calState.year, m = calState.month;
    const firstDay = new Date(y, m, 1);
    const lastDay = new Date(y, m + 1, 0);
    const monthNames = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
                        'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const dayNames = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];

    // Inicializar estructura de actividades en la BD
    if (!db.calendarActividades) db.calendarActividades = {};

    // Colores predefinidos para las actividades (5 colores)
    const COLORS = ['#1F5F4A', '#C9893E', '#B0413E', '#5B7CB8', '#7A5A8E'];

    // Indices de día de semana (Domingo=0)
    const startWeekday = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    const totalCells = Math.ceil((startWeekday + daysInMonth) / 7) * 7;

    let cellsHTML = '';
    // Encabezado de días
    cellsHTML += '<div class="m5-cal-hdr">';
    for (const dn of dayNames) cellsHTML += `<div class="m5-cal-day-name">${dn}</div>`;
    cellsHTML += '</div>';

    // Cuerpo del calendario
    cellsHTML += '<div class="m5-cal-body">';
    for (let i = 0; i < totalCells; i++) {
      const dayNum = i - startWeekday + 1;
      if (dayNum < 1 || dayNum > daysInMonth) {
        cellsHTML += '<div class="m5-cal-cell is-empty"></div>';
        continue;
      }
      const iso = `${y}-${String(m+1).padStart(2,'0')}-${String(dayNum).padStart(2,'0')}`;
      const acts = db.calendarActividades[iso] || [];
      const isToday = (iso === todayISO());
      cellsHTML += `
        <div class="m5-cal-cell ${isToday ? 'is-today' : ''}" data-iso="${iso}">
          <div class="m5-cal-num">${dayNum}</div>
          <div class="m5-cal-acts">
            ${acts.slice(0, 5).map((a, idx) => `
              <div class="m5-cal-act" style="background:${a.color || COLORS[idx % 5]};" title="${esc(a.hora ? a.hora+' — ' : '')}${esc(a.titulo)}">
                ${a.hora ? '<span class="m5-cal-act-h">'+esc(a.hora)+'</span>' : ''}
                <span class="m5-cal-act-t">${esc(a.titulo)}</span>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    }
    cellsHTML += '</div>';

    wrap.innerHTML = `
      <div class="card m5-calendar">
        <div class="m5-cal-h">
          <div class="m5-cal-nav">
            <button class="btn btn-ghost m5-cal-prev" title="Mes anterior">‹</button>
            <h2 class="m5-cal-title">${monthNames[m]} ${y}</h2>
            <button class="btn btn-ghost m5-cal-next" title="Mes siguiente">›</button>
          </div>
          ${isAdmin ? '<span class="tiny muted">Click en un día para agregar/editar actividades (máx 5/día)</span>' : '<span class="tiny muted">Solo lectura — inicia sesión admin para editar</span>'}
        </div>
        ${cellsHTML}
      </div>
    `;

    // Binds de navegación
    wrap.querySelector('.m5-cal-prev')?.addEventListener('click', () => {
      calState.month--;
      if (calState.month < 0) { calState.month = 11; calState.year--; }
      renderCalendar(panel, db, isAdmin);
    });
    wrap.querySelector('.m5-cal-next')?.addEventListener('click', () => {
      calState.month++;
      if (calState.month > 11) { calState.month = 0; calState.year++; }
      renderCalendar(panel, db, isAdmin);
    });
    // Click en celda: editar actividades del día
    if (isAdmin) {
      wrap.querySelectorAll('.m5-cal-cell[data-iso]').forEach(cell => {
        cell.addEventListener('click', () => {
          promptDayActivities(cell.dataset.iso, db, panel);
        });
      });
    }
  }

  function promptDayActivities(iso, db, panel) {
    if (!window.ModalEditor) {
      window.State?.toast('ModalEditor no disponible', 'error');
      return;
    }
    const acts = (db.calendarActividades[iso] || []).slice();

    // Schema: lista de actividades con título, hora, color, descripción
    // Hora actual como sugerencia (HH:MM) para nuevas actividades
    const now = new Date();
    const horaActual = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    // Si no hay actividades, precargar una con la hora actual sugerida
    const initialActs = acts.length ? acts : [{ hora: horaActual, titulo: '', descripcion: '', color: '#1F5F4A' }];

    const schema = [
      { key: 'actividades', label: `Actividades del ${dateHuman(iso)} (máx 5)`, type: 'list',
        itemSchema: [
          { key: 'hora',        label: 'Hora',             type: 'time', default: horaActual, help: 'Sugerencia: hora actual. Modifícala libremente.' },
          { key: 'titulo',      label: 'Título',           type: 'text', required: true },
          { key: 'descripcion', label: 'Descripción',      type: 'textarea', rows: 2 },
          { key: 'color',       label: 'Color',            type: 'select',
            options: [
              { value: '#1F5F4A', label: '🟢 Verde (clínico)' },
              { value: '#C9893E', label: '🟡 Ámbar (alerta)' },
              { value: '#B0413E', label: '🔴 Rojo (urgente)' },
              { value: '#5B7CB8', label: '🔵 Azul (admin)' },
              { value: '#7A5A8E', label: '🟣 Violeta (otro)' },
            ],
            default: '#1F5F4A', allowEmpty: false,
          },
        ],
      },
    ];

    window.ModalEditor.open({
      title: `Actividades — ${dateHuman(iso)}`,
      schema,
      data: { actividades: initialActs },
      size: 'lg',
      onSave: (result) => {
        let list = (result.actividades || []).filter(a => a.titulo);
        if (list.length > 5) {
          window.State?.toast('Máximo 5 actividades por día. Se guardan las primeras 5.', 'warn');
          list = list.slice(0, 5);
        }
        if (list.length === 0) {
          delete db.calendarActividades[iso];
        } else {
          db.calendarActividades[iso] = list;
        }
        saveAgenda();
        window.Auth?.audit('agenda_calendar_edit', `${iso}: ${list.length} actividades`);
        window.render_agenda(panel);
      },
    });
  }

  function todayISO() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }

  function renderEventosList(eventos, isAdmin) {
    if (!eventos.length) return '<p class="muted small">Sin eventos registrados.</p>';
    return `<ul class="m5-eventos">${eventos.map(e => `
      <li>
        <div class="m5-evt-fecha">${dateHuman(e.fecha)} ${e.hora ? '<span class="mono tiny">'+esc(e.hora)+'</span>' : ''}</div>
        <div class="m5-evt-titulo">${esc(e.titulo)}</div>
        ${e.descripcion ? `<p class="tiny muted mt-2">${esc(e.descripcion)}</p>` : ''}
        ${isAdmin ? `<button class="m5-del" data-kind="evento" data-id="${e.id}" title="Eliminar">×</button>` : ''}
      </li>
    `).join('')}</ul>`;
  }

  function renderTodosList(todos, isAdmin) {
    if (!todos.length) return '<p class="muted small">Sin tareas registradas.</p>';
    return `<ul class="m5-todos">${todos.map(t => `
      <li class="${t.estado === 'hecho' ? 'is-done' : ''}">
        <button class="m5-todo-check" data-id="${t.id}" ${!isAdmin ? 'disabled' : ''}>${t.estado === 'hecho' ? '✓' : '○'}</button>
        <span class="m5-todo-titulo">${esc(t.titulo)}</span>
        ${t.descripcion ? `<span class="tiny muted">— ${esc(t.descripcion)}</span>` : ''}
        ${isAdmin ? `<button class="m5-del" data-kind="todo" data-id="${t.id}" title="Eliminar">×</button>` : ''}
      </li>
    `).join('')}</ul>`;
  }

  function renderAuditList() {
    const log = window.Auth?.getAuditLog() || [];
    if (!log.length) return '<p class="muted small">Sin acciones registradas.</p>';
    // Más recientes primero, máximo 50 en la UI
    const recent = log.slice().reverse().slice(0, 50);
    return `
      <div class="m5-audit-wrap">
        <table class="m8-tabla">
          <thead>
            <tr><th>Fecha · Hora</th><th>Usuario</th><th>Acción</th><th>Detalle</th></tr>
          </thead>
          <tbody>
            ${recent.map(e => `
              <tr>
                <td class="mono tiny">${esc(formatTs(e.ts))}</td>
                <td class="tiny">${esc(e.user)}</td>
                <td><span class="badge ${auditBadgeClass(e.action)} tiny">${esc(e.action)}</span></td>
                <td class="tiny muted">${esc(e.detail || '—')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        ${log.length > 50 ? `<p class="tiny muted mt-2">Mostrando 50 más recientes de ${log.length} registradas.</p>` : ''}
      </div>
    `;
  }

  function formatTs(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      return d.toLocaleString('es-BO', {
        day: '2-digit', month: '2-digit', year: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
      });
    } catch (e) { return iso; }
  }

  function auditBadgeClass(action) {
    if (action.startsWith('login') || action === 'logout') return 'badge-mute';
    if (action.includes('delete')) return 'badge-rose';
    if (action.includes('import') || action.includes('export')) return 'badge-ochre';
    if (action.includes('checkin') || action.includes('checkout')) return 'badge-clinic';
    return 'badge-mute';
  }

  function csvCell(s) {
    const v = String(s == null ? '' : s);
    // Si contiene coma, comillas o saltos de línea, encerrar en comillas y escapar comillas
    if (/[",\n\r]/.test(v)) return '"' + v.replace(/"/g, '""') + '"';
    return v;
  }

  function exportAuditCSV() {
    const log = window.Auth?.getAuditLog() || [];
    if (!log.length) {
      window.State.toast('Audit log vacío, nada que exportar', 'warn');
      return;
    }
    const header = ['timestamp_iso', 'fecha_hora_local', 'usuario', 'accion', 'detalle'];
    const rows = log.map(e => [
      e.ts || '',
      formatTs(e.ts),
      e.user || '',
      e.action || '',
      e.detail || '',
    ]);
    const csv = '\uFEFF' + [header, ...rows]
      .map(r => r.map(csvCell).join(','))
      .join('\n');
    const filename = `audit_log_${new Date().toISOString().slice(0,10)}.csv`;
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 100);
    window.Auth.audit('audit_log_exported', `${log.length} entradas → ${filename}`);
    window.State.toast(`✓ ${filename} descargado (${log.length} entradas)`, 'ok');
  }

  function bindAgendaActions(db, panel) {
    panel.querySelectorAll('.m5-del').forEach(b => {
      b.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => {
          const k = b.dataset.kind, id = b.dataset.id;
          if (k === 'evento') db.eventos = db.eventos.filter(x => x.id !== id);
          else if (k === 'todo') db.todos = db.todos.filter(x => x.id !== id);
          window.Auth.audit('delete_'+k, id);
          saveAgenda(); window.render_agenda(panel);
        });
      });
    });
    panel.querySelectorAll('.m5-todo-check').forEach(b => {
      b.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => {
          const t = db.todos.find(x => x.id === b.dataset.id);
          if (t) { t.estado = t.estado === 'hecho' ? 'pendiente' : 'hecho'; t.completado = t.estado === 'hecho' ? new Date().toISOString() : null; }
          window.Auth.audit('toggle_todo', b.dataset.id);
          saveAgenda(); window.render_agenda(panel);
        });
      });
    });
  }

  function promptEvento(db, panel) {
    const titulo = window.prompt('Título del evento:');
    if (!titulo) return;
    const fecha = window.prompt('Fecha (YYYY-MM-DD):', todayISO());
    if (!fecha || !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) { window.State.toast('Fecha inválida', 'error'); return; }
    const hora = window.prompt('Hora (HH:MM) — opcional:', '') || '';
    const descripcion = window.prompt('Descripción — opcional:', '') || '';
    if (!db.eventos) db.eventos = [];
    db.eventos.push({ id: uid('E'), titulo, fecha, hora, descripcion, estado: 'pendiente' });
    window.Auth.audit('add_evento', titulo);
    saveAgenda(); window.render_agenda(panel);
  }

  function promptTodo(db, panel) {
    const titulo = window.prompt('Título de la tarea:');
    if (!titulo) return;
    const descripcion = window.prompt('Descripción — opcional:', '') || '';
    if (!db.todos) db.todos = [];
    db.todos.push({ id: uid('T'), titulo, descripcion, estado: 'pendiente', creado: new Date().toISOString() });
    window.Auth.audit('add_todo', titulo);
    saveAgenda(); window.render_agenda(panel);
  }

  // ============================================================
  // MÓDULO 9 — ENLACES (con filtrado oninput)
  // ============================================================
  function ensureEnlacesLoaded() {
    if (window.DB_ENLACES) return Promise.resolve();
    return window.State.loadScript('data/db_enlaces.js');
  }

  function saveEnlaces() {
    window.State.set('enlaces_data', window.DB_ENLACES);
  }
  function loadEnlacesFromStorage() {
    const stored = window.State.get('enlaces_data');
    if (stored) Object.assign(window.DB_ENLACES, stored);
  }

  // Categorías: cada una con nombre y visibilidad ('public' | 'admin').
  // Se guardan en DB_ENLACES.categorias. Si no existen, se derivan de los enlaces.
  function getCategorias() {
    const db = window.DB_ENLACES;
    if (!db) return [];
    if (!db.categorias || !db.categorias.length) {
      // Derivar de los enlaces existentes (migración suave)
      const set = [...new Set((db.enlaces || []).map(e => e.categoria).filter(Boolean))];
      db.categorias = set.map(nombre => ({
        nombre,
        visibilidad: /^admin$/i.test(nombre) ? 'admin' : 'public',
      }));
    }
    return db.categorias;
  }

  function isAdminCategory(cat) {
    const cats = (window.DB_ENLACES?.categorias) || [];
    const found = cats.find(c => c.nombre === cat);
    if (found) return found.visibilidad === 'admin';
    // fallback: por nombre
    return String(cat || '').toUpperCase().trim() === 'ADMIN';
  }

  function buildEnlaceSchema() {
    const cats = getCategorias();
    return [
      { key: 'titulo',      label: 'Título del recurso', type: 'text', required: true },
      { key: 'url',         label: 'URL completa',       type: 'text', required: true, help: 'Debe incluir https://' },
      { key: 'categoria',   label: 'Categoría',          type: 'select',
        options: cats.map(c => ({ value: c.nombre, label: c.nombre + (c.visibilidad === 'admin' ? ' 🔒' : '') })),
        required: true, allowEmpty: false },
      { key: 'descripcion', label: 'Descripción',        type: 'textarea', rows: 2 },
    ];
  }

  window.render_enlaces = async function (panel) {
    await ensureEnlacesLoaded();
    loadEnlacesFromStorage();
    const db = window.DB_ENLACES;
    const isAdmin = window.Auth?.isAdmin();
    // Filtrar enlaces ADMIN si no hay sesión admin
    const enlacesVisibles = isAdmin
      ? db.enlaces
      : db.enlaces.filter(e => !isAdminCategory(e.categoria));
    const categorias = [...new Set(enlacesVisibles.map(e => e.categoria))];

    panel.innerHTML = `
      <div class="m6-header">
        <div>
          <h1>Enlaces y recursos</h1>
          <p class="muted small">${enlacesVisibles.length} recursos en ${categorias.length} categorías${isAdmin && db.enlaces.length > enlacesVisibles.length ? ` <span class="badge badge-ochre tiny">+${db.enlaces.length - enlacesVisibles.length} ADMIN</span>` : ''}</p>
        </div>
        ${isAdmin ? `
          <div class="row gap-2">
            <button class="btn btn-ghost" id="m9-add" style="font-size:0.85rem;padding:6px 12px;">+ Nuevo</button>
            <button class="btn btn-ghost" id="m9-cats" style="font-size:0.85rem;padding:6px 12px;">🏷️ Categorías</button>
            <button class="btn btn-ghost" id="m9-export" style="font-size:0.85rem;padding:6px 12px;">⬇️ Exportar</button>
            <button class="btn btn-ghost" id="m9-import" style="font-size:0.85rem;padding:6px 12px;">⬆️ Importar</button>
          </div>
        ` : ''}
      </div>
      <div class="m6-filters">
        <div class="m6-filter-search">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input type="search" id="m9-q" placeholder="Filtrar enlaces..." class="field-input" />
        </div>
        <select class="field-select" id="m9-cat">
          <option value="">Todas las categorías</option>
          ${categorias.map(c => `<option value="${esc(c)}">${esc(c)}${isAdminCategory(c) ? ' 🔒' : ''}</option>`).join('')}
        </select>
      </div>
      <div class="m9-grid" id="m9-grid"></div>
    `;

    const q = document.getElementById('m9-q');
    const cat = document.getElementById('m9-cat');
    let timer;
    const filter = () => {
      const nq = (q.value || '').toLowerCase();
      const nc = cat.value;
      const filtered = enlacesVisibles.filter(e => {
        if (nc && e.categoria !== nc) return false;
        if (nq) {
          const hay = (e.titulo + ' ' + e.descripcion + ' ' + e.url).toLowerCase();
          if (!hay.includes(nq)) return false;
        }
        return true;
      });
      renderEnlacesGrid(filtered, isAdmin);
    };
    q?.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(filter, 200); });
    cat?.addEventListener('change', filter);

    document.getElementById('m9-export')?.addEventListener('click', () => window.State.exportJSON('DB_ENLACES', 'db_enlaces.js'));
    document.getElementById('m9-import')?.addEventListener('click', () => window.State.importJSON('DB_ENLACES', () => { saveEnlaces(); window.render_enlaces(panel); }));

    document.getElementById('m9-add')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!window.ModalEditor) {
          window.State?.toast('ModalEditor no disponible', 'error');
          return;
        }
        const cats = getCategorias();
        window.ModalEditor.open({
          title: 'Nuevo enlace',
          schema: buildEnlaceSchema(),
          data: { categoria: cats[0]?.nombre || '' },
          onSave: (data) => {
            db.enlaces.push({ id: uid('E'), ...data });
            window.Auth?.audit('add_enlace', data.titulo);
            saveEnlaces();
            window.State?.toast(`✓ Enlace "${data.titulo}" creado`, 'ok');
            window.render_enlaces(panel);
          },
        });
      });
    });

    // Gestionar categorías (crear/editar/eliminar, public/admin)
    document.getElementById('m9-cats')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => {
        if (!window.ModalEditor) return;
        const cats = getCategorias();
        window.ModalEditor.open({
          title: 'Gestionar categorías',
          size: 'lg',
          schema: [
            { key: '_help', label: '', type: 'info',
              text: 'Las categorías marcadas como "Solo admin" solo se muestran a administradores. Si eliminas una categoría usada por enlaces, esos enlaces quedarán sin categoría visible.' },
            { key: 'categorias', label: 'Categorías', type: 'list',
              itemSchema: [
                { key: 'nombre',      label: 'Nombre', type: 'text', required: true },
                { key: 'visibilidad', label: 'Visibilidad', type: 'select',
                  options: [
                    { value: 'public', label: 'Pública (todos)' },
                    { value: 'admin',  label: 'Solo admin 🔒' },
                  ], default: 'public', allowEmpty: false },
              ],
            },
          ],
          data: { categorias: cats.map(c => ({ ...c })) },
          onSave: (data) => {
            db.categorias = (data.categorias || []).filter(c => c.nombre);
            saveEnlaces();
            window.Auth?.audit('edit_categorias', `${db.categorias.length} categorías`);
            window.State?.toast('✓ Categorías actualizadas', 'ok');
            window.render_enlaces(panel);
          },
        });
      });
    });

    filter();
  };

  function renderEnlacesGrid(enlaces, isAdmin) {
    const c = document.getElementById('m9-grid');
    if (!c) return;
    if (!enlaces.length) {
      c.innerHTML = '<div class="empty-state"><p class="muted">Sin resultados.</p></div>';
      return;
    }
    c.innerHTML = enlaces.map(e => `
      <div class="m9-card">
        <span class="badge badge-mute tiny">${esc(e.categoria)}</span>
        <h3 class="m9-card-h">${esc(e.titulo)}</h3>
        <p class="tiny muted">${esc(e.descripcion || '')}</p>
        <a href="${esc(e.url)}" target="_blank" rel="noopener noreferrer" class="btn btn-primary mt-2" style="font-size:0.82rem;padding:6px 12px;">
          Abrir recurso →
        </a>
        ${isAdmin ? `<button class="m9-del" data-id="${e.id}" title="Eliminar">×</button>` : ''}
      </div>
    `).join('');
    c.querySelectorAll('.m9-del').forEach(b => {
      b.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => {
          const db = window.DB_ENLACES;
          db.enlaces = db.enlaces.filter(x => x.id !== b.dataset.id);
          window.Auth.audit('delete_enlace', b.dataset.id);
          saveEnlaces();
          const panel = document.querySelector('.tab-panel[data-panel="enlaces"]');
          if (panel) window.render_enlaces(panel);
        });
      });
    });
  }
})();
