/* ============================================================================
   excel-io.js — Conversor Excel ↔ JSON con lazy-load de SheetJS

   SheetJS Community Edition (~ 700 KB) se carga solo cuando el admin necesita
   trabajar con Excel. Una vez cargado, queda en memoria por la sesión.

   API:
     await ExcelIO.ensureLib()        // pre-carga SheetJS, devuelve true/false
     ExcelIO.export(data, { filename, sheetName, columns })  // descarga .xlsx
     ExcelIO.import(file, { columns })  // lee .xlsx, retorna array de objetos
     ExcelIO.downloadTemplate({ filename, sheetName, columns, examples })
   ============================================================================ */
(function () {
  'use strict';

  // SheetJS empaquetado localmente (vendor-xlsx.min.js) para funcionar 100%
  // offline. Si por algún motivo el archivo local falla, se intenta CDN.
  const SHEETJS_URLS = [
    'js/vendor-xlsx.min.js',                                              // local (offline)
    'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',     // respaldo CDN
    'https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js',
  ];
  let loading = null;

  function loadScriptFrom(url) {
    return new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = url;
      s.async = true;
      s.onload = () => resolve(true);
      s.onerror = () => { s.remove(); resolve(false); };
      document.head.appendChild(s);
    });
  }

  function ensureLib() {
    if (window.XLSX) return Promise.resolve(true);
    if (loading) return loading;
    loading = (async () => {
      for (const url of SHEETJS_URLS) {
        const ok = await loadScriptFrom(url);
        if (ok && window.XLSX) return true;
      }
      loading = null;
      window.State?.toast('No se pudo cargar la librería de Excel — revisa tu conexión a Internet', 'error', 5000);
      return false;
    })();
    return loading;
  }

  /**
   * Exporta un array de objetos como .xlsx
   *   data: [{ col1: 'val', col2: 'val' }, ...]
   *   columns: [{ key, header, width? }]
   */
  async function exportXlsx(data, opts) {
    const ok = await ensureLib();
    if (!ok) return false;
    const { filename, sheetName = 'Datos', columns } = opts;
    const XLSX = window.XLSX;

    // Construir matriz: primera fila = headers, después una fila por registro
    const headers = columns.map(c => c.header);
    const rows = data.map(rec => columns.map(c => {
      let v = rec[c.key];
      if (Array.isArray(v)) v = v.join(' | ');         // arrays serializados con |
      if (v && typeof v === 'object') v = JSON.stringify(v);
      return v == null ? '' : v;
    }));
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);

    // Anchos de columna sugeridos
    ws['!cols'] = columns.map(c => ({ wch: c.width || Math.min(50, Math.max(12, c.header.length + 2)) }));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
    XLSX.writeFile(wb, filename, { bookType: 'xlsx', compression: true });
    return true;
  }

  /**
   * Lee un .xlsx subido por el usuario y devuelve array de objetos.
   *   file: File object (de un <input type="file">)
   *   columns: [{ key, header, type? }]  — header debe coincidir con el de la hoja
   *
   * Devuelve: Promise<Array<Object>>
   */
  async function importXlsx(file, opts) {
    const ok = await ensureLib();
    if (!ok) throw new Error('SheetJS no disponible');
    const { columns } = opts;
    const XLSX = window.XLSX;

    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: '', raw: false });

    // Mapeo: cada fila → objeto con keys del schema
    return rows.map(row => {
      const obj = {};
      for (const col of columns) {
        let v = row[col.header];
        if (v == null) v = '';
        v = String(v).trim();
        // Listas: separar por |
        if (col.type === 'array') {
          v = v ? v.split(/\s*\|\s*/).filter(Boolean) : [];
        } else if (col.type === 'number') {
          const n = parseFloat(v);
          v = isNaN(n) ? null : n;
        }
        obj[col.key] = v;
      }
      return obj;
    });
  }

  /**
   * Descarga una plantilla Excel vacía o con ejemplos.
   *   columns: [{ key, header, width?, example? }]
   *   examples: [{...}, ...]  — filas de ejemplo opcionales
   */
  async function downloadTemplate(opts) {
    const { filename, sheetName = 'Datos', columns, examples = [] } = opts;
    const data = examples.length ? examples : [];
    // Si no hay examples, generar UNA fila con el campo example de cada columna
    if (examples.length === 0) {
      const exRow = {};
      columns.forEach(c => { exRow[c.key] = c.example != null ? c.example : ''; });
      data.push(exRow);
    }
    return exportXlsx(data, { filename, sheetName, columns });
  }

  // === API pública =========================================================
  window.ExcelIO = {
    ensureLib,
    export: exportXlsx,
    import: importXlsx,
    downloadTemplate,
  };
})();
