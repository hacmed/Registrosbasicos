/* ============================================================================
   state.js — Gestión de estado, persistencia y E/S de archivos JSON
   ============================================================================ */
(function () {
  'use strict';

  const STORAGE_PREFIX = 'rb_';

  // === Generic key/value persistente =======================================
  function get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(STORAGE_PREFIX + key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }

  function set(key, value) {
    try { localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value)); }
    catch (e) { console.warn('[state] no se pudo guardar', key, e); }
  }

  function remove(key) {
    localStorage.removeItem(STORAGE_PREFIX + key);
  }

  // === Tab activa ===========================================================
  function getActiveTab() { return get('active_tab', 'dashboard'); }
  function setActiveTab(t) { set('active_tab', t); }

  // === Toast notifications =================================================
  function ensureToastRegion() {
    let region = document.querySelector('.toast-region');
    if (!region) {
      region = document.createElement('div');
      region.className = 'toast-region';
      document.body.appendChild(region);
    }
    return region;
  }

  function toast(message, type = 'info', duration = 3500) {
    const region = ensureToastRegion();
    const el = document.createElement('div');
    const cls = type === 'ok' ? 'toast-ok'
              : type === 'warn' ? 'toast-warn'
              : type === 'error' ? 'toast-error'
              : '';
    el.className = `toast ${cls}`;
    el.textContent = message;
    region.appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity 200ms';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 220);
    }, duration);
  }

  // === Importación de archivos JSON (requiere admin) =======================
  /**
   * Pide un archivo .js o .json al usuario, lo carga y reemplaza la variable global.
   * NO se ejecuta sin permiso admin.
   * @param {string} targetVar - nombre de la var global: 'DB_CLINICA' etc.
   * @param {function} onSuccess - callback(data) tras carga exitosa
   */
  function importJSON(targetVar, onSuccess) {
    if (!window.Auth || !window.Auth.isAdmin()) {
      window.Auth?.gateAdmin(() => importJSON(targetVar, onSuccess));
      return;
    }

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,.js,application/json,text/javascript';
    input.style.display = 'none';

    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        let data;
        if (file.name.endsWith('.json')) {
          data = JSON.parse(text);
        } else {
          // .js: extraemos el JSON del patrón "window.X = {...};"
          const m = text.match(/=\s*(\{[\s\S]*\})\s*;?\s*$/);
          if (!m) throw new Error('Formato no reconocido (esperaba window.X = {...};)');
          data = JSON.parse(m[1]);
        }
        // Backup de versión actual antes de sobreescribir
        if (window[targetVar]) {
          set(`backup_${targetVar}_${Date.now()}`, window[targetVar]);
        }
        window[targetVar] = data;
        window.Auth?.audit('import_json', `${targetVar} ← ${file.name} (${(file.size/1024).toFixed(1)} KB)`);
        toast(`✓ ${file.name} cargado correctamente`, 'ok');
        if (onSuccess) onSuccess(data);
      } catch (err) {
        toast('Error al cargar: ' + err.message, 'error', 5000);
        console.error(err);
      }
    });

    document.body.appendChild(input);
    input.click();
    setTimeout(() => input.remove(), 1000);
  }

  /**
   * Descarga el contenido de una variable global como archivo .js.
   * Requiere admin.
   */
  function exportJSON(targetVar, filename) {
    if (!window.Auth || !window.Auth.isAdmin()) {
      window.Auth?.gateAdmin(() => exportJSON(targetVar, filename));
      return;
    }
    if (!window[targetVar]) {
      toast(`No hay datos cargados para ${targetVar}`, 'error');
      return;
    }
    const payload = JSON.stringify(window[targetVar], null, 2);
    const content = `/* ${filename} — exportado ${new Date().toISOString()} */\nwindow.${targetVar} = ${payload};\n`;
    const blob = new Blob([content], { type: 'text/javascript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 100);
    window.Auth?.audit('export_json', `${targetVar} → ${filename}`);
    toast(`✓ ${filename} descargado`, 'ok');
  }

  // === Carga perezosa de archivos JS de datos ==============================
  const loadingScripts = new Map();
  /**
   * Carga un <script src> dinámicamente. Devuelve una Promise.
   * Cachea: una vez cargado, devuelve resuelto. Las promesas RECHAZADAS no se
   * cachean, para permitir reintento tras fallo de red.
   */
  function loadScript(src) {
    if (loadingScripts.has(src)) return loadingScripts.get(src);
    const p = new Promise((resolve, reject) => {
      // ¿Ya está en el DOM?
      if (document.querySelector(`script[src="${src}"]`)) {
        resolve(); return;
      }
      const s = document.createElement('script');
      s.src = src;
      s.async = true;
      s.onload = () => resolve();
      s.onerror = () => {
        // Limpiar el script roto del DOM para que el reintento agregue uno nuevo
        s.remove();
        reject(new Error(`No se pudo cargar ${src}`));
      };
      document.head.appendChild(s);
    });
    // Si falla, eliminar del cache para permitir reintento
    p.catch(() => loadingScripts.delete(src));
    loadingScripts.set(src, p);
    return p;
  }

  // === Toolbar admin renderizable (usado por M4/M6/M7/M8 SEDEM) ============
  /**
   * Renderiza HTML de botones admin (export/import/+ Nuevo) que el módulo
   * inserta en su header. Solo visible para admin.
   *   opts.withExcel: si true, incluye los botones de Excel y plantilla
   *   opts.showAddBtn: si false, oculta "+ Nuevo"
   */
  function renderAdminToolbar(targetVar, opts = {}) {
    if (!window.Auth || !window.Auth.isAdmin()) return '';
    const ns = opts.ns || targetVar.toLowerCase();
    return `
      <div class="rb-admin-tools" data-target="${targetVar}" data-ns="${ns}">
        ${opts.showAddBtn !== false ? `<button class="btn btn-ghost rb-admin-add" style="font-size:0.85rem;padding:6px 12px;">+ Nuevo</button>` : ''}
        <button class="btn btn-ghost rb-admin-export" style="font-size:0.85rem;padding:6px 12px;">⬇️ Exportar JSON</button>
        <button class="btn btn-ghost rb-admin-import" style="font-size:0.85rem;padding:6px 12px;">⬆️ Importar JSON</button>
        ${opts.withExcel ? `
          <button class="btn btn-ghost rb-admin-export-xlsx" style="font-size:0.85rem;padding:6px 12px;">📊 Exportar Excel</button>
          <button class="btn btn-ghost rb-admin-import-xlsx" style="font-size:0.85rem;padding:6px 12px;">📥 Importar Excel</button>
          <button class="btn btn-ghost rb-admin-template" style="font-size:0.85rem;padding:6px 12px;">📋 Plantilla Excel</button>
        ` : ''}
      </div>
    `;
  }

  /**
   * Conecta los botones admin generados por renderAdminToolbar.
   *  - filename: nombre del archivo .js que se descargará
   *  - onChange: callback para que el módulo re-renderice tras un cambio
   *  - onAdd:    callback opcional cuando se presiona "+ Nuevo"
   *  - excelOpts: si se pasó withExcel:true, configurar:
   *      { columns: [...], itemsKey: 'vademecum', sheetName, filenameXlsx, examples }
   */
  function bindAdminToolbar(container, opts) {
    if (!container) return;
    const targetVar = container.dataset.target;
    const ns = container.dataset.ns;
    const filename = opts.filename || `db_${ns}.js`;
    const onChange = opts.onChange || (() => {});
    const onAdd = opts.onAdd || (() => {});

    container.querySelector('.rb-admin-export')?.addEventListener('click', () => {
      exportJSON(targetVar, filename);
    });
    container.querySelector('.rb-admin-import')?.addEventListener('click', () => {
      importJSON(targetVar, () => {
        set(`db_override_${ns}`, window[targetVar]);
        onChange();
      });
    });
    container.querySelector('.rb-admin-add')?.addEventListener('click', () => {
      window.Auth?.gateAdmin(() => onAdd());
    });

    // === Botones Excel ===
    if (opts.excelOpts) {
      const ex = opts.excelOpts;
      const filenameXlsx = ex.filenameXlsx || filename.replace(/\.js$/, '.xlsx');

      container.querySelector('.rb-admin-export-xlsx')?.addEventListener('click', async () => {
        window.Auth?.gateAdmin(async () => {
          const db = window[targetVar];
          if (!db) { toast(`No hay datos cargados`, 'error'); return; }
          const items = ex.itemsKey ? db[ex.itemsKey] : db;
          if (!Array.isArray(items)) { toast(`Formato no compatible con Excel`, 'error'); return; }
          toast('Generando Excel...', 'info', 1500);
          const ok = await window.ExcelIO.export(items, {
            filename: filenameXlsx,
            sheetName: ex.sheetName || ns,
            columns: ex.columns,
          });
          if (ok) {
            toast(`✓ ${filenameXlsx} descargado`, 'ok');
            window.Auth?.audit('export_xlsx', `${targetVar} → ${filenameXlsx}`);
          }
        });
      });

      container.querySelector('.rb-admin-import-xlsx')?.addEventListener('click', () => {
        window.Auth?.gateAdmin(() => {
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = '.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          input.style.display = 'none';
          input.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            toast('Leyendo Excel...', 'info', 1500);
            try {
              const records = await window.ExcelIO.import(file, { columns: ex.columns });
              if (!records || records.length === 0) {
                toast('El Excel está vacío o no tiene las columnas esperadas', 'warn');
                return;
              }
              // Confirmar reemplazo o append
              const mode = window.confirm(
                `Se leyeron ${records.length} registros.\n\n` +
                `Aceptar = REEMPLAZAR los datos actuales\n` +
                `Cancelar = AÑADIR los nuevos a los existentes`
              ) ? 'replace' : 'append';

              const db = window[targetVar] || {};
              if (!db[ex.itemsKey]) db[ex.itemsKey] = [];
              // Asignar IDs nuevos a los que no tengan
              records.forEach((r, i) => {
                if (!r.id) r.id = ns.charAt(0).toUpperCase() + Date.now().toString(36).toUpperCase() + i;
              });

              if (mode === 'replace') {
                // Backup
                set(`backup_${targetVar}_${Date.now()}`, db[ex.itemsKey]);
                db[ex.itemsKey] = records;
              } else {
                db[ex.itemsKey] = db[ex.itemsKey].concat(records);
              }
              window[targetVar] = db;
              set(`db_override_${ns}`, db);
              toast(`✓ ${records.length} registros ${mode === 'replace' ? 'cargados' : 'añadidos'}`, 'ok');
              window.Auth?.audit('import_xlsx', `${targetVar} ← ${file.name} (${records.length} regs, ${mode})`);
              onChange();
            } catch (err) {
              toast('Error: ' + err.message, 'error', 5000);
              console.error(err);
            }
          });
          document.body.appendChild(input);
          input.click();
          setTimeout(() => input.remove(), 1000);
        });
      });

      container.querySelector('.rb-admin-template')?.addEventListener('click', async () => {
        toast('Generando plantilla...', 'info', 1500);
        const ok = await window.ExcelIO.downloadTemplate({
          filename: `plantilla_${ns}.xlsx`,
          sheetName: ex.sheetName || ns,
          columns: ex.columns,
          examples: ex.examples || [],
        });
        if (ok) {
          toast(`✓ plantilla_${ns}.xlsx descargada`, 'ok');
          window.Auth?.audit('download_template', `plantilla_${ns}.xlsx`);
        }
      });
    }
  }

  /**
   * Carga overrides admin de localStorage (si existen) sobre la BD original.
   * Se llama después de cargar el .js original del paquete.
   */
  function applyAdminOverride(targetVar, ns) {
    const stored = get(`db_override_${ns}`);
    if (stored && window[targetVar]) {
      window[targetVar] = stored;
      return true;
    }
    return false;
  }

  /**
   * Persiste el estado actual de una BD como override admin.
   */
  function persistAdminDB(targetVar, ns) {
    if (window[targetVar]) {
      set(`db_override_${ns}`, window[targetVar]);
    }
  }

  // === API pública =========================================================
  window.State = {
    get, set, remove,
    getActiveTab, setActiveTab,
    toast,
    importJSON, exportJSON,
    loadScript,
    renderAdminToolbar, bindAdminToolbar,
    applyAdminOverride, persistAdminDB,
  };
})();
