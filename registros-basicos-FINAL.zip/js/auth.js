/* ============================================================================
   auth.js — Autenticación simbólica con PBKDF2 (Web Crypto API)
   - La app es abierta para lectura.
   - Acciones críticas (exportar/importar/editar/eliminar JSON) requieren login.
   - La contraseña NUNCA se guarda en texto plano: solo el hash PBKDF2.
   - Sesión expira a los 30 min de inactividad.
   ============================================================================ */
(function () {
  'use strict';

  // === Configuración =======================================================
  const PBKDF2_ITERATIONS = 120000;        // ~OWASP 2023 mínimo razonable
  const SESSION_TTL_MS    = 30 * 60 * 1000; // 30 min
  const STORAGE_USER_DB   = 'rb_users_v1';
  const STORAGE_SESSION   = 'rb_session_v1';
  const STORAGE_AUDIT     = 'rb_audit_v1';

  // === Usuarios por defecto (al primer arranque) ===========================
  // Las contraseñas se hashean en el primer arranque, nunca quedan en texto plano.
  const DEFAULT_USERS = [
    { username: 'hacmed',         password: 'P4r4s1t0l0g1$', role: 'admin',     display: 'Administrador HACMED' },
    { username: 'CARLOS_MIRANDA', password: 'P4r4s1t0l0g1$', role: 'admin',     display: 'Carlos Miranda' },
    // Usuarios básicos solicitados (roles con permisos definidos en DB_AGENDA.rolePermissions)
    { username: 'BJA',            password: 'BJA',            role: 'bja',       display: 'Usuario BJA' },
    { username: 'NUTRICION',      password: 'NUTRICION',      role: 'nutricion', display: 'Usuario Nutrición' },
  ];

  // === Utilidades criptográficas ===========================================
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  function toHex(buffer) {
    return Array.from(new Uint8Array(buffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  function randomSalt(bytes = 16) {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return toHex(arr.buffer);
  }

  async function hashPassword(password, saltHex) {
    const saltBytes = new Uint8Array(saltHex.match(/.{2}/g).map(b => parseInt(b, 16)));
    const key = await crypto.subtle.importKey(
      'raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']
    );
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: saltBytes, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
      key, 256
    );
    return toHex(bits);
  }

  // === Inicialización: hash de usuarios por defecto =========================
  async function initUserDB() {
    const existing = localStorage.getItem(STORAGE_USER_DB);
    if (existing) {
      try {
        return JSON.parse(existing);
      } catch (e) {
        console.warn('[auth] BD de usuarios corrupta, regenerando');
      }
    }
    // Si hay una semilla pre-generada (js/users-seed.js), usarla tal cual
    // (ya tiene hashes). Permite desplegar usuarios "de fábrica" al servidor.
    if (window.RB_USERS_SEED && Array.isArray(window.RB_USERS_SEED) && window.RB_USERS_SEED.length) {
      localStorage.setItem(STORAGE_USER_DB, JSON.stringify(window.RB_USERS_SEED));
      return window.RB_USERS_SEED;
    }
    // Primera vez: hashear contraseñas por defecto
    const users = [];
    for (const u of DEFAULT_USERS) {
      const salt = randomSalt();
      const hash = await hashPassword(u.password, salt);
      users.push({
        username: u.username,
        role:     u.role,
        display:  u.display,
        salt,
        hash,
        created:  Date.now(),
      });
    }
    localStorage.setItem(STORAGE_USER_DB, JSON.stringify(users));
    return users;
  }

  // === Audit log ============================================================
  function audit(action, detail = '') {
    let log = [];
    try { log = JSON.parse(localStorage.getItem(STORAGE_AUDIT) || '[]'); } catch (e) {}
    log.push({
      ts:     new Date().toISOString(),
      user:   getCurrentUser()?.username || '(anon)',
      action,
      detail: String(detail).slice(0, 300),
    });
    // Limita el log a últimas 500 entradas
    if (log.length > 500) log = log.slice(-500);
    localStorage.setItem(STORAGE_AUDIT, JSON.stringify(log));
  }

  function getAuditLog() {
    try { return JSON.parse(localStorage.getItem(STORAGE_AUDIT) || '[]'); }
    catch (e) { return []; }
  }

  // === Sesión (SOLO EN MEMORIA) ============================================
  // Decisión: la sesión admin NO se persiste. Al actualizar/recargar la página
  // o cerrar la pestaña, el modo admin se cierra automáticamente. Esto es más
  // seguro para un dispositivo compartido (ej. una tablet en consultorio).
  let memorySession = null;

  function getCurrentUser() {
    if (!memorySession) return null;
    const now = Date.now();
    if (memorySession.lastActivity > now) memorySession.lastActivity = now;
    if (now - memorySession.lastActivity > SESSION_TTL_MS) {
      memorySession = null;
      return null;
    }
    return memorySession;
  }

  function touchSession() {
    if (memorySession) memorySession.lastActivity = Date.now();
  }

  function logout() {
    const u = getCurrentUser();
    if (u) audit('logout');
    memorySession = null;
    updateUI();
    document.dispatchEvent(new CustomEvent('rb:auth-changed', { detail: { user: null } }));
  }

  async function login(username, password, opts = {}) {
    const users = await initUserDB();
    const u = users.find(x => x.username === username);
    if (!u) return { ok: false, error: 'Usuario no encontrado' };
    const candidate = await hashPassword(password, u.salt);
    if (candidate !== u.hash) {
      audit('login_failed', username);
      return { ok: false, error: 'Contraseña incorrecta' };
    }
    // El login público (visible en Inicio) NO admite cuentas admin (modo DIOS).
    // El modo DIOS solo se abre por el gesto oculto.
    if (opts.publicOnly && u.role === 'admin') {
      audit('login_blocked_admin_public', username);
      return { ok: false, error: 'Esta cuenta debe ingresar por la vía de administrador' };
    }
    memorySession = {
      username: u.username,
      role:     u.role,
      display:  u.display,
      loginAt:  Date.now(),
      lastActivity: Date.now(),
    };
    audit('login_ok');
    updateUI();
    document.dispatchEvent(new CustomEvent('rb:auth-changed', { detail: { user: memorySession } }));
    return { ok: true, user: memorySession };
  }

  // === UI: modal de login ===================================================
  function buildModal() {
    if (document.getElementById('auth-modal')) return;
    const html = `
      <div class="modal-backdrop" id="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title">
        <div class="modal">
          <div class="modal-h">
            <h2 id="auth-title">Acceso administrativo</h2>
            <p>Esta acción requiere autenticación. Solo el rol administrador puede modificar archivos JSON.</p>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label" for="auth-user">Usuario</label>
              <input class="field-input" type="text" id="auth-user" autocomplete="username" autofocus />
            </div>
            <div class="field">
              <label class="field-label" for="auth-pass">Contraseña</label>
              <input class="field-input" type="password" id="auth-pass" autocomplete="current-password" />
              <div class="field-error" id="auth-error"></div>
            </div>
            <p class="tiny muted">
              Aviso: este login restringe vista casual al menú admin. No es protección
              criptográfica de grado bancario — el código se ejecuta en el navegador.
            </p>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn btn-ghost" id="auth-cancel">Cancelar</button>
            <button type="button" class="btn btn-primary" id="auth-submit">Ingresar</button>
          </div>
        </div>
      </div>`;
    document.body.insertAdjacentHTML('beforeend', html);

    const modal = document.getElementById('auth-modal');
    const userEl = document.getElementById('auth-user');
    const passEl = document.getElementById('auth-pass');
    const errEl  = document.getElementById('auth-error');

    const submit = async () => {
      errEl.textContent = '';
      const u = userEl.value.trim();
      const p = passEl.value;
      if (!u || !p) { errEl.textContent = 'Completa usuario y contraseña'; return; }
      const btn = document.getElementById('auth-submit');
      btn.disabled = true; btn.textContent = 'Verificando…';
      const res = await login(u, p);
      btn.disabled = false; btn.textContent = 'Ingresar';
      if (!res.ok) {
        errEl.textContent = res.error;
        passEl.select();
        return;
      }
      modal.classList.remove('is-open');
      passEl.value = '';
      // Ejecuta el callback pendiente
      if (pendingCallback) {
        const cb = pendingCallback;
        pendingCallback = null;
        cb();
      }
    };

    document.getElementById('auth-submit').addEventListener('click', submit);
    document.getElementById('auth-cancel').addEventListener('click', () => {
      modal.classList.remove('is-open');
      pendingCallback = null;
      passEl.value = '';
      errEl.textContent = '';
    });
    passEl.addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
    userEl.addEventListener('keydown', e => { if (e.key === 'Enter') passEl.focus(); });
  }

  let pendingCallback = null;

  /**
   * Pide login si no hay sesión activa, ejecuta el callback al éxito.
   * Uso: Auth.gateAdmin(() => exportarJSON());
   */
  function gateAdmin(callback) {
    const u = getCurrentUser();
    if (u && u.role === 'admin') {
      touchSession();
      callback();
      return;
    }
    buildModal();
    pendingCallback = callback;
    const modal = document.getElementById('auth-modal');
    modal.classList.add('is-open');
    setTimeout(() => document.getElementById('auth-user')?.focus(), 100);
  }

  // === UI: indicador de sesión en header (DISCRETO) =========================
  function updateUI() {
    const el = document.getElementById('auth-status');
    if (!el) return;
    const u = getCurrentUser();
    if (u) {
      // Sesión activa: nombre + botón salir
      const esAdmin = u.role === 'admin';
      el.innerHTML = `
        <span class="badge ${esAdmin ? 'badge-clinic' : 'badge-mute'}" title="Sesión activa: ${escapeHtml(u.display)}">
          ${esAdmin ? `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-right:3px;vertical-align:-1px;"><path d="M12 2L4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z"/></svg>` : '👤 '}
          ${escapeHtml(u.display)}
        </span>
        <button class="btn btn-ghost" id="auth-logout-btn" style="padding:6px 10px;font-size:0.8rem">Salir</button>
      `;
      document.getElementById('auth-logout-btn')?.addEventListener('click', logout);
    } else {
      // SIN sesión: login compacto visible al lado del buscador (solo usuarios
      // normales; el modo DIOS se rechaza por publicOnly y entra por gesto oculto).
      el.innerHTML = `
        <div class="hdr-login">
          <input type="text" class="hdr-login-user" placeholder="Usuario" autocomplete="username" />
          <input type="password" class="hdr-login-pass" placeholder="Clave" autocomplete="current-password" />
          <button class="btn btn-primary hdr-login-btn" style="padding:6px 12px;font-size:0.8rem;">Entrar</button>
        </div>
      `;
      const doLogin = async () => {
        const user = el.querySelector('.hdr-login-user')?.value.trim();
        const pass = el.querySelector('.hdr-login-pass')?.value;
        if (!user || !pass) { window.State?.toast('Completa usuario y contraseña', 'warn'); return; }
        const res = await login(user, pass, { publicOnly: true });
        if (!res.ok) { window.State?.toast(res.error, 'error'); return; }
        window.State?.toast(`✓ Bienvenido, ${res.user.display || res.user.username}`, 'ok');
      };
      el.querySelector('.hdr-login-btn')?.addEventListener('click', doLogin);
      el.querySelector('.hdr-login-pass')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); });
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  // === Renovar timestamp en cada interacción del admin =====================
  ['click', 'keydown'].forEach(evt => {
    document.addEventListener(evt, () => {
      if (getCurrentUser()) touchSession();
    }, { passive: true });
  });

  // === TRIGGERS OCULTOS PARA ABRIR EL MODAL ADMIN ==========================
  //  (a) 3 taps/clicks rápidos en el logo "R" (móvil y desktop)
  //  (b) Long-press de 1500ms en el logo (móvil)
  //  (c) Atajo de teclado Ctrl+Shift+A (desktop)
  function setupHiddenTriggers() {
    // Delegación a document: funciona aunque #brand-trigger se cree después.
    let tapCount = 0;
    let tapTimer = null;
    let longPressTimer = null;
    let longPressFired = false;
    let lastTapTime = 0;

    function isBrand(target) {
      return target && target.closest && target.closest('#brand-trigger');
    }

    function registerTap() {
      if (getCurrentUser()) return;
      const now = Date.now();
      // Reiniciar si pasó demasiado tiempo desde el último toque
      if (now - lastTapTime > 1500) tapCount = 0;
      lastTapTime = now;
      tapCount++;
      clearTimeout(tapTimer);
      tapTimer = setTimeout(() => { tapCount = 0; }, 1600);
      if (tapCount >= 5) {
        tapCount = 0;
        clearTimeout(tapTimer);
        if (navigator.vibrate) navigator.vibrate([20, 40, 20]);
        gateAdmin(() => {});
      }
    }

    // En MÓVIL contamos en touchend (más fiable que click sobre divs anidados).
    // Marcamos para que el click posterior no duplique el conteo.
    let touchHandled = false;
    document.addEventListener('touchend', (e) => {
      cancelLong();
      if (!isBrand(e.target)) return;
      if (longPressFired) { longPressFired = false; touchHandled = true; setTimeout(() => { touchHandled = false; }, 600); return; }
      touchHandled = true;
      setTimeout(() => { touchHandled = false; }, 600);
      registerTap();
    });

    // En DESKTOP (y respaldo) contamos en click, salvo que ya lo manejó touch.
    document.addEventListener('click', (e) => {
      if (touchHandled) return;
      if (longPressFired) { longPressFired = false; return; }
      if (isBrand(e.target)) registerTap();
    });

    // Long-press en móvil (mantener 900 ms sobre la marca)
    document.addEventListener('touchstart', (e) => {
      if (!isBrand(e.target)) return;
      if (getCurrentUser()) return;
      longPressFired = false;
      clearTimeout(longPressTimer);
      longPressTimer = setTimeout(() => {
        longPressFired = true;
        if (navigator.vibrate) navigator.vibrate(40);
        gateAdmin(() => {});
      }, 900);
    }, { passive: true });
    function cancelLong() { clearTimeout(longPressTimer); }
    document.addEventListener('touchmove', cancelLong, { passive: true });
    document.addEventListener('touchcancel', cancelLong);

    // Evitar menú contextual al mantener presionado sobre la marca (móvil)
    document.addEventListener('contextmenu', (e) => {
      if (isBrand(e.target)) e.preventDefault();
    });

    // Atajo de teclado: Ctrl+Shift+A o Cmd+Shift+A (desktop)
    document.addEventListener('keydown', (e) => {
      const isShortcut = (e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a');
      if (isShortcut) {
        e.preventDefault();
        if (!getCurrentUser()) gateAdmin(() => {});
      }
    });
  }

  // === Inicializar al cargar ===============================================
  document.addEventListener('DOMContentLoaded', async () => {
    await initUserDB();
    updateUI();
    buildModal();
    setupHiddenTriggers();
  });

  // === Gestión de usuarios (CRUD) ==========================================
  // NOTA: organizativo, no seguridad real (todo está en el navegador).
  function listUsers() {
    try {
      const u = JSON.parse(localStorage.getItem(STORAGE_USER_DB) || '[]');
      // No exponer hash/salt al exterior salvo lo necesario
      return u.map(x => ({ username: x.username, role: x.role, display: x.display, created: x.created }));
    } catch (e) { return []; }
  }

  async function createUser({ username, password, role, display }) {
    if (!username || !password) return { ok: false, error: 'Usuario y contraseña requeridos' };
    await initUserDB();  // asegura que existan los usuarios por defecto
    let users = [];
    try { users = JSON.parse(localStorage.getItem(STORAGE_USER_DB) || '[]'); } catch (e) {}
    if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
      return { ok: false, error: 'Ese usuario ya existe' };
    }
    const salt = randomSalt();
    const hash = await hashPassword(password, salt);
    users.push({ username, role: role || 'editor', display: display || username, salt, hash, created: Date.now() });
    localStorage.setItem(STORAGE_USER_DB, JSON.stringify(users));
    audit('user_create', `${username} (${role})`);
    return { ok: true };
  }

  async function updateUser(username, { password, role, display }) {
    let users = [];
    try { users = JSON.parse(localStorage.getItem(STORAGE_USER_DB) || '[]'); } catch (e) {}
    const u = users.find(x => x.username === username);
    if (!u) return { ok: false, error: 'Usuario no encontrado' };
    if (role) u.role = role;
    if (display) u.display = display;
    if (password) { u.salt = randomSalt(); u.hash = await hashPassword(password, u.salt); }
    localStorage.setItem(STORAGE_USER_DB, JSON.stringify(users));
    audit('user_update', username);
    return { ok: true };
  }

  function deleteUser(username) {
    let users = [];
    try { users = JSON.parse(localStorage.getItem(STORAGE_USER_DB) || '[]'); } catch (e) {}
    const admins = users.filter(u => u.role === 'admin');
    const target = users.find(u => u.username === username);
    if (target && target.role === 'admin' && admins.length <= 1) {
      return { ok: false, error: 'No puedes eliminar el último administrador' };
    }
    users = users.filter(u => u.username !== username);
    localStorage.setItem(STORAGE_USER_DB, JSON.stringify(users));
    audit('user_delete', username);
    return { ok: true };
  }

  function clearAuditLog() {
    localStorage.setItem(STORAGE_AUDIT, '[]');
    audit('audit_cleared');
  }

  // Respaldo de usuarios (incluye hashes y salts, NO contraseñas en claro)
  function exportUsers() {
    let users = [];
    try { users = JSON.parse(localStorage.getItem(STORAGE_USER_DB) || '[]'); } catch (e) {}
    const payload = {
      _app: 'Registros Básicos', _type: 'backup-users', _version: 1,
      _fecha: new Date().toISOString(), _count: users.length, users,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `registros-basicos-usuarios_${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 100);
    window.State?.toast(`✓ ${users.length} usuarios respaldados`, 'ok');
    audit('users_export', `${users.length} usuarios`);
  }

  function importUsers() {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = '.json,application/json'; input.style.display = 'none';
    input.addEventListener('change', async (e) => {
      const file = e.target.files[0]; if (!file) return;
      try {
        const payload = JSON.parse(await file.text());
        if (payload._type !== 'backup-users' || !Array.isArray(payload.users)) {
          throw new Error('Archivo de usuarios no válido');
        }
        // Validar estructura mínima
        const valid = payload.users.every(u => u.username && u.hash && u.salt && u.role);
        if (!valid) throw new Error('El archivo tiene usuarios con formato incorrecto');
        if (!payload.users.some(u => u.role === 'admin')) {
          throw new Error('El respaldo no contiene ningún administrador — no se puede restaurar');
        }
        if (!window.confirm(`Restaurar ${payload.users.length} usuarios del ${new Date(payload._fecha).toLocaleString('es-BO')}?\nEsto reemplaza TODOS los usuarios actuales.`)) return;
        localStorage.setItem(STORAGE_USER_DB, JSON.stringify(payload.users));
        audit('users_import', `${payload.users.length} usuarios`);
        window.State?.toast('✓ Usuarios restaurados', 'ok');
        document.dispatchEvent(new CustomEvent('rb:auth-changed'));
      } catch (err) {
        window.State?.toast('Error: ' + err.message, 'error', 5000);
      }
    });
    document.body.appendChild(input); input.click();
    setTimeout(() => input.remove(), 1000);
  }

  // === Exportar API =========================================================
  window.Auth = {
    gateAdmin,
    getCurrentUser,
    logout,
    audit,
    getAuditLog,
    clearAuditLog,
    exportUsers,
    importUsers,
    isAdmin: () => getCurrentUser()?.role === 'admin',
    login,
    // Gestión de usuarios
    listUsers,
    createUser,
    updateUser,
    deleteUser,
  };
})();
