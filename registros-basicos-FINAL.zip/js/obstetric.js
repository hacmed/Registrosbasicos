/* ============================================================================
   obstetric.js — Utilidades obstétricas compartidas (M3 + M8)
   - Cálculo de edad gestacional bidireccional FUM ↔ SG ↔ FPP
   - Regla de Naegele (FUM + 280 días)
   - Regla de Parikh (ciclos irregulares)
   - Regla de Wahl (FUM + 10 días, restar 3 meses, +1 año)
   - Tablas de ganancia de peso recomendada según IMC pregestacional (IOM 2009)
   ============================================================================ */
(function () {
  'use strict';

  const GESTATION_DAYS = 280;  // 40 semanas

  // === Fechas en UTC =========================================================
  function isoToDate(iso) {
    if (!iso) return null;
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    if (!m) return null;
    const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
    return isNaN(d.getTime()) ? null : d;
  }

  function dateToISO(date) {
    if (!date || isNaN(date.getTime())) return '';
    const y = date.getUTCFullYear();
    const m = String(date.getUTCMonth() + 1).padStart(2, '0');
    const d = String(date.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  function addDays(date, days) {
    return new Date(date.getTime() + days * 86400000);
  }

  function diffDays(a, b) {
    return Math.round((a.getTime() - b.getTime()) / 86400000);
  }

  function todayUTC() {
    const n = new Date();
    return new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()));
  }

  // === Cálculos =============================================================
  /**
   * Edad gestacional en semanas desde FUM hasta fecha de referencia (CPN o hoy)
   * @returns {weeks, days, totalDays, fraction} o null
   */
  function calcEG(fum, refDate) {
    if (!fum) return null;
    const ref = refDate || todayUTC();
    const d = diffDays(ref, fum);
    if (d < 0) return null;
    return {
      totalDays: d,
      weeks: Math.floor(d / 7),
      days: d % 7,
      fraction: d / 7,
    };
  }

  /**
   * Regla de Naegele: FUM + 280 días = FPP estándar (ciclo 28 días)
   */
  function fppNaegele(fum) {
    if (!fum) return null;
    return addDays(fum, GESTATION_DAYS);
  }

  /**
   * Regla de Parikh: ajuste por ciclos irregulares.
   * FPP = FUM + 280 + (longitud ciclo - 28)
   * @param cicloDias longitud del ciclo en días (típico 21-35)
   */
  function fppParikh(fum, cicloDias) {
    if (!fum || !cicloDias) return null;
    return addDays(fum, GESTATION_DAYS + (cicloDias - 28));
  }

  /**
   * Regla de Wahl: variante alemana — FUM + 7 días + 9 meses calendario
   * (algunos textos la describen como FUM + 10 días - 3 meses + 1 año)
   */
  function fppWahl(fum) {
    if (!fum) return null;
    const y = fum.getUTCFullYear() + 1;
    const m = fum.getUTCMonth() - 3;
    const d = fum.getUTCDate() + 10;
    // Normalizar meses negativos
    const baseDate = new Date(Date.UTC(y, m, d));
    return baseDate;
  }

  /**
   * Calcular FUM aproximada desde la edad gestacional ecográfica
   * @param sgWeeks semanas (puede ser decimal)
   * @param ecoDate fecha de la ecografía
   */
  function fumFromEcoSG(sgWeeks, ecoDate) {
    if (!sgWeeks || !ecoDate) return null;
    return addDays(ecoDate, -Math.round(sgWeeks * 7));
  }

  // === Tabla de ganancia de peso recomendada (IOM 2009 + Bolivia SAFCI) ====
  /**
   * Devuelve la categoría IMC pregestacional y el rango de ganancia esperada.
   */
  function gananciaSegunIMC(imcPregestacional, embarazoMultiple = false, tallaBaja = false) {
    if (!imcPregestacional) return null;
    let cat, rango;
    if (imcPregestacional < 18.5) {
      cat = { label: 'Bajo peso', tier: 'warn' };
      rango = embarazoMultiple ? { min: 17.0, max: 25.0 } : { min: 12.5, max: 18.0 };
    } else if (imcPregestacional < 25) {
      cat = { label: 'Peso normal', tier: 'ok' };
      rango = embarazoMultiple ? { min: 16.8, max: 24.5 } : { min: 11.5, max: 16.0 };
    } else if (imcPregestacional < 30) {
      cat = { label: 'Sobrepeso', tier: 'warn' };
      rango = embarazoMultiple ? { min: 14.1, max: 22.7 } : { min: 7.0, max: 11.5 };
    } else {
      cat = { label: 'Obesidad', tier: 'alert' };
      rango = embarazoMultiple ? { min: 11.3, max: 19.1 } : { min: 5.0, max: 9.0 };
    }
    // Ajuste talla baja (< 1.57 m): -25% al límite superior (lineamiento Bolivia SAFCI)
    if (tallaBaja) {
      rango = { ...rango, max: rango.max * 0.85 };
      cat.label += ' (talla baja)';
    }
    return { cat, rango, embarazoMultiple, tallaBaja };
  }

  /**
   * Ganancia semanal esperada en el 2do y 3er trimestre (kg/semana)
   * Aproximación: en el 1er trim (0-12s) se gana ~0.5-2 kg total;
   * el resto se gana en los 28 semanas restantes (de la sem 13 a 40).
   */
  function gananciaSemanal(imcCat, weeksGestation) {
    if (!imcCat || weeksGestation == null) return null;
    const t1Total = imcCat === 'Bajo peso' ? 2.0
                  : imcCat === 'Peso normal' ? 1.5
                  : imcCat === 'Sobrepeso' ? 1.0
                  : 0.5;
    const rates = {  // kg/semana 2do-3er trimestre
      'Bajo peso':    0.5,
      'Peso normal':  0.4,
      'Sobrepeso':    0.28,
      'Obesidad':     0.22,
    };
    return { t1Total, ratePerWeek: rates[imcCat] || null };
  }

  // === Altura uterina (percentilos referenciales) ==========================
  /**
   * Altura uterina esperada según semanas de gestación.
   * Referencia: curva de Belizán/Fescina (CLAP/OPS Latinoamérica).
   */
  const AU_REFERENCE = {
    13: { p10: 8,  p50: 10,  p90: 12 },
    14: { p10: 8,  p50: 11,  p90: 13 },
    15: { p10: 10, p50: 12,  p90: 14 },
    16: { p10: 11, p50: 13,  p90: 15 },
    17: { p10: 12, p50: 14,  p90: 16 },
    18: { p10: 13, p50: 15,  p90: 17 },
    19: { p10: 14, p50: 16,  p90: 18 },
    20: { p10: 15, p50: 17,  p90: 19 },
    21: { p10: 16, p50: 18,  p90: 20 },
    22: { p10: 17, p50: 19,  p90: 21 },
    23: { p10: 18, p50: 20,  p90: 22 },
    24: { p10: 19, p50: 21,  p90: 23 },
    25: { p10: 20, p50: 22,  p90: 24 },
    26: { p10: 21, p50: 23,  p90: 25 },
    27: { p10: 22, p50: 24,  p90: 26 },
    28: { p10: 23, p50: 25,  p90: 27 },
    29: { p10: 24, p50: 26,  p90: 28 },
    30: { p10: 25, p50: 27,  p90: 29 },
    31: { p10: 26, p50: 28,  p90: 30 },
    32: { p10: 27, p50: 29,  p90: 31 },
    33: { p10: 28, p50: 30,  p90: 32 },
    34: { p10: 29, p50: 31,  p90: 33 },
    35: { p10: 30, p50: 32,  p90: 34 },
    36: { p10: 30, p50: 33,  p90: 35 },
    37: { p10: 31, p50: 34,  p90: 36 },
    38: { p10: 31, p50: 34,  p90: 37 },
    39: { p10: 32, p50: 35,  p90: 37 },
    40: { p10: 32, p50: 35,  p90: 38 },
  };

  function clasifAlturaUterina(weeks, au) {
    if (!weeks || au == null) return null;
    const w = Math.round(weeks);
    const ref = AU_REFERENCE[w];
    if (!ref) return null;
    if (au < ref.p10) return { tier: 'alert', label: 'Por debajo del p10 (RCIU?)', ref };
    if (au > ref.p90) return { tier: 'warn', label: 'Por encima del p90 (macrosomía/poli?)', ref };
    return { tier: 'ok', label: 'Normal (entre p10 y p90)', ref };
  }

  // === API pública ==========================================================
  window.Obstetric = {
    GESTATION_DAYS,
    // fechas
    isoToDate, dateToISO, addDays, diffDays, todayUTC,
    // cálculos
    calcEG,
    fppNaegele, fppParikh, fppWahl, fumFromEcoSG,
    gananciaSegunIMC, gananciaSemanal,
    clasifAlturaUterina,
    AU_REFERENCE,
  };
})();
