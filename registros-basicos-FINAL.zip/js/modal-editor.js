/* ============================================================================
   modal-editor.js — Componente modal de edición compartido (Fase D)

   Reemplaza los prompt() simples por un modal con TODOS los campos de cada
   registro. Soporta:
     - text (input)
     - textarea (multilinea)
     - number
     - select (con opciones)
     - tags (array de strings, ej. CIE-10)
     - list (array de objetos, ej. prestaciones — sub-editor)

   API:
     ModalEditor.open({
       title: 'Editar fármaco',
       schema: [
         { key: 'medicamento', label: 'Nombre genérico', type: 'text', required: true },
         { key: 'forma',       label: 'Forma',           type: 'text' },
         { key: 'mecanismo_fc', label: 'Mecanismo de acción', type: 'textarea', rows: 4 },
         { key: 'cie10',       label: 'CIE-10',          type: 'tags' },
         { key: 'prestaciones',label: 'Prestaciones',    type: 'list',
           itemSchema: [
             { key: 'tratamiento_prestacion', label: 'Tratamiento', type: 'textarea' },
             { key: 'observaciones',          label: 'Observaciones', type: 'textarea' },
           ],
         },
       ],
       data: { ...registroExistente },   // o {} para nuevo
       onSave: (data) => { ... },
       onCancel: () => { ... },
     });
   ============================================================================ */
(function () {
  'use strict';

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }
  function uid() { return 'me' + Date.now().toString(36) + Math.random().toString(36).slice(2,5); }

  // === Render de un campo individual =======================================
  function renderField(field, value, idPrefix) {
    const id = `${idPrefix}-${field.key}`;
    const val = value != null ? value : (field.default != null ? field.default : '');
    const required = field.required ? 'required' : '';
    const requiredMark = field.required ? '<span class="me-req">*</span>' : '';
    const help = field.help ? `<span class="tiny muted">${esc(field.help)}</span>` : '';

    switch (field.type) {
      case 'textarea': {
        const rows = field.rows || 3;
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <textarea id="${id}" data-key="${field.key}" data-type="textarea"
                      rows="${rows}" class="field-input me-textarea" ${required}>${esc(val)}</textarea>
            ${help}
          </label>
        `;
      }
      case 'number':
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <input type="number" id="${id}" data-key="${field.key}" data-type="number"
                   value="${esc(val)}" class="field-input"
                   ${field.min != null ? `min="${field.min}"` : ''}
                   ${field.max != null ? `max="${field.max}"` : ''}
                   ${field.step != null ? `step="${field.step}"` : ''}
                   ${required}/>
            ${help}
          </label>
        `;
      case 'select': {
        const options = (field.options || []).map(opt => {
          if (typeof opt === 'string') {
            return `<option value="${esc(opt)}" ${opt === val ? 'selected' : ''}>${esc(opt)}</option>`;
          }
          return `<option value="${esc(opt.value)}" ${opt.value === val ? 'selected' : ''}>${esc(opt.label)}</option>`;
        }).join('');
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <select id="${id}" data-key="${field.key}" data-type="select" class="field-select" ${required}>
              ${field.allowEmpty !== false ? '<option value="">—</option>' : ''}
              ${options}
            </select>
            ${help}
          </label>
        `;
      }
      case 'info': {
        return `<div class="me-field me-info">${esc(field.text || '')}</div>`;
      }
      case 'time': {
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <input type="time" id="${id}" data-key="${field.key}" data-type="time"
                   value="${esc(val)}" class="field-input" ${required}/>
            ${help}
          </label>
        `;
      }
      case 'date': {
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <input type="date" id="${id}" data-key="${field.key}" data-type="date"
                   value="${esc(val)}" class="field-input" ${required}/>
            ${help}
          </label>
        `;
      }
      case 'weekdays': {
        const DAYS = [
          { v: 'lunes', l: 'Lun' }, { v: 'martes', l: 'Mar' }, { v: 'miércoles', l: 'Mié' },
          { v: 'jueves', l: 'Jue' }, { v: 'viernes', l: 'Vie' }, { v: 'sábado', l: 'Sáb' }, { v: 'domingo', l: 'Dom' },
        ];
        const selected = Array.isArray(val) ? val : [];
        return `
          <div class="me-field" data-key="${field.key}" data-type="weekdays">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <div class="me-weekdays">
              ${DAYS.map(d => `
                <label class="me-weekday ${selected.includes(d.v) ? 'is-on' : ''}">
                  <input type="checkbox" value="${d.v}" ${selected.includes(d.v) ? 'checked' : ''}/>
                  <span>${d.l}</span>
                </label>
              `).join('')}
            </div>
            ${help}
          </div>
        `;
      }
      case 'tags': {
        const arr = Array.isArray(val) ? val : (val ? String(val).split(/[,;]/).map(s=>s.trim()).filter(Boolean) : []);
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <input type="text" id="${id}" data-key="${field.key}" data-type="tags"
                   value="${esc(arr.join(', '))}" class="field-input"
                   placeholder="Separar con comas..." />
            ${help || `<span class="tiny muted">Separa los valores con comas. Ej: A06, A06.0, A06.9</span>`}
          </label>
        `;
      }
      case 'list': {
        // Sub-editor para listas anidadas (ej. prestaciones)
        const items = Array.isArray(val) ? val : [];
        return `
          <div class="me-field me-list" data-key="${field.key}" data-type="list">
            <div class="me-label-row">
              <span class="me-label">${esc(field.label)}${requiredMark}
                <span class="badge badge-mute tiny">${items.length}</span>
              </span>
              <button type="button" class="btn btn-ghost me-list-add" style="font-size:0.8rem;padding:4px 10px;">+ Añadir línea</button>
            </div>
            <div class="me-list-items" data-id="${id}">
              ${items.map((item, idx) => renderListItem(field.itemSchema, item, idx)).join('')}
              ${items.length === 0 ? '<p class="tiny muted me-list-empty">Sin elementos. Pulsa "+ Añadir línea".</p>' : ''}
            </div>
            ${help}
          </div>
        `;
      }
      default:  // text
        return `
          <label class="me-field">
            <span class="me-label">${esc(field.label)}${requiredMark}</span>
            <input type="text" id="${id}" data-key="${field.key}" data-type="text"
                   value="${esc(val)}" class="field-input" ${required}/>
            ${help}
          </label>
        `;
    }
  }

  function renderListItem(itemSchema, item, idx) {
    return `
      <div class="me-list-item" data-idx="${idx}">
        <div class="me-list-item-h">
          <span class="me-list-item-num">${idx + 1}</span>
          <button type="button" class="me-list-item-del" title="Eliminar línea">×</button>
        </div>
        <div class="me-list-item-body">
          ${itemSchema.map(f => renderField(f, item[f.key], `li-${idx}`)).join('')}
        </div>
      </div>
    `;
  }

  // === Lectura de valores desde el DOM =====================================
  function readField(container, field) {
    if (field.type === 'info') return undefined;
    const sel = `[data-key="${field.key}"][data-type="${field.type || 'text'}"]`;
    const el = container.querySelector(sel);
    if (!el) return undefined;
    if (field.type === 'number') {
      const v = parseFloat(el.value);
      return isNaN(v) ? null : v;
    }
    if (field.type === 'tags') {
      return (el.value || '').split(/[,;]/).map(s => s.trim()).filter(Boolean);
    }
    if (field.type === 'weekdays') {
      return Array.from(el.querySelectorAll('input[type="checkbox"]:checked')).map(c => c.value);
    }
    if (field.type === 'list') {
      const items = [];
      el.querySelectorAll('.me-list-item').forEach(itemEl => {
        const item = {};
        for (const f of field.itemSchema) {
          item[f.key] = readField(itemEl, f);
        }
        items.push(item);
      });
      return items;
    }
    return el.value || '';
  }

  // === Apertura del modal ==================================================
  function open({ title, schema, data, onSave, onCancel, size, extraButtons }) {
    data = data || {};
    const idPrefix = uid();
    const modalEl = document.createElement('div');
    modalEl.className = 'me-overlay';

    const fieldsHTML = schema.map(f => renderField(f, data[f.key], idPrefix)).join('');

    const extraBtnsHTML = (extraButtons || []).map((b, i) =>
      `<button type="button" class="btn btn-ghost me-extra" data-extra="${i}">${esc(b.label)}</button>`
    ).join('');

    modalEl.innerHTML = `
      <div class="me-modal me-modal-${size || 'lg'}" role="dialog" aria-modal="true" aria-labelledby="${idPrefix}-title">
        <div class="me-modal-h">
          <h2 id="${idPrefix}-title">${esc(title)}</h2>
          <button type="button" class="me-close" aria-label="Cerrar">×</button>
        </div>
        <form class="me-body" id="${idPrefix}-form">
          ${fieldsHTML}
        </form>
        <div class="me-modal-foot">
          <button type="button" class="btn btn-ghost me-cancel">Cancelar</button>
          ${extraBtnsHTML}
          <button type="button" class="btn btn-primary me-save">Guardar</button>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl);
    document.body.classList.add('me-locked');
    // Focus primer campo
    setTimeout(() => {
      const first = modalEl.querySelector('input, textarea, select');
      first?.focus();
    }, 50);

    function close(result) {
      document.body.removeChild(modalEl);
      document.body.classList.remove('me-locked');
      if (result === 'cancel' && onCancel) onCancel();
    }

    function readAll() {
      const form = modalEl.querySelector(`#${idPrefix}-form`);
      const out = {};
      for (const field of schema) {
        out[field.key] = readField(form, field);
      }
      return out;
    }

    function validate() {
      for (const field of schema) {
        if (!field.required) continue;
        const val = readField(modalEl, field);
        if (val == null || val === '' || (Array.isArray(val) && val.length === 0)) {
          window.State?.toast(`Campo requerido: ${field.label}`, 'warn');
          const el = modalEl.querySelector(`[data-key="${field.key}"]`);
          el?.focus();
          return false;
        }
      }
      return true;
    }

    // Bindings
    modalEl.querySelector('.me-close')?.addEventListener('click', () => close('cancel'));
    modalEl.querySelector('.me-cancel')?.addEventListener('click', () => close('cancel'));
    // Botones extra (ej. vista previa) — no cierran el modal
    modalEl.querySelectorAll('.me-extra').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.extra);
        const eb = (extraButtons || [])[idx];
        if (eb && eb.onClick) {
          try { eb.onClick(readAll()); } catch (e) { console.error(e); }
        }
      });
    });
    modalEl.querySelector('.me-save')?.addEventListener('click', () => {
      if (!validate()) return;
      const result = readAll();
      try {
        onSave && onSave(result);
        close('save');
      } catch (e) {
        console.error('[ModalEditor] onSave threw:', e);
        window.State?.toast('Error al guardar: ' + e.message, 'error');
      }
    });
    // Click fuera del modal = cancelar
    modalEl.addEventListener('click', (e) => {
      if (e.target === modalEl) close('cancel');
    });
    // Esc = cancelar
    const escHandler = (e) => {
      if (e.key === 'Escape') { close('cancel'); document.removeEventListener('keydown', escHandler); }
    };
    document.addEventListener('keydown', escHandler);

    // === Bindings de las listas anidadas (añadir/eliminar línea) ===
    modalEl.querySelectorAll('.me-list').forEach(listEl => {
      const fieldKey = listEl.dataset.key;
      const field = schema.find(f => f.key === fieldKey);
      if (!field || field.type !== 'list') return;

      listEl.querySelector('.me-list-add')?.addEventListener('click', () => {
        const items = listEl.querySelector('.me-list-items');
        const idx = items.querySelectorAll('.me-list-item').length;
        // Quitar el "Sin elementos" si existía
        const empty = items.querySelector('.me-list-empty');
        if (empty) empty.remove();
        items.insertAdjacentHTML('beforeend', renderListItem(field.itemSchema, {}, idx));
        bindListItemDelete(items);
        renumberListItems(items);
      });
      bindListItemDelete(listEl.querySelector('.me-list-items'));
    });

    // Toggle visual de weekday chips (delegación para que funcione también en listas)
    modalEl.addEventListener('change', (e) => {
      const lbl = e.target.closest && e.target.closest('.me-weekday');
      if (lbl && e.target.type === 'checkbox') {
        lbl.classList.toggle('is-on', e.target.checked);
      }
    });
  }

  function bindListItemDelete(itemsContainer) {
    if (!itemsContainer) return;
    itemsContainer.querySelectorAll('.me-list-item-del').forEach(btn => {
      // Evitar doble bind: clonar el botón
      if (btn.dataset.bound) return;
      btn.dataset.bound = '1';
      btn.addEventListener('click', () => {
        if (window.confirm('¿Eliminar esta línea?')) {
          btn.closest('.me-list-item')?.remove();
          renumberListItems(itemsContainer);
        }
      });
    });
  }

  function renumberListItems(container) {
    const items = container.querySelectorAll('.me-list-item');
    items.forEach((it, idx) => {
      it.dataset.idx = idx;
      const numEl = it.querySelector('.me-list-item-num');
      if (numEl) numEl.textContent = idx + 1;
    });
    if (items.length === 0) {
      container.innerHTML = '<p class="tiny muted me-list-empty">Sin elementos. Pulsa "+ Añadir línea".</p>';
    }
  }

  // === Selector de registro (modal pequeño con búsqueda) ===================
  /**
   * Muestra un buscador de items para luego abrir el editor.
   * Útil cuando hay muchos registros (vademécum, patologías).
   *
   *  ModalEditor.openPicker({
   *    title: 'Buscar fármaco a editar',
   *    items: db.vademecum,
   *    labelKey: 'medicamento',
   *    subLabelFn: (item) => `${item.forma} · ${item.concentracion}`,
   *    onPick: (item) => { ... },
   *  });
   */
  function openPicker({ title, items, labelKey, subLabelFn, onPick }) {
    const idPrefix = uid();
    const modalEl = document.createElement('div');
    modalEl.className = 'me-overlay';
    modalEl.innerHTML = `
      <div class="me-modal me-modal-md" role="dialog" aria-modal="true">
        <div class="me-modal-h">
          <h2>${esc(title)}</h2>
          <button type="button" class="me-close">×</button>
        </div>
        <div class="me-body">
          <div class="me-picker-search">
            <input type="search" class="field-input" id="${idPrefix}-q" placeholder="Buscar..." />
          </div>
          <div class="me-picker-list" id="${idPrefix}-list"></div>
        </div>
      </div>
    `;
    document.body.appendChild(modalEl);
    document.body.classList.add('me-locked');

    function close() {
      document.body.removeChild(modalEl);
      document.body.classList.remove('me-locked');
    }
    function normalize(s) {
      return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    }

    function renderList(query) {
      const nq = normalize(query);
      const filtered = items
        .filter(it => {
          if (!nq) return true;
          const hay = normalize((it[labelKey] || '') + ' ' + (subLabelFn ? subLabelFn(it) : ''));
          return hay.includes(nq);
        })
        .slice(0, 50);
      const listEl = modalEl.querySelector(`#${idPrefix}-list`);
      if (filtered.length === 0) {
        listEl.innerHTML = `<p class="muted small" style="padding:var(--space-3);text-align:center;">Sin resultados</p>`;
        return;
      }
      listEl.innerHTML = filtered.map(it => `
        <button type="button" class="me-picker-item" data-id="${esc(it.id)}">
          <div class="me-picker-name">${esc(it[labelKey])}</div>
          ${subLabelFn ? `<div class="me-picker-sub">${esc(subLabelFn(it))}</div>` : ''}
        </button>
      `).join('');
      listEl.querySelectorAll('.me-picker-item').forEach(btn => {
        btn.addEventListener('click', () => {
          const item = items.find(x => x.id === btn.dataset.id);
          if (item) onPick(item);
          close();
        });
      });
    }

    const q = modalEl.querySelector(`#${idPrefix}-q`);
    let timer;
    q.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => renderList(q.value), 150);
    });
    modalEl.querySelector('.me-close').addEventListener('click', close);
    modalEl.addEventListener('click', e => { if (e.target === modalEl) close(); });
    document.addEventListener('keydown', function onEsc(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); }
    });

    renderList('');
    setTimeout(() => q.focus(), 50);
  }

  // === API pública =========================================================
  window.ModalEditor = { open, openPicker };
})();
