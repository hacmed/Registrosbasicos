/* ============================================================================
   backup.js — Respaldo y restauración unificada

   Dos modos:
   - COMPLETO: configuración + estado actual de TODAS las bases de datos.
   - LIVIANO: solo configuración y lo que el admin editó.
   NO incluye: sesión activa ni cachés efímeros.
   ============================================================================ */
(function () {
  'use strict';

  const PREFIX = 'rb_';
  const EXCLUDE = ['rb_session_v1', 'rb_news_cache_v1', 'rb_announcement_seen_v1'];

  const DBS = [
    { var: 'DB_VADEMECUM',          ns: 'vademecum' },
    { var: 'DB_PATOLOGIAS',         ns: 'patologias' },
    { var: 'DB_PAI',                ns: 'pai' },
    { var: 'DB_VIGILANCIA',         ns: 'vigilancia' },
    { var: 'DB_ENLACES',            ns: 'enlaces' },
    { var: 'DB_AGENDA',             ns: 'agenda' },
    { var: 'DB_SEDEM',              ns: 'sedem' },
    { var: 'DB_DOSIS_PEDIATRICAS',  ns: 'dosis_ped' },
    { var: 'DB_LMS',                ns: 'lms' },
  ];

  function collectConfig() {
    const out = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith(PREFIX)) continue;
      if (EXCLUDE.includes(k)) continue;
      out[k] = localStorage.getItem(k);
    }
    return out;
  }

  function collectDatabases() {
    const out = {};
    DBS.forEach(db => {
      if (window[db.var]) {
        try { out[db.ns] = window[db.var]; } catch (e) {}
      }
    });
    return out;
  }

  function doExport(modo) {
    const payload = {
      _app: 'Registros Básicos',
      _type: 'backup-config',
      _modo: modo,
      _version: 2,
      _fecha: new Date().toISOString(),
      config: collectConfig(),
    };
    if (modo === 'completo') payload.databases = collectDatabases();
    const cfgN = Object.keys(payload.config).length;
    const dbN = payload.databases ? Object.keys(payload.databases).length : 0;
    payload._resumen = `${cfgN} ajustes${dbN ? ` + ${dbN} bases de datos` : ''}`;

    const blob = new Blob([JSON.stringify(payload)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const fecha = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `registros-basicos-respaldo-${modo}_${fecha}.json`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 100);
    window.State?.toast(`✓ Respaldo ${modo} descargado (${payload._resumen})`, 'ok', 4000);
    window.Auth?.audit('backup_export', `${modo}: ${payload._resumen}`);
  }

  function exportAll() {
    if (!window.ModalEditor) { doExport('completo'); return; }
    window.ModalEditor.open({
      title: '💾 Respaldar todo',
      schema: [
        { key: '_help', label: '', type: 'info',
          text: 'COMPLETO: incluye toda la configuración Y el contenido actual de todas las bases (vademécum, clínica, PAI, enlaces, agenda...). Ideal para migrar a otro dispositivo. Archivo más grande.\n\nLIVIANO: solo la configuración y lo que editaste. Archivo pequeño.' },
        { key: 'modo', label: 'Tipo de respaldo', type: 'select',
          options: [
            { value: 'completo', label: 'Completo (config + todas las bases)' },
            { value: 'liviano',  label: 'Liviano (solo configuración)' },
          ], default: 'completo', allowEmpty: false },
      ],
      data: { modo: 'completo' },
      onSave: (data) => doExport(data.modo || 'completo'),
    });
  }

  function importAll() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.style.display = 'none';
    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        const payload = JSON.parse(text);
        if (payload._type !== 'backup-config' || !payload.config) {
          throw new Error('Este archivo no es un respaldo válido de Registros Básicos');
        }
        const cfgKeys = Object.keys(payload.config || {});
        const dbKeys = Object.keys(payload.databases || {});
        const ok = window.confirm(
          `Respaldo ${payload._modo || ''} del ${new Date(payload._fecha).toLocaleString('es-BO')}\n` +
          `Contiene ${cfgKeys.length} ajustes` + (dbKeys.length ? ` y ${dbKeys.length} bases de datos` : '') + `.\n\n` +
          `Aceptar = RESTAURAR (sobrescribe lo actual)\nCancelar = no hacer nada`
        );
        if (!ok) return;

        cfgKeys.forEach(k => {
          if (EXCLUDE.includes(k)) return;
          try { localStorage.setItem(k, payload.config[k]); } catch (err) {}
        });
        dbKeys.forEach(ns => {
          try { localStorage.setItem(`rb_db_override_${ns}`, JSON.stringify(payload.databases[ns])); } catch (err) {}
        });

        window.Auth?.audit('backup_import', `${cfgKeys.length} ajustes, ${dbKeys.length} bases`);
        window.State?.toast('✓ Respaldo restaurado. Recargando…', 'ok', 2000);
        setTimeout(() => window.location.reload(), 1200);
      } catch (err) {
        window.State?.toast('Error: ' + err.message, 'error', 5000);
        console.error(err);
      }
    });
    document.body.appendChild(input);
    input.click();
    setTimeout(() => input.remove(), 1000);
  }

  // ====== Generar archivos para SUBIR AL SERVIDOR ==========================
  // Convierte el estado actual (bases editadas + usuarios) en los archivos
  // data/*.js y js/users-seed.js listos para reemplazar en la carpeta de la web.
  // Así los cambios quedan "horneados" para todos, no solo en este navegador.
  function generarArchivosServidor() {
    const archivos = [];

    // 1. Bases de datos data/*.js
    const dbFiles = [
      { var: 'DB_VADEMECUM',         file: 'data/db_vademecum.js' },
      { var: 'DB_PATOLOGIAS',        file: 'data/db_patologias.js' },
      { var: 'DB_PAI',               file: 'data/db_pai.js' },
      { var: 'DB_VIGILANCIA',        file: 'data/db_vigilancia.js' },
      { var: 'DB_ENLACES',           file: 'data/db_enlaces.js' },
      { var: 'DB_AGENDA',            file: 'data/db_agenda.js' },
      { var: 'DB_SEDEM',             file: 'data/db_sedem.js' },
      { var: 'DB_DOSIS_PEDIATRICAS', file: 'data/db_dosis_pediatricas.js' },
      { var: 'DB_LMS',               file: 'data/db_lms.js' },
    ];
    dbFiles.forEach(({ var: v, file }) => {
      if (!window[v]) return;
      const content = `/* ${file} — generado ${new Date().toISOString()} desde Registros Básicos */\nwindow.${v} = ${JSON.stringify(window[v], null, 2)};\n`;
      archivos.push({ file, content });
    });

    // 2. Semilla de usuarios js/users-seed.js (incluye hashes, no claves en claro)
    let users = [];
    try { users = JSON.parse(localStorage.getItem('rb_users_v1') || '[]'); } catch (e) {}
    if (users.length) {
      const seed = `/* js/users-seed.js — generado ${new Date().toISOString()} */\n/* Usuarios pre-cargados (contraseñas como hash PBKDF2, nunca en texto plano). */\nwindow.RB_USERS_SEED = ${JSON.stringify(users, null, 2)};\n`;
      archivos.push({ file: 'js/users-seed.js', content: seed });
    }

    // Descargar todos como un ZIP simple (concatenado con instrucciones) o
    // uno por uno. Sin librería de ZIP, descargamos uno por uno.
    if (!archivos.length) { window.State?.toast('No hay datos para generar', 'warn'); return; }

    // Crear un archivo índice con instrucciones
    const instrucciones = `INSTRUCCIONES PARA ACTUALIZAR LA WEB EN EL SERVIDOR
====================================================
Generado: ${new Date().toLocaleString('es-BO')}

Se descargaron ${archivos.length} archivos. Para aplicar los cambios:

1. En la carpeta de tu web, reemplaza estos archivos por los descargados:
${archivos.map(a => '   - ' + a.file).join('\n')}

2. Si descargaste js/users-seed.js, asegúrate de que index.html lo cargue
   ANTES de js/auth.js. Si no aparece esa línea, añádela:
   <script src="js/users-seed.js"></script>

3. Vuelve a subir la carpeta al servidor (o recarga si es local).

4. Los usuarios que abran la web verán ahora tus cambios.

NOTA: cada navegador que ya tenga datos guardados seguirá usando los suyos
hasta que pulse "Forzar actualización" o entre en incógnito. Para empezar
limpio, usa el botón de forzar actualización del pie de página.
`;
    archivos.unshift({ file: 'LEEME-actualizar.txt', content: instrucciones });

    // Descargar secuencialmente
    let i = 0;
    function bajarSiguiente() {
      if (i >= archivos.length) {
        window.State?.toast(`✓ ${archivos.length} archivos descargados. Lee LEEME-actualizar.txt`, 'ok', 5000);
        return;
      }
      const a = archivos[i++];
      const blob = new Blob([a.content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = a.file.split('/').pop();
      document.body.appendChild(link);
      link.click();
      setTimeout(() => { URL.revokeObjectURL(url); link.remove(); bajarSiguiente(); }, 400);
    }
    bajarSiguiente();
    window.Auth?.audit('generar_archivos_servidor', `${archivos.length} archivos`);
  }

  window.Backup = { exportAll, importAll, generarArchivosServidor };
})();
