/* ============================================================================
   news-feed.js — Lector de noticias de salud (RSS vía proxy + respaldo manual)

   Arquitectura (decisión: opción D):
     1. Intenta cargar feeds RSS de fuentes de salud configurables, vía un
        proxy CORS público (la app es cliente puro, sin servidor propio).
     2. Si el proxy falla o tarda > timeout, cae a las noticias MANUALES que
        el admin escribió (DB_AGENDA.noticias). Nunca deja el dashboard vacío.
     3. Cachea el último resultado exitoso en localStorage para mostrar algo
        de inmediato mientras revalida en segundo plano.

   Fuentes por defecto (editables por admin en DB_AGENDA.newsFeeds):
     - OPS/OMS Bolivia, noticias de salud
   El proxy se puede cambiar si uno deja de funcionar.

   IMPORTANTE: si no hay internet o el proxy está caído, la app sigue
   funcionando con las noticias manuales. Sin dependencias duras.
   ============================================================================ */
(function () {
  'use strict';

  // Proxies CORS públicos (se intentan en orden). Si uno cae, prueba el siguiente.
  const PROXIES = [
    (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
    (url) => `https://corsproxy.io/?url=${encodeURIComponent(url)}`,
  ];

  // Fuentes por defecto. Los feeds de rss.app entregan JSON con CORS abierto
  // (no requieren proxy), por eso son los más confiables.
  // type: 'json' = rss.app JSON Feed | 'rss' = XML vía proxy
  const DEFAULT_FEEDS = [
    { nombre: 'Noticias de salud', url: 'https://rss.app/feeds/v1.1/2RvMdqWqscLk8wXC.json', type: 'json' },
  ];

  // Feeds RSS XML de respaldo (vía proxy, menos confiables)
  const FALLBACK_RSS = [
    { nombre: 'OPS', url: 'https://www.paho.org/es/rss/noticias.xml', type: 'rss' },
  ];

  const CACHE_KEY = 'rb_news_cache_v1';
  const CACHE_TTL_MS = 6 * 60 * 60 * 1000;  // 6 horas
  const FETCH_TIMEOUT_MS = 6000;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[c]);
  }

  // Fetch con timeout
  function fetchWithTimeout(url, ms) {
    return new Promise((resolve, reject) => {
      const ctrl = new AbortController();
      const t = setTimeout(() => { ctrl.abort(); reject(new Error('timeout')); }, ms);
      fetch(url, { signal: ctrl.signal })
        .then(r => { clearTimeout(t); resolve(r); })
        .catch(e => { clearTimeout(t); reject(e); });
    });
  }

  // Parsear XML RSS/Atom → array de items {titulo, link, fecha, resumen}
  function parseFeed(xmlText, fuenteNombre) {
    const items = [];
    try {
      const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
      if (doc.querySelector('parsererror')) return items;

      // RSS 2.0
      doc.querySelectorAll('item').forEach(it => {
        items.push({
          titulo: (it.querySelector('title')?.textContent || '').trim(),
          link: (it.querySelector('link')?.textContent || '').trim(),
          fecha: (it.querySelector('pubDate')?.textContent || '').trim(),
          resumen: stripHtml(it.querySelector('description')?.textContent || '').slice(0, 200),
          fuente: fuenteNombre,
        });
      });
      // Atom
      if (items.length === 0) {
        doc.querySelectorAll('entry').forEach(en => {
          const linkEl = en.querySelector('link');
          items.push({
            titulo: (en.querySelector('title')?.textContent || '').trim(),
            link: linkEl ? (linkEl.getAttribute('href') || '') : '',
            fecha: (en.querySelector('updated')?.textContent || en.querySelector('published')?.textContent || '').trim(),
            resumen: stripHtml(en.querySelector('summary')?.textContent || en.querySelector('content')?.textContent || '').slice(0, 200),
            fuente: fuenteNombre,
          });
        });
      }
    } catch (e) {
      console.warn('[news] parse error', e);
    }
    return items;
  }

  function stripHtml(html) {
    const d = document.createElement('div');
    d.innerHTML = html;
    return (d.textContent || d.innerText || '').replace(/\s+/g, ' ').trim();
  }

  // Parsear JSON Feed (formato rss.app v1.1 / jsonfeed.org)
  function parseJsonFeed(jsonText, fuenteNombre) {
    const items = [];
    try {
      const data = typeof jsonText === 'string' ? JSON.parse(jsonText) : jsonText;
      const arr = data.items || [];
      arr.forEach(it => {
        items.push({
          titulo: (it.title || '').trim(),
          link: (it.url || it.external_url || '').trim(),
          fecha: (it.date_published || it.date_modified || '').trim(),
          resumen: stripHtml(it.content_text || it.summary || it.content_html || '').slice(0, 200),
          fuente: fuenteNombre,
          imagen: it.image || it.banner_image || '',
        });
      });
    } catch (e) {
      console.warn('[news] json parse error', e);
    }
    return items;
  }

  // Intentar cargar un feed. JSON feeds (rss.app) van directo (CORS abierto).
  // RSS XML van a través de proxies.
  async function loadFeed(feed) {
    // 1. JSON Feed directo (rss.app y similares) — sin proxy
    if (feed.type === 'json') {
      try {
        const res = await fetchWithTimeout(feed.url, FETCH_TIMEOUT_MS);
        if (res.ok) {
          const text = await res.text();
          const items = parseJsonFeed(text, feed.nombre);
          if (items.length) return items;
        }
      } catch (e) {
        // si falla directo, intentar vía proxy como último recurso
        for (const makeProxy of PROXIES) {
          try {
            const res = await fetchWithTimeout(makeProxy(feed.url), FETCH_TIMEOUT_MS);
            if (!res.ok) continue;
            const items = parseJsonFeed(await res.text(), feed.nombre);
            if (items.length) return items;
          } catch (e2) {}
        }
      }
      return [];
    }

    // 2. RSS/Atom XML vía proxy
    for (const makeProxy of PROXIES) {
      try {
        const proxied = makeProxy(feed.url);
        const res = await fetchWithTimeout(proxied, FETCH_TIMEOUT_MS);
        if (!res.ok) continue;
        const text = await res.text();
        const items = parseFeed(text, feed.nombre);
        if (items.length) return items;
      } catch (e) {
        // probar siguiente proxy
      }
    }
    return [];
  }

  // Cargar todas las fuentes y mezclar
  async function fetchAll(feeds) {
    const results = await Promise.allSettled(feeds.map(f => loadFeed(f)));
    let all = [];
    results.forEach(r => { if (r.status === 'fulfilled') all = all.concat(r.value); });
    // Ordenar por fecha desc (las que parseen bien)
    all.sort((a, b) => {
      const da = Date.parse(a.fecha) || 0;
      const db = Date.parse(b.fecha) || 0;
      return db - da;
    });
    return all.slice(0, 12);
  }

  function getCache() {
    try {
      const raw = localStorage.getItem(CACHE_KEY);
      if (!raw) return null;
      const obj = JSON.parse(raw);
      if (Date.now() - obj.ts > CACHE_TTL_MS) return obj; // expirado pero usable como fallback
      return obj;
    } catch (e) { return null; }
  }
  function setCache(items) {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({ ts: Date.now(), items }));
    } catch (e) {}
  }

  /**
   * API principal: render de noticias en un contenedor.
   *  - container: elemento DOM donde inyectar
   *  - manualNoticias: array de noticias del admin (DB_AGENDA.noticias) como respaldo
   *  - feeds: fuentes RSS (DB_AGENDA.newsFeeds o DEFAULT_FEEDS)
   */
  async function render(container, opts = {}) {
    if (!container) return;
    const feeds = (opts.feeds && opts.feeds.length) ? opts.feeds : DEFAULT_FEEDS;
    const manual = opts.manualNoticias || [];

    // 1. Mostrar de inmediato lo que haya: caché RSS o noticias manuales
    const cache = getCache();
    if (cache && cache.items && cache.items.length) {
      container.innerHTML = renderItems(cache.items, 'rss', true);
    } else if (manual.length) {
      container.innerHTML = renderManual(manual);
    } else {
      container.innerHTML = `<div class="m1-news-loading"><div class="skel" style="height:60px;"></div></div>`;
    }

    // 2. Revalidar en segundo plano (si hay conexión)
    if (navigator.onLine === false) {
      // Sin conexión: quedarse con lo mostrado (o manual)
      if (!cache && manual.length) container.innerHTML = renderManual(manual);
      return;
    }

    try {
      const items = await fetchAll(feeds);
      if (items.length) {
        setCache(items);
        container.innerHTML = renderItems(items, 'rss', false);
      } else if (!cache && manual.length) {
        // RSS no devolvió nada y no hay caché → usar manual
        container.innerHTML = renderManual(manual);
      } else if (!cache && !manual.length) {
        container.innerHTML = `<p class="muted small">No se pudieron cargar noticias en este momento. Verifica tu conexión o agrega noticias manualmente.</p>`;
      }
    } catch (e) {
      // Falla total: usar manual si existe
      if (!cache && manual.length) container.innerHTML = renderManual(manual);
    }
  }

  function renderItems(items, kind, fromCache) {
    if (!items.length) return '<p class="muted small">Sin noticias.</p>';
    return `
      ${fromCache ? '<div class="tiny muted m1-news-cache">📡 Mostrando última versión guardada · actualizando…</div>' : ''}
      <div class="m1-news-list">
        ${items.map(n => `
          <a class="m1-news-item" href="${esc(n.link)}" target="_blank" rel="noopener noreferrer">
            <div class="m1-news-meta">
              <span class="badge badge-mute tiny">${esc(n.fuente || 'RSS')}</span>
              ${n.fecha ? `<span class="tiny muted">${esc(fmtFecha(n.fecha))}</span>` : ''}
            </div>
            <div class="m1-news-title">${esc(n.titulo)}</div>
            ${n.resumen ? `<div class="m1-news-summary tiny muted">${esc(n.resumen)}…</div>` : ''}
          </a>
        `).join('')}
      </div>
    `;
  }

  function renderManual(noticias) {
    return `
      <div class="tiny muted m1-news-cache">📝 Noticias del administrador (sin conexión a fuentes externas)</div>
      <div class="m1-news-list">
        ${noticias.map(n => `
          <div class="m1-news-item">
            <div class="m1-news-meta">
              ${n.fecha ? `<span class="tiny muted">${esc(n.fecha)}</span>` : ''}
            </div>
            <div class="m1-news-title">${esc(n.titulo)}</div>
            ${n.cuerpo ? `<div class="m1-news-summary tiny muted">${esc(n.cuerpo)}</div>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  }

  function fmtFecha(s) {
    const t = Date.parse(s);
    if (!t) return s;
    try {
      return new Intl.DateTimeFormat('es-BO', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(t));
    } catch (e) { return s; }
  }

  window.NewsFeed = { render, DEFAULT_FEEDS };
})();
